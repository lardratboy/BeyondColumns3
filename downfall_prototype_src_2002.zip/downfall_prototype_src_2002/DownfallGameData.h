// DownfallGameData.h: -- 
//
//	Copyright (c) 2002, Brad P. Taylor, LLC
//
//	All rights reserved, unauthorized reproduction prohibited
//
//	-- FILE NOTES --
//
//////////////////////////////////////////////////////////////////////

#if !defined( DOWNFALLGAMEDATA_2B7F5795_78E0_45f1_9B97_BA516EA093D3_INCLUDED )
#define DOWNFALLGAMEDATA_2B7F5795_78E0_45f1_9B97_BA516EA093D3_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif

// ----------------------------------------------------------------------------

#include "gameplay.h"

// ----------------------------------------------------------------------------

#define BPT_WANT_FPS			30
//#define BPT_USE_FPS				((BPT_WANT_FPS)*2)
//#define BPT_USE_FPS				((BPT_WANT_FPS)/2)
#define BPT_USE_FPS				((BPT_WANT_FPS)*1)

#define MACRO_SCALE_TO_FRAMERATE( x ) \
	( ((x) * BPT_USE_FPS) / (BPT_WANT_FPS) )

// ----------------------------------------------------------------------------

namespace GAMEDATA {

	extern const DOWNFALL::Shape g_FalloutShapes[];
	extern const DOWNFALL::Shape g_GroupShapes[];

	extern const DOWNFALL::InputShapeSet * g_pExtendedFalloutShapeOddsTable[];
	extern const DOWNFALL::InputShapeSet * g_pFalloutShapeOddsTable[];
	extern const DOWNFALL::InputShapeSet * g_pTwoUpShapeOddsTable[];

}; // namespace GAMEDATA

#endif // DOWNFALLGAMEDATA_2B7F5795_78E0_45f1_9B97_BA516EA093D3_INCLUDED

