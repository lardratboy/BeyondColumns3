// BPTGeometry.h: -- 
//
//	Copyright (c) 2002, Brad P. Taylor, LLC
//
//	All rights reserved, unauthorized reproduction prohibited
//
//	-- FILE NOTES --
//
//////////////////////////////////////////////////////////////////////

#if !defined( BPTGEOMETRY_31AA5218_76A8_4322_AC3E_F159862081E3_INCLUDED )
#define BPTGEOMETRY_31AA5218_76A8_4322_AC3E_F159862081E3_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif

// ----------------------------------------------------------------------------

#include <D3dx8mesh.h>
#include <limits>
#include "BoxOfBoxes.h"

// ----------------------------------------------------------------------------

namespace BPT {

	// ------------------------------------------------------------------------

	HRESULT CreateOctahedron(
		LPDIRECT3DDEVICE8 pd3dDevice
		,const DWORD dwOptions
		,const DWORD dwFVF
		,LPD3DXMESH * ppMesh
	);

	HRESULT CreateD3DXTessellatedOctahedron(
		LPDIRECT3DDEVICE8 pd3dDevice
		,const float fSegmentsPerEdge
		,const DWORD dwOptions
		,const DWORD dwFVF
		,LPD3DXMESH * ppMesh
	);

	HRESULT NormalizeMeshVertices( LPD3DXMESH pMesh, const bool bCalcNormals );

	HRESULT ReverseNormals( LPD3DXMESH pMesh );

	HRESULT ReverseFaceOrder( LPD3DXMESH pMesh );

	HRESULT CreateTessellatedGrid(
		LPDIRECT3DDEVICE8 pd3dDevice
		,const float width
		,const float height
		,const float zValue
		,const int horizontal_vertex_count
		,const int vertical_vertex_count
		,const DWORD dwOptions
		,const DWORD dwFVF
		,LPD3DXMESH * ppMesh
		,const bool bOrganizeIndicesIntoPseudoFans
	);

	HRESULT
	CreateSphere(
		LPDIRECT3DDEVICE8 pd3dDevice
		,const bool bViewInside
		,const int horizontal_vertex_count
		,const int vertical_vertex_count
		,const DWORD dwOptions
		,const DWORD dwFVF
		,LPD3DXMESH * ppMesh
		,const bool bOrganizeIndicesIntoPseudoFans
	);

	DWORD CalcFVFOffset( const DWORD dwFVF, const DWORD dwFVFFlag );

	HRESULT TranslateMeshVerts( LPD3DXMESH pMesh, const D3DXVECTOR3 & translation );

	HRESULT CenterMeshOnCoordinate( LPD3DXMESH pMesh, const D3DXVECTOR3 & center );

	HRESULT
	CreateBoxOfBoxes( 
		LPDIRECT3DDEVICE8 pd3dDevice
		,const int xCount
		,const int yCount
		,const int zCount
		,const D3DXVECTOR3 & firstBoxCenter
		,const D3DXVECTOR3 & innerBoxDimension
		,const D3DXVECTOR3 & innerBoxDelta
		,const bool bUseSameAttribute
		,const bool bCenterOnAxis
		,const DWORD dwOptions
		,const DWORD dwFVF
		,LPD3DXMESH * ppMesh
	);

	// ------------------------------------------------------------------------

	//
	//	TFilterMeshData()
	//
	//	-- Filters assume that the vertex buffer is valid for read & write op's!
	//

	template< class FILTER, class T > HRESULT
	TFilterMeshData( LPD3DXMESH pMesh, FILTER & filter, const T nDataOffset )
	{
		// ----------------------------------------------------------------

		DWORD dwNumVertices = pMesh->GetNumVertices();

		DWORD dwFVF = pMesh->GetFVF();

		HRESULT hr;

		// ----------------------------------------------------------------

		LPBYTE pVertexData;

		if ( FAILED( hr = pMesh->LockVertexBuffer( 0, &pVertexData ) ) ) {

			return hr;

		}

		pVertexData += nDataOffset;

		DWORD fvfSize = D3DXGetFVFVertexSize( dwFVF );

		for ( DWORD v = 0; v < dwNumVertices; v++ ) {

			filter( (void *)pVertexData );

			pVertexData += fvfSize;

		}

		pMesh->UnlockVertexBuffer();

		return S_OK;

	}

	// ------------------------------------------------------------------------

	//
	//	TFilterMeshVertices()
	//

	template< class FILTER > HRESULT
	TFilterMeshVertices( LPD3DXMESH pMesh, FILTER & filter )
	{
		return TFilterMeshData(
			pMesh
			,filter
			,CalcFVFOffset( pMesh->GetFVF(), D3DFVF_XYZ )
		);
	}

	// ------------------------------------------------------------------------

	//
	//	TFilterMeshNormals()
	//

	template< class FILTER > HRESULT
	TFilterMeshNormals( LPD3DXMESH pMesh, FILTER & filter )
	{
		return TFilterMeshData(
			pMesh
			,filter
			,CalcFVFOffset( pMesh->GetFVF(), D3DFVF_NORMAL )
		);
	}

	// ------------------------------------------------------------------------

	//
	//	NormalizeFilter()
	//

	struct NormalizeFilter {

		void operator()( float * pX, float * pY, float * pZ ) {

			float x = *pX;
			float y = *pY;
			float z = *pZ;

			// need to make sure that the various math functions
			// are reasonably efficient.

			float len = sqrtf( x * x + y * y + z * z );

			if ( std::numeric_limits<FLOAT>::epsilon() <= fabsf(len) ) {

				float oo = 1.0f / len;

				*pX = x * oo;
				*pY = y * oo;
				*pZ = z * oo;

			} else {

				*pX = 0.0f;
				*pY = 0.0f;
				*pZ = 0.0f;

			}

		}

		void operator()( void * pData ) {

			(*this)( (float *)pData, ((float *)pData) + 1, ((float *)pData) + 2 );

		}

	};

	//
	//	NegateFilter()
	//

	struct NegateFilter {

		void operator()( float * pX, float * pY, float * pZ ) {

			*pX = -(*pX);
			*pY = -(*pY);
			*pZ = -(*pZ);

		}

		void operator()( void * pData ) {

			(*this)( (float *)pData, ((float *)pData) + 1, ((float *)pData) + 2 );

		}

	};

	//
	//	TranlateFilter()
	//

	class TranlateFilter {

	private:

		float m_X;
		float m_Y;
		float m_Z;

	public:

		TranlateFilter( const float x = 0.0f, const float y = 0.0f, const float z = 0.0f ) : m_X(x), m_Y(y), m_Z(z) {}

		void operator()( float * pX, float * pY, float * pZ ) {

			*pX += m_X;
			*pY += m_Y;
			*pZ += m_Z;

		}

		void operator()( void * pData ) {

			(*this)( (float *)pData, ((float *)pData) + 1, ((float *)pData) + 2 );

		}

	};


}; // namespace BPT

#endif // !defined(BPTGEOMETRY_31AA5218_76A8_4322_AC3E_F159862081E3_INCLUDED)
