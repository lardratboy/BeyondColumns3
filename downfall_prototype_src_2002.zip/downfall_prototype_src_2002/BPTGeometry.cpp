// My3DXMesh.h: -- this is my wrapper around the 3DX helpers
//
//	Copyright (c) 2002, Brad P. Taylor, LLC
//
//	All rights reserved, unauthorized reproduction prohibited
//
//	-- FILE NOTES --
//
//////////////////////////////////////////////////////////////////////

#include "StdAfx.h"
#include "bptgeometry.h"
#include "BPT3DUtil.h"

#include <limits>
#include <D3d8types.h>
#include <D3dx8math.h>

namespace BPT {

	// ------------------------------------------------------------------------

	//
	//	OutputDebugf()
	//

	void OutputDebugf( const char * pszFormat, ... ) {

		char text[ 2048 ];

		va_list marker;

		va_start( marker, pszFormat );

		vsprintf( text, pszFormat, marker );

		OutputDebugString( "BPT::" );

		OutputDebugString( text );

		va_end( marker );

	}

	// ------------------------------------------------------------------------

	//
	//	XXX_D3DXComputeNormals()
	//

	HRESULT 
	XXX_D3DXComputeNormals( LPD3DXBASEMESH pMesh )
	{

#if !defined(D3DXTesselateMesh)

		return D3DXComputeNormals( pMesh, 0 );

#else

		return D3DXComputeNormals( pMesh );

#endif

	}


	// ------------------------------------------------------------------------

	//
	//	CreateOctahedron()
	//

	HRESULT CreateOctahedron(
		LPDIRECT3DDEVICE8 pd3dDevice
		,const DWORD dwOptions
		,const DWORD dwFVF
		,LPD3DXMESH * ppMesh
	) {

		// ----------------------------------------------------------------

		if ( !ppMesh ) {

			return E_FAIL;

		}

		*ppMesh = NULL;

		// Create the un tessellated mesh
		// ----------------------------------------------------------------

		LPD3DXMESH pOctahedronMesh;

		HRESULT hr = D3DXCreateMeshFVF(
			8, 6, dwOptions, dwFVF, pd3dDevice, &pOctahedronMesh
		);

		if ( FAILED( hr ) ) {

			return hr;

		}

		// ----------------------------------------------------------------

		DWORD dwNumFaces = pOctahedronMesh->GetNumFaces();

		_ASSERT( 8 <= dwNumFaces );

		DWORD dwNumVertices = pOctahedronMesh->GetNumVertices();

		_ASSERT( 6 <= dwNumVertices );

		// Fill in the attribute table
		// ----------------------------------------------------------------

		{
			LPDWORD pAttributeData;

			if ( FAILED( hr = pOctahedronMesh->LockAttributeBuffer( 0, &pAttributeData ) ) ) {

				pOctahedronMesh->Release();

				return hr;

			}

			ZeroMemory( pAttributeData, dwNumFaces * sizeof(DWORD) );

			pOctahedronMesh->UnlockAttributeBuffer();
		}

		// Fill in the index table
		// ----------------------------------------------------------------

		{
			LPBYTE pIndexData;

			if ( FAILED( hr = pOctahedronMesh->LockIndexBuffer( 0, &pIndexData ) ) ) {

				pOctahedronMesh->Release();

				return hr;

			}

			WORD * pIndices = (WORD *)( pIndexData );

			*pIndices++ = 2; *pIndices++ = 0; *pIndices++ = 1; 
			*pIndices++ = 3; *pIndices++ = 0; *pIndices++ = 2; 
			*pIndices++ = 4; *pIndices++ = 0; *pIndices++ = 3; 
			*pIndices++ = 1; *pIndices++ = 0; *pIndices++ = 4; 

			*pIndices++ = 1; *pIndices++ = 5; *pIndices++ = 2; 
			*pIndices++ = 2; *pIndices++ = 5; *pIndices++ = 3; 
			*pIndices++ = 3; *pIndices++ = 5; *pIndices++ = 4; 
			*pIndices++ = 4; *pIndices++ = 5; *pIndices++ = 1; 

			pOctahedronMesh->UnlockIndexBuffer();
		}

		// Fill in the verts 
		// ----------------------------------------------------------------

		{
			LPBYTE pVertexData;

			if ( FAILED( hr = pOctahedronMesh->LockVertexBuffer( 0, &pVertexData ) ) ) {

				pOctahedronMesh->Release();

				return hr;

			}

			int fvfSize = D3DXGetFVFVertexSize( pOctahedronMesh->GetFVF() );

			ZeroMemory(
				pVertexData
				,fvfSize * dwNumVertices
			);

			*((D3DVECTOR *)&pVertexData[ fvfSize * 0 ]) = D3DXVECTOR3( +0.0f, +1.0f, +0.0f );
			*((D3DVECTOR *)&pVertexData[ fvfSize * 1 ]) = D3DXVECTOR3( -1.0f, +0.0f, +0.0f );
			*((D3DVECTOR *)&pVertexData[ fvfSize * 2 ]) = D3DXVECTOR3( +0.0f, +0.0f, +1.0f );
			*((D3DVECTOR *)&pVertexData[ fvfSize * 3 ]) = D3DXVECTOR3( +1.0f, +0.0f, +0.0f );
			*((D3DVECTOR *)&pVertexData[ fvfSize * 4 ]) = D3DXVECTOR3( +0.0f, +0.0f, -1.0f );
			*((D3DVECTOR *)&pVertexData[ fvfSize * 5 ]) = D3DXVECTOR3( +0.0f, -1.0f, +0.0f );

			pOctahedronMesh->UnlockVertexBuffer();

		}

		// ----------------------------------------------------------------

		if ( D3DFVF_NORMAL & dwFVF ) {

			if ( FAILED( hr = XXX_D3DXComputeNormals( pOctahedronMesh ) ) ) {

				pOctahedronMesh->Release();

				return hr;

			}

		}

		// ----------------------------------------------------------------

		*ppMesh = pOctahedronMesh;

		return S_OK;

	}

	// ------------------------------------------------------------------------

	//
	//	NormalizeMeshVertices()
	//

	HRESULT
	NormalizeMeshVertices( LPD3DXMESH pMesh, const bool bCalcNormals )
	{
		// ----------------------------------------------------------------

		HRESULT hr = TFilterMeshVertices( pMesh, NormalizeFilter() );

		if ( FAILED(hr) ) {

			return hr;

		}

		// ----------------------------------------------------------------

		if ( bCalcNormals && (D3DFVF_NORMAL & pMesh->GetFVF()) ) {

			if ( FAILED( hr = XXX_D3DXComputeNormals( pMesh ) ) ) {

				return hr;

			}

		}

		return S_OK;

	}

	// ------------------------------------------------------------------------

	//
	//	CreateD3DXTessellatedOctahedron()
	//

	HRESULT CreateD3DXTessellatedOctahedron(
		LPDIRECT3DDEVICE8 pd3dDevice
		,const float fSegmentsPerEdge
		,const DWORD dwOptions
		,const DWORD dwFVF
		,LPD3DXMESH * ppMesh
	)
	{
		if ( !ppMesh ) {

			return E_FAIL;

		}

		// --------------------------------------------------------------------

		LPD3DXMESH pOctahedron;

		HRESULT hr = CreateOctahedron(
			pd3dDevice
			,dwOptions
			,dwFVF
			,&pOctahedron
		);

		if ( FAILED( hr ) ) {

			return hr;

		}

		if ( 1.0f == fSegmentsPerEdge ) {

			*ppMesh = pOctahedron;

			return S_OK;

		}

		// --------------------------------------------------------------------

#if !defined(D3DXTesselateMesh)

		hr = D3DXTessellateNPatches(
			pOctahedron
			,NULL
			,fSegmentsPerEdge
			,TRUE // FALSE
			,ppMesh
			,NULL
		);

#else

		hr = D3DXTesselateMesh(
			pOctahedron
			,NULL
			,fSegmentsPerEdge
			,TRUE // FALSE
			,ppMesh
		);

#endif

		pOctahedron->Release();

#if 1 // test
		NormalizeMeshVertices( *ppMesh, false );
#endif

		return hr;

	}

	// ------------------------------------------------------------------------

	//
	//	CreateTessellatedGrid()
	//

	HRESULT CreateTessellatedGrid(
		LPDIRECT3DDEVICE8 pd3dDevice
		,const float fWidth
		,const float fHeight
		,const float zValue
		,const int horizontal_vertex_count
		,const int vertical_vertex_count
		,const DWORD dwOptions
		,const DWORD dwFVF
		,LPD3DXMESH * ppMesh
		,const bool bOrganizeIndicesIntoPseudoFans
	) {

		// ----------------------------------------------------------------

		if ( !ppMesh ) {

			return E_FAIL;

		}

		*ppMesh = NULL;

		if ( (2 > horizontal_vertex_count) || (2 > vertical_vertex_count) ) {

			return E_FAIL;

		}

		// Create the mesh
		// ----------------------------------------------------------------

		LPD3DXMESH pMesh;

		DWORD dwVertices = (horizontal_vertex_count * vertical_vertex_count);

		DWORD dwNumIndices = ((horizontal_vertex_count - 1) * (vertical_vertex_count - 1)) * 2 * 3; // (2 triangles per element * 3 entries)

		DWORD dwNumFaces = dwNumIndices / 3;

		HRESULT hr = D3DXCreateMeshFVF(
			dwNumFaces
			,dwVertices
			,dwOptions
			,dwFVF
			,pd3dDevice
			,&pMesh
		);

		if ( FAILED( hr ) ) {

			return hr;

		}

#if defined(_DEBUG)

		DWORD dwCheckVertices = pMesh->GetNumVertices();

		_ASSERT( dwVertices <= dwCheckVertices );

		DWORD dwCheckFaces = pMesh->GetNumFaces();

		_ASSERT( dwNumFaces <= dwCheckFaces );

#endif

		// Construct the verts
		// ----------------------------------------------------------------

		{
			LPBYTE pVertexData;

			if ( FAILED( hr = pMesh->LockVertexBuffer( 0, &pVertexData ) ) ) {

				pMesh->Release();

				return hr;

			}

			DWORD fvfSize = D3DXGetFVFVertexSize( pMesh->GetFVF() );

			ZeroMemory(
				pVertexData
				,fvfSize * dwVertices
			);

#if defined(_DEBUG)
			LPBYTE pEndVertexData = pVertexData + (fvfSize * dwVertices);
#endif

			// Find the offset for the various FVF fields
			// ----------------------------------------------------------------

			DWORD dwNormalOffset = (D3DFVF_NORMAL & dwFVF) ? CalcFVFOffset(dwFVF,D3DFVF_NORMAL) : 0;

			DWORD dwUVOffset = (D3DFVF_TEX1 & dwFVF) ? CalcFVFOffset(dwFVF,D3DFVF_TEX1) : 0;

			// ----------------------------------------------------------------

			float dy = 1.0f / (float)(vertical_vertex_count - 1);

			float dx = 1.0f / (float)(horizontal_vertex_count - 1);

			float y = 0.0f;

			for ( int v = 0; v < vertical_vertex_count; v++ ) {

				float x = 0.0f;

				for ( int h = 0; h < horizontal_vertex_count; h++ ) {

					// --------------------------------------------------------

					float * pXYZ = (float *)pVertexData;

					// I do the multiply out here so that the range of the delta is better
					// the calculation of the delta could be w/(n-1) and h/(m-1)...

					*(pXYZ + 0) = x * fWidth;

					*(pXYZ + 1) = y * fHeight;

					*(pXYZ + 2) = zValue;

					// --------------------------------------------------------

					if ( dwNormalOffset ) {

						float * pNormal = (float *)(pVertexData + dwNormalOffset);

						*(pNormal + 0) = 0.0f;
						*(pNormal + 1) = 0.0f;
						*(pNormal + 2) = -1.0f;

					}

					// --------------------------------------------------------

					if ( dwUVOffset ) {

						float * pUV = (float *)(pVertexData + dwUVOffset);

#if 0 // test texture wack

						float fxx = sinf( (x + y) * (D3DX_PI * (1.5f * horizontal_vertex_count)) );

						if ( 0.0f > fxx ) fxx = -fxx; //1.0f + fxx;

						float fyy = sinf( y * (D3DX_PI * (2.5f * vertical_vertex_count)) );

						if ( 0.0f > fyy ) fyy = -fyy; //1.0f + fyy;

						*(pUV + 0) = fxx;
						*(pUV + 1) = fyy;

#else

#if 1

						*(pUV + 0) = fmodf( x * 2.0f, 1.0f );
						*(pUV + 1) = fmodf( y * 2.0f, 1.0f );

#else

						*(pUV + 0) = x;
						*(pUV + 1) = y;

#endif

#endif

					}

					// --------------------------------------------------------

					x += dx;

					pVertexData += fvfSize;

				}

				y += dy;

			}

			// ----------------------------------------------------------------

#if defined(_DEBUG)
			{
				DWORD diff = pVertexData - pEndVertexData;

				BPT::OutputDebugf( "INDEX: %p vs. %p (%d)\n", pEndVertexData, pVertexData, diff );

				_ASSERT( pEndVertexData == pVertexData );
			}
#endif

			// ----------------------------------------------------------------

			pMesh->UnlockVertexBuffer();

		}

		// Fill in the index table trying to make 'fans' to make adjacent
		// triangles share up to two verts hopefully software vertex
		// processing has a cache for indexed primitives!
		// --------------------------------------------------------------------

		{
			// ----------------------------------------------------------------

			LPBYTE pIndexData;

			if ( FAILED( hr = pMesh->LockIndexBuffer( 0, &pIndexData ) ) ) {

				pMesh->Release();

				return hr;

			}

			WORD * pIndices = (WORD *)( pIndexData );

#if defined(_DEBUG)
			WORD * pEndIndices = pIndices + dwNumIndices;
#endif

			// ----------------------------------------------------------------

			int vFanCount, hFanCount;

			if ( bOrganizeIndicesIntoPseudoFans ) {

				vFanCount = (vertical_vertex_count - 1) / 2;
				hFanCount = (horizontal_vertex_count - 1) / 2;

			} else {

				vFanCount = 0;
				hFanCount = 0;

			}

			// Build the fans
			// ----------------------------------------------------------------

			if ( hFanCount && vFanCount ) {

				// setup the vertex setup tables
				// ------------------------------------------------------------

				const int indexOffset[ 9 ] = {
					/* a == 0 */ -horizontal_vertex_count - 1,
					/* b == 1 */ -horizontal_vertex_count,
					/* c == 2 */ -horizontal_vertex_count + 1,
					/* d == 3 */ -1,
					/* e == 4 */ 0,
					/* f == 5 */ +1,
					/* g == 6 */ +horizontal_vertex_count - 1,
					/* h == 7 */ +horizontal_vertex_count,
					/* i == 8 */ +horizontal_vertex_count + 1
				};

				const int vertexOrder[ 8 * 3 ] = {
					4, 1, 0,
					4, 0, 3,
					4, 3, 6,
					4, 6, 7,
					4, 7, 8,
					4, 8, 5,
					4, 5, 2,
					4, 2, 1
				};

				// ------------------------------------------------------------

				int outterBaseIndex = horizontal_vertex_count + 1;

				int hPitch = horizontal_vertex_count * 2;

				for ( int vf = 0; vf < vFanCount; vf++ ) {

					int innerBaseIndex = outterBaseIndex;

					for ( int hf = 0; hf < hFanCount; hf++ ) {

						for ( int t = 0; t < (8 * 3); t++ ) {

							*pIndices++ = indexOffset[ vertexOrder[ t ] ] + innerBaseIndex;

						}

						innerBaseIndex += 2;

					}

					outterBaseIndex += hPitch;

				}

			}

			// Handle the horizontal left over
			// ----------------------------------------------------------------

			if ( hFanCount && vFanCount ) {

				int hFanVertexCount = (hFanCount * 3) - (hFanCount - 1);

				int hTriangleCount = horizontal_vertex_count - hFanVertexCount;

				if ( hTriangleCount ) {
					
					int hTriangleIndex = hFanVertexCount - 1;

					int hPitch = horizontal_vertex_count - hTriangleCount;

					int vTriangleCount = vertical_vertex_count - ((vFanCount * 3) - (vFanCount - 1));

					for ( int v = (1 + vTriangleCount); v < vertical_vertex_count; v++ ) {

						for ( int t = 0; t < hTriangleCount; t++ ) {

							*pIndices++ = hTriangleIndex + horizontal_vertex_count;
							*pIndices++ = hTriangleIndex;
							*pIndices++ = hTriangleIndex + 1;

							*pIndices++ = hTriangleIndex + horizontal_vertex_count;
							*pIndices++ = hTriangleIndex + 1;
							*pIndices++ = hTriangleIndex + horizontal_vertex_count + 1;

							++hTriangleIndex;

						}

						hTriangleIndex += hPitch;

					}

				}

			}

			// Handle the vertical left over
			// ----------------------------------------------------------------

			{
				// ------------------------------------------------------------

				int vTriangleCount, vTriangleIndex;

				if ( vFanCount ) {

					int vFanVertexCount = (vFanCount * 3) - (vFanCount - 1);

					vTriangleCount = vertical_vertex_count - vFanVertexCount;

					vTriangleIndex = (vFanVertexCount - 1) * horizontal_vertex_count;

				} else {

					vTriangleCount = vertical_vertex_count - 1;

					vTriangleIndex = 0;

				}

				// ------------------------------------------------------------

				if ( vTriangleCount ) {

					for ( int v = 0; v < vTriangleCount; v++ ) {

						for ( int h = 1; h < horizontal_vertex_count; h++ ) {

							*pIndices++ = vTriangleIndex + horizontal_vertex_count;
							*pIndices++ = vTriangleIndex;
							*pIndices++ = vTriangleIndex + 1;

							*pIndices++ = vTriangleIndex + horizontal_vertex_count;
							*pIndices++ = vTriangleIndex + 1;
							*pIndices++ = vTriangleIndex + horizontal_vertex_count + 1;

							++vTriangleIndex;

						}

						++vTriangleIndex;

					}

				}

			}

			// ----------------------------------------------------------------

#if defined(_DEBUG)
			{
				DWORD diff = pIndices - pEndIndices;

				BPT::OutputDebugf( "INDEX: %p vs. %p (%d)\n", pEndIndices, pIndices, diff );

				_ASSERT( pEndIndices == pIndices );
			}
#endif

			// ----------------------------------------------------------------

			pMesh->UnlockIndexBuffer();

		}

		// Fill in the attribute table
		// ----------------------------------------------------------------

		{
			LPDWORD pAttributeData;

			if ( FAILED( hr = pMesh->LockAttributeBuffer( 0, &pAttributeData ) ) ) {

				pMesh->Release();

				return hr;

			}

			ZeroMemory( pAttributeData, dwNumFaces * sizeof(DWORD) );

			pMesh->UnlockAttributeBuffer();
		}

		// ----------------------------------------------------------------

		*ppMesh = pMesh;

		return S_OK;

	}

	// ------------------------------------------------------------------------

	//
	//	ReverseNormals()
	//

	HRESULT
	ReverseNormals( LPD3DXMESH pMesh )
	{
		return TFilterMeshNormals( pMesh, NegateFilter() );
	}

	// ------------------------------------------------------------------------

	//
	//	ReverseFaceOrder()
	//

	HRESULT
	ReverseFaceOrder( LPD3DXMESH pMesh )
	{
		LPBYTE pIndexData;

		HRESULT hr;

		if ( FAILED( hr = pMesh->LockIndexBuffer( 0, &pIndexData ) ) ) {

			return hr;

		}

		DWORD dwFaces = pMesh->GetNumFaces();

		WORD * pWork = (WORD *)pIndexData;

		for ( DWORD f = 0; f < dwFaces; f++ ) {

			WORD t = *(pWork + 0);

			*(pWork + 0) = *(pWork + 2);

			*(pWork + 2) = t;

			pWork += 3;

		}

		pMesh->UnlockIndexBuffer();

		return S_OK;

	}

	// ------------------------------------------------------------------------

	//
	//	TurnMeshInsideOut()
	//

	HRESULT TurnMeshInsideOut( LPD3DXMESH pMesh )
	{
		HRESULT hr;

		if ( D3DFVF_NORMAL & pMesh->GetFVF() ) {

			if ( FAILED( hr = ReverseNormals( pMesh ) ) ) {

				return hr;

			}

		}

		if ( FAILED( hr = ReverseFaceOrder( pMesh ) ) ) {

			return hr;

		}

		return S_OK;
	}

	// ------------------------------------------------------------------------

	//
	//	SpiralTestFilter()
	//

	struct SpiralTestFilter {

		void operator()( float * pX, float * pY, float * pZ ) {

#if 0 // spiral test

			float alpha = *pY;
			float beta = 1.0f; //alpha;

			float x = (*pX) + alpha;
			float y = (*pY) * beta;

			float r = y * (D3DX_PI * 2.0f);
			float t = x * (D3DX_PI * 2.0f);

			*pX = r * cosf( t );
			*pY = r * sinf( t );
			*pZ = 0.0f;
#else

			float x = *pX;
			float y = *pY;

			float a = y * (D3DX_PI * 2.0f);
			float t = x * (D3DX_PI * 2.0f);

			float a2 = a * a;
			float r2 = a2 * t;

			float r = sqrtf( r2 );

			*pX = r * cosf( t );
			*pY = r * sinf( t );
			*pZ = 0.0f;

#endif

		}

		void operator()( void * pData ) {

			(*this)( (float *)pData, ((float *)pData) + 1, ((float *)pData) + 2 );

		}

	};

	// ------------------------------------------------------------------------

	//
	//	EllipsoidFilter()
	//

	struct EllipsoidFilter {

		float m_RX;
		float m_RY;
		float m_RZ;

		EllipsoidFilter(
			const float rx = 1.0f, 
			const float ry = 1.0f, 
			const float rz = 1.0f
		) : m_RX(rx), m_RY(ry), m_RZ(rz) {}

		void operator()( float * pX, float * pY, float * pZ ) {

			float u = (((*pX) - 0.5f) * D3DX_PI);
			float v = (((*pY) - 0.5f) * (D3DX_PI * 2.0f));
			float cu = cosf(u);

			*pX = (m_RX * cu) * cosf(v);
			*pY = (m_RY * cu) * sinf(v);
			*pZ = (m_RZ * sinf(u));

		}

		void operator()( void * pData ) {

			(*this)( (float *)pData, ((float *)pData) + 1, ((float *)pData) + 2 );

		}

	};

	//
	//	CreateSphere()
	//

	HRESULT
	CreateSphere(
		LPDIRECT3DDEVICE8 pd3dDevice
		,const bool bViewInside
		,const int horizontal_vertex_count
		,const int vertical_vertex_count
		,const DWORD dwOptions
		,const DWORD dwFVF
		,LPD3DXMESH * ppMesh
		,const bool bOrganizeIndicesIntoPseudoFans
	)
	{
		// create the grid to convert to spherical coordinates

		HRESULT hr = CreateTessellatedGrid(
			pd3dDevice
			,1.0f
			,1.0f
			,0.0f
			,horizontal_vertex_count
			,vertical_vertex_count
			,dwOptions
			,dwFVF
			,ppMesh
			,bOrganizeIndicesIntoPseudoFans
		);

		if ( FAILED(hr) ) {

			return hr;

		}

		// convert the coordinates to spheroid coordinates

		EllipsoidFilter ellipsoidFilter( 1.0f, 1.0f, 1.0f );

		if ( FAILED( hr = TFilterMeshVertices( *ppMesh, ellipsoidFilter ) ) ) {

			(*ppMesh)->Release();

			*ppMesh = 0;

			return hr;

		}

		// calculate the normals

		if ( D3DFVF_NORMAL & dwFVF ) {

			if ( FAILED( hr = XXX_D3DXComputeNormals( *ppMesh ) ) ) {

				(*ppMesh)->Release();

				*ppMesh = 0;

				return hr;

			}

		}

		// check to see if this is a inside out object

		if ( bViewInside ) {

			if ( FAILED( hr = TurnMeshInsideOut( *ppMesh ) ) ) {

				(*ppMesh)->Release();

				*ppMesh = 0;

				return hr;

			}

		}

		return S_OK;

	}

	// ------------------------------------------------------------------------

	//
	//	CalcFVFOffset()
	//

	DWORD 
	CalcFVFOffset( const DWORD dwFVF, const DWORD dwFVFFlag )
	{

		_ASSERT( dwFVFFlag & dwFVF ); // dwFVF doesn't have the requested flag!

		DWORD dwOffset = 0;

		// -----------------------------------------------------------------

		if ( D3DFVF_XYZ & dwFVF ) {

			if ( D3DFVF_XYZ & dwFVFFlag ) return dwOffset;

			dwOffset += sizeof(float) * 3;
			
		} else if ( D3DFVF_XYZRHW & dwFVF ) {

			if ( D3DFVF_XYZRHW & dwFVFFlag ) return dwOffset;

			dwOffset += sizeof(float) * 4;

		}

		// deal with the blend weights
		// -----------------------------------------------------------------

		if ( D3DFVF_XYZB1 == (D3DFVF_XYZB1 & dwFVF) ) {

			if ( D3DFVF_XYZB1 & dwFVFFlag ) return dwOffset;

			dwOffset += (sizeof(float) * 1);

		}

		if ( D3DFVF_XYZB2 == (D3DFVF_XYZB2 & dwFVF) ) {

			if ( D3DFVF_XYZB2 & dwFVFFlag ) return dwOffset;

			dwOffset += (sizeof(float) * 2);

		}

		if ( D3DFVF_XYZB3 == (D3DFVF_XYZB3 & dwFVF) ) {

			if ( D3DFVF_XYZB3 & dwFVFFlag ) return dwOffset;

			dwOffset += (sizeof(float) * 3);

		}

		if ( D3DFVF_XYZB4 == (D3DFVF_XYZB4 & dwFVF) ) {

			_ASSERT(false); // unhandled

			return E_FAIL;

		}

		if ( D3DFVF_XYZB5 == (D3DFVF_XYZB5 & dwFVF) ) {

			_ASSERT(false); // unhandled

			return E_FAIL;

		}

		// Deal with the normal
		// -----------------------------------------------------------------

		if ( D3DFVF_NORMAL == (D3DFVF_NORMAL & dwFVF) ) {

			if ( D3DFVF_NORMAL & dwFVFFlag ) return dwOffset;

			dwOffset += (sizeof(float) * 3);

		}

		// Deal with the point size
		// -----------------------------------------------------------------

		if ( D3DFVF_PSIZE == (D3DFVF_PSIZE & dwFVF) ) {

			if ( D3DFVF_PSIZE & dwFVFFlag ) return dwOffset;

			dwOffset += sizeof(float);

		}

		// Deal with the colors
		// -----------------------------------------------------------------

		if ( D3DFVF_DIFFUSE == (D3DFVF_DIFFUSE & dwFVF) ) {

			if ( D3DFVF_DIFFUSE & dwFVFFlag ) return dwOffset;

			dwOffset += sizeof(DWORD);

		}

		if ( D3DFVF_SPECULAR == (D3DFVF_SPECULAR & dwFVF) ) {

			if ( D3DFVF_SPECULAR & dwFVFFlag ) return dwOffset;

			dwOffset += sizeof(DWORD);

		}

		// Deal with the texture coordinates
		// -----------------------------------------------------------------

		const DWORD dwTextureFlags[ 8 ] = {
			D3DFVF_TEX1
			,D3DFVF_TEX2
			,D3DFVF_TEX3
			,D3DFVF_TEX4
			,D3DFVF_TEX5
			,D3DFVF_TEX6
			,D3DFVF_TEX7
			,D3DFVF_TEX8
		};

		for ( int i = 0; i < (sizeof(dwTextureFlags)/sizeof(dwTextureFlags[0])); i++ ) {

			if ( dwTextureFlags[i] == (dwTextureFlags[i] & dwFVF) ) {

				if ( dwTextureFlags[i] & dwFVFFlag ) return dwOffset;

				if ( D3DFVF_TEXCOORDSIZE1(i) == (D3DFVF_TEXCOORDSIZE1(i) & dwFVFFlag) ) {

					dwOffset += (sizeof(float) * 1);

				} else if ( D3DFVF_TEXCOORDSIZE2(i) == (D3DFVF_TEXCOORDSIZE2(i) & dwFVFFlag) ) {

					dwOffset += (sizeof(float) * 2);

				} else if ( D3DFVF_TEXCOORDSIZE3(i) == (D3DFVF_TEXCOORDSIZE3(i) & dwFVFFlag) ) {

					dwOffset += (sizeof(float) * 3);

				} else if ( D3DFVF_TEXCOORDSIZE4(i) == (D3DFVF_TEXCOORDSIZE4(i) & dwFVFFlag) ) {

					dwOffset += (sizeof(float) * 4);

				} else {

					_ASSERT(false); // unable to determine how many floats

				}

			}

		}

		// everything else
		// -----------------------------------------------------------------

		_ASSERT( false ); // Unhandled cases remain.

		return 0x7fffffff; // this should cause an error...

	}

	// ------------------------------------------------------------------------

	// Need generate 'box' of meshes method.

	// ------------------------------------------------------------------------

	//
	//	TranslateMeshVerts()
	//
	
	HRESULT 
	TranslateMeshVerts( LPD3DXMESH pMesh, const D3DXVECTOR3 & translation )
	{
		TranlateFilter translationFilter( translation.x, translation.y, translation.z );

		return TFilterMeshVertices( pMesh, translationFilter );
	}

	//
	//	CenterMeshOnCoordinate()
	//

	HRESULT 
	CenterMeshOnCoordinate( LPD3DXMESH pMesh, const D3DXVECTOR3 & center )
	{
		// --------------------------------------------------------------------

		LPBYTE pVertexData;

		HRESULT hr;

		if ( FAILED( hr = pMesh->LockVertexBuffer( 0, &pVertexData ) ) ) {

			return hr;

		}

		// --------------------------------------------------------------------

		D3DXVECTOR3 currentCenter;

		float radius;

		if ( FAILED( hr = D3DXComputeBoundingSphere(
			pVertexData, pMesh->GetNumVertices(), pMesh->GetFVF(),
			&currentCenter, &radius ) ) ) {

			pMesh->UnlockVertexBuffer();

			return hr;

		}

		pMesh->UnlockVertexBuffer();

		// Move the center to the axis
		// --------------------------------------------------------------------

		D3DXVECTOR3 adjustment = center - currentCenter;

		return TranslateMeshVerts( pMesh, adjustment );

	}

	// ------------------------------------------------------------------------

	//
	//	YesCreateEveryBox
	//

	struct YesCreateEveryBox {

		bool operator()( const int x, const int y, const int z ) const {

			return ((x + y + z) & 1) ? true : false;

		}

	};

	//
	//	CreateBoxOfBoxes()
	//

	HRESULT
	CreateBoxOfBoxes( 
		LPDIRECT3DDEVICE8 pd3dDevice
		,const int xCount
		,const int yCount
		,const int zCount
		,const D3DXVECTOR3 & firstBoxCenter
		,const D3DXVECTOR3 & innerBoxDimension
		,const D3DXVECTOR3 & innerBoxDelta
		,const bool bUseSameAttribute
		,const bool bCenterOnAxis
		,const DWORD dwOptions
		,const DWORD dwFVF
		,LPD3DXMESH * ppMesh
	)
	{

#if 1

		return TCreateBoxOfBoxes(
			YesCreateEveryBox()
			,pd3dDevice
			,xCount
			,yCount
			,zCount
			,firstBoxCenter
			,innerBoxDimension
			,innerBoxDelta
			,bUseSameAttribute
			,bCenterOnAxis
			,dwOptions
			,dwFVF
			,ppMesh
		);

#else

		// ----------------------------------------------------------------

		if ( !ppMesh ) {

			return E_FAIL;

		}

		*ppMesh = NULL;

		// Create the un tessellated mesh
		// ----------------------------------------------------------------

		LPD3DXMESH pBoxMesh;

		DWORD dwCopies = (xCount * yCount) * zCount;
		DWORD dwQuads = 6 * dwCopies;
		DWORD dwWantFaces = dwQuads * 2;
		DWORD dwWantVerts = dwQuads * 4;

		HRESULT hr = D3DXCreateMeshFVF(
			dwWantFaces, dwWantVerts, dwOptions, dwFVF, pd3dDevice, &pBoxMesh
		);

		if ( FAILED( hr ) ) {

			return hr;

		}

		// ----------------------------------------------------------------

		DWORD dwNumFaces = pBoxMesh->GetNumFaces();

		_ASSERT( dwWantFaces != dwNumFaces );

		DWORD dwNumVertices = pBoxMesh->GetNumVertices();

		_ASSERT( dwWantVerts != dwNumVertices );

		// Fill in the attribute table
		// ----------------------------------------------------------------

		{
			LPDWORD pAttributeData;

			if ( FAILED( hr = pBoxMesh->LockAttributeBuffer( 0, &pAttributeData ) ) ) {

				pBoxMesh->Release();

				return hr;

			}

			if ( bUseSameAttribute ) {

				ZeroMemory( pAttributeData, dwNumFaces * sizeof(DWORD) );

			} else {

				DWORD quadAttributes = dwCopies * 2;

				for ( DWORD quadFace = 0; quadFace < 6; quadFace++ ) {

					for ( DWORD attribute = 0; attribute < quadAttributes; attribute++ ) {

						*pAttributeData++ = quadFace;

					}

				}

			}

			pBoxMesh->UnlockAttributeBuffer();
		}

		// Fill in the index table
		// ----------------------------------------------------------------

		{
			LPBYTE pIndexData;

			if ( FAILED( hr = pBoxMesh->LockIndexBuffer( 0, &pIndexData ) ) ) {

				pBoxMesh->Release();

				return hr;

			}

			WORD * pIndices = (WORD *)( pIndexData );

			int numQuads = dwQuads;

			int baseIndex = 0;

			for ( int quad = 0; quad < numQuads; quad++ ) {

				*pIndices++ = (baseIndex + 3);
				*pIndices++ = (baseIndex + 0);
				*pIndices++ = (baseIndex + 1);
				*pIndices++ = (baseIndex + 3);
				*pIndices++ = (baseIndex + 1);
				*pIndices++ = (baseIndex + 2);

				baseIndex += 4;

			}

			pBoxMesh->UnlockVertexBuffer();

		}

		// Fill in the vertex table
		// ----------------------------------------------------------------

		{
			LPBYTE pVertexData;

			if ( FAILED( hr = pBoxMesh->LockVertexBuffer( 0, &pVertexData ) ) ) {

				pBoxMesh->Release();

				return hr;

			}

			DWORD fvfSize = D3DXGetFVFVertexSize( dwFVF );

			ZeroMemory(
				pVertexData
				,fvfSize * dwWantVerts
			);

			// Find the offset for the various FVF fields
			// ----------------------------------------------------------------

			DWORD dwNormalOffset = (D3DFVF_NORMAL & dwFVF) ? CalcFVFOffset(dwFVF,D3DFVF_NORMAL) : 0;

			DWORD dwUVOffset = (D3DFVF_TEX1 & dwFVF) ? CalcFVFOffset(dwFVF,D3DFVF_TEX1) : 0;

			// Fill in the verts
			// ----------------------------------------------------------------

			// Setup the reset position for the box

			D3DXVECTOR3 reset[ 8 ];

			D3DXVECTOR3 half = innerBoxDimension * 0.5f;

			// front

			reset[ 0 ].x = firstBoxCenter.x - half.x;
			reset[ 0 ].y = firstBoxCenter.y + half.y;
			reset[ 0 ].z = firstBoxCenter.z - half.z;

			reset[ 1 ].x = firstBoxCenter.x + half.x;
			reset[ 1 ].y = firstBoxCenter.y + half.y;
			reset[ 1 ].z = firstBoxCenter.z - half.z;

			reset[ 2 ].x = firstBoxCenter.x + half.x;
			reset[ 2 ].y = firstBoxCenter.y - half.y;
			reset[ 2 ].z = firstBoxCenter.z - half.z;

			reset[ 3 ].x = firstBoxCenter.x - half.x;
			reset[ 3 ].y = firstBoxCenter.y - half.y;
			reset[ 3 ].z = firstBoxCenter.z - half.z;

			// back

			reset[ 4 ].x = firstBoxCenter.x - half.x;
			reset[ 4 ].y = firstBoxCenter.y + half.y;
			reset[ 4 ].z = firstBoxCenter.z + half.z;

			reset[ 5 ].x = firstBoxCenter.x + half.x;
			reset[ 5 ].y = firstBoxCenter.y + half.y;
			reset[ 5 ].z = firstBoxCenter.z + half.z;

			reset[ 6 ].x = firstBoxCenter.x + half.x;
			reset[ 6 ].y = firstBoxCenter.y - half.y;
			reset[ 6 ].z = firstBoxCenter.z + half.z;

			reset[ 7 ].x = firstBoxCenter.x - half.x;
			reset[ 7 ].y = firstBoxCenter.y - half.y;
			reset[ 7 ].z = firstBoxCenter.z + half.z;

			// fill in the normal table

			D3DXVECTOR3 faceNormals[ 6 ] = {
					D3DXVECTOR3( +0.0f, +0.0f, -1.0f)
				,	D3DXVECTOR3( +0.0f, +1.0f, +0.0f)
				,	D3DXVECTOR3( +0.0f, +0.0f, +1.0f)
				,	D3DXVECTOR3( +0.0f, -1.0f, +0.0f)
				,	D3DXVECTOR3( -1.0f, +0.0f, +0.0f)
				,	D3DXVECTOR3( +1.0f, +0.0f, +0.0f)
			};

			// fill in the uv table (each face could have different uv's)

			D3DXVECTOR3 faceUVs[ 6 ][ 4 ] = {

				{
						D3DXVECTOR3( 0.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 1.0f, 0.0f)
					,	D3DXVECTOR3( 0.0f, 1.0f, 0.0f)
				}
				,{
						D3DXVECTOR3( 0.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 1.0f, 0.0f)
					,	D3DXVECTOR3( 0.0f, 1.0f, 0.0f)
				}
				,{
						D3DXVECTOR3( 0.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 1.0f, 0.0f)
					,	D3DXVECTOR3( 0.0f, 1.0f, 0.0f)
				}
				,{
						D3DXVECTOR3( 0.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 1.0f, 0.0f)
					,	D3DXVECTOR3( 0.0f, 1.0f, 0.0f)
				}
				,{
						D3DXVECTOR3( 0.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 1.0f, 0.0f)
					,	D3DXVECTOR3( 0.0f, 1.0f, 0.0f)
				}
				,{
						D3DXVECTOR3( 0.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 1.0f, 0.0f)
					,	D3DXVECTOR3( 0.0f, 1.0f, 0.0f)
				}
			};

			// fill in the vertex generation order

			int faceIndices[ 6 ][ 4 ] = {

					{ 0, 1, 2, 3 }		// front
				,	{ 4, 5, 1, 0 }		// top
				,	{ 7, 6, 5, 4 }		// back
				,	{ 3, 2, 6, 7 }		// bottom
				,	{ 4, 0, 3, 7 }		// left
				,	{ 1, 5, 6, 2 }		// right

			};

			// build each 'face' in the proper order

			for ( int f = 0; f < 6; f++ ) {

				D3DXVECTOR3 verts[ 8 ];

				D3DXVECTOR3 normal = faceNormals[ f ];

				D3DXVECTOR3 * pUVs = faceUVs[ f ];

				int * idx = faceIndices[ f ];

				// reset z's

				for ( int r = 0; r < 4; r++ ) { verts[ idx[ r ] ].z = reset[ idx[ r ] ].z; }

				for ( int z = 0; z < zCount; z++ ) {

					// reset y's

					for ( int r = 0; r < 4; r++ ) { verts[ idx[ r ] ].y = reset[ idx[ r ] ].y; }

					for ( int y = 0; y < yCount; y++ ) {

						// reset x's

						for ( int r = 0; r < 4; r++ ) { verts[ idx[ r ] ].x = reset[ idx[ r ] ].x; }

						for ( int x = 0; x < xCount; x++ ) {

							for ( int a = 0; a < 4; a++ ) {

								// fill in the vertex data

								float * pXYZ = (float *)pVertexData;

								*(pXYZ + 0) = verts[ idx[ a ] ].x;
								*(pXYZ + 1) = verts[ idx[ a ] ].y;
								*(pXYZ + 2) = verts[ idx[ a ] ].z;

								// normals

								if ( D3DFVF_NORMAL & dwFVF ) {

									float * pNormal = (float *)(pVertexData + dwNormalOffset);

									*(pNormal + 0) = normal.x;
									*(pNormal + 1) = normal.y;
									*(pNormal + 2) = normal.z;

								}

								// UV's

								if ( D3DFVF_TEX1 & dwFVF ) {

									float * pUV = (float *)(pVertexData + dwUVOffset);

									*(pUV + 0) = pUVs[ a ].x;
									*(pUV + 1) = pUVs[ a ].y;

								}

								// move to the next vertex

								pVertexData += fvfSize;
			
								// advance x's

								verts[ idx[ a ] ].x += innerBoxDelta.x;
							
							}

						}

						// advance y's

						for ( int a = 0; a < 4; a++ ) { verts[ idx[ a ] ].y += innerBoxDelta.y; }

					}

					// advance z's

					for ( int a = 0; a < 4; a++ ) { verts[ idx[ a ] ].z += innerBoxDelta.z; }

				}

			}

			pBoxMesh->UnlockVertexBuffer();

		}

		// ----------------------------------------------------------------

		if ( bCenterOnAxis ) {

			if ( FAILED( hr = CenterMeshOnCoordinate( pBoxMesh, D3DXVECTOR3(0.0f,0.0f,0.0f) ) ) ) {

				pBoxMesh->Release();

				return hr;

			}

		}

		// ----------------------------------------------------------------

		*ppMesh = pBoxMesh;

		return S_OK;

#endif

	}

	// ------------------------------------------------------------------------

}; // namespace BPT

