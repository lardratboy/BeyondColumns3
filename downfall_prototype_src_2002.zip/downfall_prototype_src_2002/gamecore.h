// gamecore.h: -- implements the core game logic
//
//	Copyright (c) 2002, Brad P. Taylor, LLC
//
//	All rights reserved, unauthorized reproduction prohibited
//
//	-- FILE NOTES --
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMECORE_H__4A70CE15_944D_4d8b_9C18_AD7B2E4360A4__INCLUDED_)
#define AFX_GAMECORE_H__4A70CE15_944D_4d8b_9C18_AD7B2E4360A4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

/*

	<<< FUTURE STEP >>>

	It would be nice to be able to make uber pieces that drop as a group.  These
	pieces are worth big points and can effect the game in a big way.  This would 
	mean that movers need to know if they are part of a group and if so then the
	group members land at the same vertical spot relative to their group.  This means
	that some group's can't be merged!!!!

	A cheap version of the drop as a group could be accomplished by having pieces
	that are empty to searches and input but solid to the mover detection.  This really
	doesn't change much at all, it would just require that the reserve system be modified
	so that it starts at a lower number than the phantom blocks.  Could group movement
	be done via detecting unsupported groups and 'exploding' the phantom pieces? Whole
	line support (or lack of support) could be detected by a shape that represents a
	whole row of phantom shapes, they could mark the match imediately. 	Then all that 
	would be necessary is that movers retain their group notion.


*/

// ----------------------------------------------------------------------------

#include "gametypes.h"

// ----------------------------------------------------------------------------

namespace DOWNFALL {

	// ------------------------------------------------------------------------

	//
	//	TPuzzleGameCore
	//

	template<
		class RENDERER
		,class INPUT
		,const int MAX_ROW_COUNT = 21
		,const int MAX_COL_COUNT = 9
		,const int _FRACTION_SHIFT = 8
		,const int _FRACTION_MASK = ((1 << _FRACTION_SHIFT) - 1)
	>
	class TPuzzleGameCore {

	public:

		// traits/info
		// --------------------------------------------------------------------

		typedef RENDERER renderer_type;

		typedef INPUT input_type;

		friend input_type;
		
		friend renderer_type;

		enum {

			MAX_ROWS			= MAX_ROW_COUNT
			,MAX_COLS			= MAX_COL_COUNT
			,MAX_ELEMENTS		= ((MAX_ROW_COUNT) * (MAX_COL_COUNT))
			,FRACTION_SHIFT		= _FRACTION_SHIFT
			,FRACTION_MASK		= _FRACTION_MASK

		};

	private:

		// --------------------------------------------------------------------

		struct SGroup {

			// -------------------------------------

			struct Member {

				struct Member * pNext;

				int row;
				int col;

				Member() {

					Reset();

				}

				void Reset() {

					pNext = 0;
					row = 0;
					col = 0;

				}

			};

			// -------------------------------------

			struct SGroup * pNext;

			Member * pMembersHead;

			int memberCount;

			bool bActivated; // this should be one of many 'flags'

			// -------------------------------------

			SGroup() {

				Reset();

			}

			void Reset() {

				bActivated = false;

				pMembersHead = 0;

				memberCount = 0;

				pNext = 0;

			}

		};

		SGroup * m_pActiveGroupsListHead;

		SGroup * m_pGroup[ MAX_ROWS ][ MAX_COLS ];

		SGroup m_GroupStorage[ MAX_ELEMENTS ]; 

		SGroup * m_GroupStack[ MAX_ELEMENTS ]; 

		int m_GroupStackPtr;

		SGroup::Member m_MemberStorage[ MAX_ELEMENTS ];

		SGroup::Member * m_MemberStack[ MAX_ELEMENTS ];

		int m_MemberStackPtr;

		// --------------------------------------------------------------------

		int m_nGroupActivationCount;

		int m_GroupSetTimerValue;

		// --------------------------------------------------------------------

		class CElementTimer {

		private:

			int m_SetLimit;
			int m_Current;

		public:

			CElementTimer() : m_SetLimit(0), m_Current(0) { /* empty */ }

			void Reset() {

				m_SetLimit = 0;

				m_Current = 0;

			}

			int Limit() const {

				return m_SetLimit;

			}

			int Current() const {

				return m_Current;

			}

			bool Active() const {

				return (0 != m_SetLimit);

			}

			// returns true if it's started a new one...

			bool StartTimer( const int limit ) {

				bool bNewLimit = (0 != limit);

				if ( m_SetLimit ) {

					bNewLimit = false;

				}

				m_SetLimit = max( limit, m_SetLimit );

				return bNewLimit;

			}

			bool Tick() {

				if ( m_SetLimit ) {

					if ( ++m_Current >= m_SetLimit ) {

						Reset();

						return true;

					}

				}

				return false;

			}

		};

		CElementTimer m_MatchTimer[ MAX_ROWS ][ MAX_COLS ];

		int m_RowHasNMatchTimers[ MAX_ROWS ];

		// Shape set (the shape database is terminated by a null pElements)
		// --------------------------------------------------------------------

		const Shape * m_pCurrentShapes;

		// Mover related elements (REFACTOR!!!)
		// --------------------------------------------------------------------

		Mover * m_Movers[ MAX_COLS ];

		Mover m_MoverStorage[ MAX_ELEMENTS ]; 

		Mover * m_MoverStack[ MAX_ELEMENTS ]; 

		int m_MoverStackPtr;

		// board options
		// --------------------------------------------------------------------

		int m_HiddenRows;
		int m_ActiveRows;
		int m_ActiveCols;
		int m_LastRow;
		int m_LastCol;

		Location m_Locations[ MAX_ROWS ][ MAX_COLS ];

		PieceType m_Board[ MAX_ROWS ][ MAX_COLS ];

		int m_Match[ MAX_ROWS ][ MAX_COLS ];

		int m_MatchCount[ MAX_COLS ];

		int m_FP_PerframeDelta;

		int m_FP_UserPieceDelta;

		bool m_bNeedToCheckForMatches;

		int m_nPointsCollectedThisFrame;

		int m_nTotalMatchesThisFrame;

		int m_ScoreMultiplier;

	public:

		void ResetGameInternals() {

			// ----------------------------------------------------------------

			m_nPointsCollectedThisFrame = 0;
			m_nTotalMatchesThisFrame = 0;
			m_ScoreMultiplier = 1;

			// setup the group system (need to refactor!!!)
			// ----------------------------------------------------------------

			m_pActiveGroupsListHead = 0;

			{
				for ( int r = 0; r < MAX_ROWS; r++ ) {

					for ( int c = 0; c < MAX_COLS; c++ ) {

						m_pGroup[ r ][ c ] = 0;

					}

				}

				// fill in the group stack
			}

			m_GroupStackPtr = MAX_ELEMENTS;

			m_MemberStackPtr = MAX_ELEMENTS;

			{
				for ( int i = 0; i < MAX_ELEMENTS; i++ ) {

					m_GroupStorage[ i ].Reset();
					m_GroupStack[ i ] = &m_GroupStorage[ i ];

					m_MemberStorage[ i ].Reset();
					m_MemberStack[ i ] = &m_MemberStorage[ i ];

				}

			}
			// Setup the mover stack
			// ----------------------------------------------------------------

			m_MoverStackPtr = MAX_ELEMENTS;

			{
				for ( int i = 0; i < MAX_ELEMENTS; i++ ) {

					m_MoverStorage[ i ].Reset();

					m_MoverStack[ i ] = &m_MoverStorage[ i ];

				}

			}

			// clear the mover information
			// ----------------------------------------------------------------

			{
				for ( int c = 0; c < MAX_COLS; c++ ) {

					m_Movers[ c ] = 0;

					m_MatchCount[ c ] = 0;

				}
			}

			// clear the board, match and reset the timers
			// ----------------------------------------------------------------

			{
				for ( int r = 0; r < MAX_ROWS; r++ ) {

					m_RowHasNMatchTimers[ r ] = 0;

					for ( int c = 0; c < MAX_COLS; c++ ) {

						m_Board[ r ][ c ].Empty();

						m_Match[ r ][ c ] = 0;

						m_MatchTimer[ r ][ c ].Reset();

					}
				}
			}

		}

		//
		//	TPuzzleGameCore()
		//

		TPuzzleGameCore() {

			m_HiddenRows = 3;
			m_nGroupActivationCount = 4;
			m_GroupSetTimerValue = 8;
			m_pCurrentShapes = 0;
			m_ActiveRows = 0;
			m_ActiveCols = 0;
			m_LastRow = 0;

			ResetGameInternals();

			// setup the simple variables

			m_FP_PerframeDelta = (1 << FRACTION_SHIFT) / 10; //5; //20;

			m_FP_UserPieceDelta = 0;

			m_bNeedToCheckForMatches = false;

		}

		// Setup methods
		// ---------------------------------------------------------------------

		bool SetPerFrameMoverDelta( const int nFrames ) {

			if ( 0 >= nFrames ) {

				return false;

			}

			m_FP_PerframeDelta = (1 << FRACTION_SHIFT) / nFrames;

			return true;

		}

		bool SetupGroupActivationPolicy( const int nCount, const int nTimerValue ) {

			m_nGroupActivationCount = nCount;

			m_GroupSetTimerValue = nTimerValue;

			return true;

		}

		bool SetShapeSet( const Shape * pShapes ) {

			m_pCurrentShapes = pShapes;

			return true;

		}

		bool SetDimensions(
			const int rows, const int cols, const int hiddenRows
		) {

			if ( 
				((0 >= rows) || (MAX_ROWS < rows)) || 
				((0 >= cols) || (MAX_COLS < cols)) ||
				(0 >= (rows - hiddenRows))
			) {

				// ATLTRACE( "Invalid dimension %d, %d limit %d, %d\n", rows, cols, MAX_ROWS, MAX_COLS );

				return false;

			}

			// setup the row/col limits
			// ----------------------------------------------------------------

			m_HiddenRows = hiddenRows;
			m_ActiveRows = rows;
			m_ActiveCols = cols;
			m_LastRow = rows - 1;
			m_LastCol = cols - 1;

			// Prepare the board etc...
			// ----------------------------------------------------------------

			return true;

		}

		// ---------------------------------------------------------------------

		inline void validate_row_col_ASSERT( const int row, const int col ) const {

			_ASSERT( (0 <= row) && (m_LastRow >= row) );
			_ASSERT( (0 <= col) && (m_LastCol >= col) );

		}

		// low level table access methods
		// ---------------------------------------------------------------------

		inline PieceType & _BoardElement( const int row, const int col ) {

			validate_row_col_ASSERT( row, col );

			return m_Board[ row ][ col ];

		}

		inline const PieceType & _BoardElement( const int row, const int col ) const {

			validate_row_col_ASSERT( row, col );

			return m_Board[ row ][ col ];

		}

		inline int & _MatchElement( const int row, const int col ) {

			validate_row_col_ASSERT( row, col );

			return m_Match[ row ][ col ];

		}

		//
		//	GetLocation()
		//

		inline void GetLocation( const int row, const int col, Location & pos ) const {

			validate_row_col_ASSERT( row, col );

			pos = m_Locations[ row ][ col ];

		}

		//
		//	SetLocation()
		//

		inline void SetLocation( const int row, const int col, const Location & pos ) {

			validate_row_col_ASSERT( row, col );

			m_Locations[ row ][ col ] = pos;

		}

		//
		//	SetupLocations()
		//

		void SetupLocations(
			const int startX, const int startY
			,const int rowStepX, const int rowStepY
			,const int colStepX, const int colStepY
		) {

			int rowX = startX;

			int rowY = startY;

			for ( int r = 0; r < m_ActiveRows; r++ ) {

				int x = rowX;
				int y = rowY;

				rowX += rowStepX;
				rowY += rowStepY;

				for ( int c = 0; c < m_ActiveCols; c++ ) {

					Location location;

					location.x = x;
					location.y = y;
					location.z = 0;

					SetLocation( r, c, location );

					x += colStepX;
					y += colStepY;

				}

			}

		}

		// Board methods
		// ---------------------------------------------------------------------

		//
		//	GetPieceMatchID()
		//

		inline int GetPieceMatchID( const int row, const int col ) const {

			return _BoardElement( row, col ).ID();

		}

		//
		//	IsBoardPieceActive()
		//

		inline bool IsBoardPieceActive( const int row, const int col ) const {

			return !_BoardElement( row, col ).IsDisabled();

		}

		//
		//	IsBoardElementOccupied()
		//

		inline bool IsBoardElementOccupied( const int row, const int col ) const {

			return !_BoardElement( row, col ).IsEmpty();

		}

		//
		//	CanInputPenetrate()
		//

		inline bool CanInputPenetrate( const int row, const int col ) const {

			const PieceType & piece = _BoardElement( row, col );

			if ( piece.IsEmpty() ) {

				return true;

			}

			return piece.InputCanPenetrate();

		}

		//
		//	CanMoverPenetrate()
		//

		inline bool CanMoverPenetrate( const int row, const int col ) const {

			const PieceType & piece = _BoardElement( row, col );

			return ( piece.IsEmpty() || piece.IsReserved() );

		}

		//
		//	CanBoardElementBeGrouped()
		//

		inline bool CanBoardElementBeGrouped( const int row, const int col ) const {

			return _BoardElement( row, col ).CanBeGrouped();

		}

		//
		//	CanPieceBeMatched()
		//

		inline bool CanPieceBeMatched( const int row, const int col ) const {

			return _BoardElement( row, col ).CanMatch();

		}

		// Borad group methods
		// --------------------------------------------------------------------

		//
		//	GetBoardGroup()
		//

		inline SGroup * GetBoardGroup( const int row, const int col ) const {

			validate_row_col_ASSERT( row, col );

			return m_pGroup[ row ][ col ];

		}

		//
		//	CreateNewGroup()
		//

		SGroup * CreateNewGroup() {

			_ASSERT( 0 < m_GroupStackPtr );

			SGroup * pGroup = m_GroupStack[ --m_GroupStackPtr ];

			pGroup->pNext = m_pActiveGroupsListHead;

			m_pActiveGroupsListHead = pGroup;

			return pGroup;

		}

		//
		//	UnlinkGroupFromActiveList()
		//

		void UnlinkGroupFromActiveList( SGroup * pGroup ) {

			_ASSERT( m_pActiveGroupsListHead );

			SGroup ** pRef = &m_pActiveGroupsListHead;

			for ( SGroup * pSearch = m_pActiveGroupsListHead; pSearch; pSearch = pSearch->pNext ) {

				if ( pGroup == pSearch ) {

					break;

				}

				pRef = &pSearch->pNext;

			}

			_ASSERT( pGroup == *pRef );

			*pRef = pGroup->pNext;

		}

		//
		//	DestroyGroup()
		//

		void DestroyGroup( SGroup * pGroup ) {

			// Make sure there are no members and that there are groups
			// ----------------------------------------------------------------

			_ASSERT( 0 == pGroup->pMembersHead );

			// unlink from the active list
			// ----------------------------------------------------------------

			UnlinkGroupFromActiveList( pGroup );

			// Put back on the available stack
			// ----------------------------------------------------------------

			_ASSERT( MAX_ELEMENTS > m_GroupStackPtr );

			pGroup->Reset();

			m_GroupStack[ m_GroupStackPtr++ ] = pGroup;

		}

		//
		//	RemoveFromGroup()
		//

		void RemoveFromGroup( const int row, const int col ) {

			validate_row_col_ASSERT( row, col );

			SGroup * pGroup = m_pGroup[ row ][ col ];

			if ( pGroup ) {

				// need to unlink this node from the group
				// ------------------------------------------------------------

				_ASSERT( pGroup->pMembersHead );

				SGroup::Member ** pRef = &pGroup->pMembersHead;

				for ( SGroup::Member * pMember = pGroup->pMembersHead; pMember; pMember = pMember->pNext ) {

					if ( (row == pMember->row) && (col == pMember->col) ) {

						break;

					}

					pRef = &pMember->pNext;

				}

				// Make sure that the element was a part of the group...
				// ------------------------------------------------------------

				_ASSERT( (row == (*pRef)->row) && (col == (*pRef)->col) );

				// unlink from the group
				// ------------------------------------------------------------

				*pRef = pMember->pNext;

				// push back onto the member stack
				// ------------------------------------------------------------

				_ASSERT( MAX_ELEMENTS > m_MemberStackPtr );

				pMember->Reset();

				m_MemberStack[ m_MemberStackPtr++ ] = pMember;

				// Now unlink the group from the element
				// ------------------------------------------------------------

				m_pGroup[ row ][ col ] = 0;

				_ASSERT( 0 < pGroup->memberCount );

				--pGroup->memberCount;

				// if this was the last reference then destroy the group
				// ------------------------------------------------------------

				if ( !pGroup->memberCount ) {

					DestroyGroup( pGroup );

				}

			}

		}

		//
		//	AddToGroup
		//

		void AddToGroup( const int row, const int col, SGroup * pGroup ) {

			validate_row_col_ASSERT( row, col );

			SGroup * pOldGroup = m_pGroup[ row ][ col ];

			if ( pGroup != pOldGroup ) {

				if ( pOldGroup ) {

					// SHOULD THIS BE AN ASSERT???

					RemoveFromGroup( row, col );

				}

				// attach the group to the element
				// ------------------------------------------------------------

				m_pGroup[ row ][ col ] = pGroup;

				++pGroup->memberCount;

				// Make a new group member
				// ------------------------------------------------------------

				_ASSERT( 0 < m_MemberStackPtr );

				SGroup::Member * pMember = m_MemberStack[ --m_MemberStackPtr ];

				pMember->row = row;

				pMember->col = col;

				pMember->pNext = pGroup->pMembersHead;

				pGroup->pMembersHead = pMember;

			}

		}

		//
		//	ReplaceGroupWithGroup()
		//

		void ReplaceGroupWithGroup( SGroup * pFindGroup, SGroup * pReplaceGroup ) {

			SGroup::Member * pMember = pFindGroup->pMembersHead;

			for ( ; pMember ; pMember = pMember->pNext ) {

				m_pGroup[ pMember->row ][ pMember->col ] = pReplaceGroup;

			}

		}

		//
		//	MergeTwoGroups()
		//

		SGroup * MergeTwoGroups( SGroup * pGroupA, SGroup * pGroupB ) {

			// if not in proper order then call self (single depth recursion)
			// ----------------------------------------------------------------

			if ( pGroupA->memberCount > pGroupB->memberCount ) {

				return MergeTwoGroups( pGroupB, pGroupA );

			}

			// Find the tail
			// ----------------------------------------------------------------

			SGroup::Member ** pRef = &pGroupA->pMembersHead;

			while ( *pRef ) {

				pRef = &(*pRef)->pNext;

			}

			// Combine the lists and then replace the references to the soon
			// to be removed list with the remaining list.
			// ----------------------------------------------------------------

			*pRef = pGroupB->pMembersHead;

			pGroupA->memberCount += pGroupB->memberCount;

			if ( pGroupB->bActivated ) {

				pGroupA->bActivated = true;

			}

			ReplaceGroupWithGroup( pGroupB, pGroupA );

			// unlink the group from the active list
			// -------------------------------------------------------------------------

			UnlinkGroupFromActiveList( pGroupB );

			// now put the group back into the free list.
			// -------------------------------------------------------------------------

			_ASSERT( MAX_ELEMENTS > m_GroupStackPtr );

			pGroupB->Reset();

			m_GroupStack[ m_GroupStackPtr++ ] = pGroupB;

			return pGroupA;
			
		}

		// Match related methods
		// --------------------------------------------------------------------

		//
		//	GetElementMatchCount()
		//

		inline int GetElementMatchCount( const int row, const int col ) {

			return _MatchElement( row, col );

		}

		inline int GetElementMatchCount( const int row, const int col ) const {

			return _MatchElement( row, col );

		}

		//
		//	SetElementMatchCount()
		//

		inline void SetElementMatchCount( const int row, const int col, const int count ) {

			_MatchElement( row, col ) = count;

		}

		//
		//	IncrementElementMatchCount()
		//

		inline void IncrementElementMatchCount( const int row, const int col ) {

			++_MatchElement( row, col );

			++m_MatchCount[ col ];

			// collect points here?

		}

		// Timer related methods
		// --------------------------------------------------------------------

		inline CElementTimer & _ElementMatchTimer( const int row, const int col ) {

			validate_row_col_ASSERT( row, col );

			return m_MatchTimer[ row ][ col ];

		}

		inline const CElementTimer & _ElementMatchTimer( const int row, const int col ) const {

			validate_row_col_ASSERT( row, col );

			return m_MatchTimer[ row ][ col ];

		}

		inline void StartElementTimer( const int row, const int col, const int timerValue ) {

			if ( _ElementMatchTimer( row, col ).StartTimer( timerValue ) ) {

				++m_RowHasNMatchTimers[ row ];

			}

		}

		inline bool DoesElementHaveTimer( const int row, const int col ) const {

			return _ElementMatchTimer( row, col ).Active();

		}

		// Semi-policy objects (knows about sprites/tiles etc)
		// ---------------------------------------------------------------------

		//
		//	GetFreeMover()
		//

		Mover * GetFreeMover() {

			_ASSERT( 0 < m_MoverStackPtr );

			return m_MoverStack[ --m_MoverStackPtr ];

		}

		//
		//	ReleaseMover()
		//

		void ReleaseMover( Mover * pMover ) {

			_ASSERT( MAX_ELEMENTS > m_MoverStackPtr );

			pMover->Reset();

			m_MoverStack[ m_MoverStackPtr++ ] = pMover;

		}

		//
		//	SetMoverLocation()
		//

		void SetMoverLocation( Mover * pMover, const Location & pos ) {

			pMover->location = pos;

		}

		//
		//	MakeMover()
		//

		Mover * MakeMover(
			const int row
			,const int col
			,const PieceType & pieceType
			,const DWORD dwFlags
		) {

			Mover * pMover = GetFreeMover();

			_ASSERT( 0 != pMover );

			pMover->pieceType = pieceType;

			pMover->dwFlags = dwFlags;

			if ( Mover::MF_FROM_INPUT & dwFlags ) { // set the piece 'source' 4/29/02

				pMover->pieceType.SetFromInput( true );

			} else {

				pMover->pieceType.SetFromInput( false );

			}

			pMover->pieceType.IncreaseStillCounter( -pMover->pieceType.StillCounter() ); // 4/17/02

			pMover->FP_boardRow = row << FRACTION_SHIFT; // refactor into fixed point class!

			pMover->FP_delta = 0;

			Location location;

			GetLocation( row, col, location );

			SetMoverLocation( pMover, location );

			return pMover;

		}

		//
		//	BoardHasMovers()
		//

		bool BoardHasMovers() const {

			for ( int col = 0; col < m_ActiveCols; col++ ) {

				if ( m_Movers[ col ] ) {

					return true;

				}

			}

			return false;

		}

		// --------------------------------------------------------------------

		//
		//	SetBoardPiece()
		//

		void SetBoardPiece( const int row, const int col, const PieceType & pieceType ) {

			_BoardElement( row, col ) = pieceType;

			//	CALCULATE PIECE CONNECTIVITY...

		}

		//
		//	ClearBoardPiece()
		//

		void ClearBoardPiece( const int row, const int col ) {

			_BoardElement( row, col ).Empty();

			// remove CONNECTIVITY for all neighbors

		}

		// ====================================================================

		//
		//	BOARDPOS
		//

		struct BOARDPOS {

			int row;
			int col;

		};

		//
		//	WrapAroundAwareMakeBoardPos()
		//

		inline BOARDPOS WrapAroundAwareMakeBoardPos(
			const int baseRow
			,const int baseCol
			,const ShapeElement * pElement
		)  {

			BOARDPOS boardPos;

			// handle the ROW calculation
			// ----------------------------------------------------------------

			boardPos.row = baseRow + pElement->rowOffset;

			if ( 0 > boardPos.row ) {

				boardPos.row += m_LastRow;

			}

			if ( m_LastRow < boardPos.row ) {

				boardPos.row = boardPos.row - m_LastRow - 1;

			}

			_ASSERT( (0 <= boardPos.row) && (m_LastRow >= boardPos.row) );

			// handle the COL calculation
			// ----------------------------------------------------------------

			boardPos.col = baseCol + pElement->colOffset;

			if ( 0 > boardPos.col ) {

				boardPos.col += m_LastCol;

			}

			if ( m_LastCol < boardPos.col ) {

				boardPos.col = boardPos.col - m_LastCol - 1;

			}

			_ASSERT( (0 <= boardPos.col) && (m_LastCol >= boardPos.col) );

			// finally return our board position
			// ----------------------------------------------------------------

			return boardPos;

		}

		// ====================================================================

		//
		//	FoundShapeAt()
		//
		//	-- returns count of 'new' matches
		//

		int FoundShapeAt( const Shape * pShape, const int baseRow, const int baseCol ) {

	// ================================================================
	// Trigger related events
	// ================================================================

			SGroup * pGroup = 0;

			int newMatchCount = 0;

			// Scan the shape searching for a group and/or marking matches
			// ----------------------------------------------------------------

			{
				const ShapeElement * pElement = pShape->pElements;

				int elementCount = pShape->elementCount;

				int setTimerValue = pShape->setTimerValue;

				DWORD dwFlags = pShape->dwFlags;

				for ( int e = 0; e < elementCount; e++ ) {

					BOARDPOS boardPos = WrapAroundAwareMakeBoardPos(
						baseRow, baseCol, pElement
					);

					// deal with simple settings
					// --------------------------------------------------------

					if ( Shape::MARKS_PIECES & dwFlags ) {

						// check to see if this is a new match

						if ( 0 == GetElementMatchCount( boardPos.row, boardPos.col ) ) {

							if ( CollectPointsForElement( boardPos.row, boardPos.col ) ) {

								++newMatchCount;

							}

						}

						IncrementElementMatchCount( boardPos.row, boardPos.col );

					}

					if ( (Shape::SETS_TIMER & dwFlags) || (ShapeElement::ELEMENT_SETS_TIMER & pElement->dwFlags)  ) {

						// check to see if this is a new match

						if ( !DoesElementHaveTimer( boardPos.row, boardPos.col ) ) {

							if ( CollectPointsForElement( boardPos.row, boardPos.col ) ) {

								++newMatchCount;

							}

						}

						StartElementTimer( boardPos.row, boardPos.col, setTimerValue );

					}

					// should group setting be controlled by shapes????
					// --------------------------------------------------------

					if ( Shape::MAKES_GROUPS & dwFlags ) {

						SGroup * pFoundGroup = GetBoardGroup( boardPos.row, boardPos.col );
	
						if ( pFoundGroup ) {

							if ( pGroup && (pGroup != pFoundGroup) ) {

								pFoundGroup = MergeTwoGroups( pGroup, pFoundGroup );

							}

							pGroup = pFoundGroup;
	
						}

					}

					++pElement;

				}

			}

			// If we are finding groups then assign the shape area to a group
			// ----------------------------------------------------------------

			if ( Shape::MAKES_GROUPS & pShape->dwFlags ) {

				if ( !pGroup ) {

					pGroup = CreateNewGroup();

				}

				// Add elements to the group 

				const ShapeElement * pElement = pShape->pElements;

				int elementCount = pShape->elementCount;

				for ( int e = 0; e < elementCount; e++ ) {
	
					BOARDPOS boardPos = WrapAroundAwareMakeBoardPos(
						baseRow, baseCol, pElement
					);

					AddToGroup( boardPos.row, boardPos.col, pGroup );

					++pElement;

				}

				// activate the group if this is a 'special' shape.

				if ( Shape::ACTIVATE_GROUP == (Shape::ACTIVATE_GROUP & pShape->dwFlags) ) {

					pGroup->bActivated = true;

				}

			}

			return newMatchCount;

		}
	
		//
		//	MatchShape()
		//
	
		int MatchShape(
			const Shape * pShape
			,const bool bWrapRows
			,const bool bWrapCols
		) {

			int newMatchCount = 0;

			int matchIDs[ ShapeElement::MATCH_SET_COUNT ];
	
			int searchRows = m_ActiveRows - (bWrapRows ? 0 : (pShape->rows - 1));

			int searchCols = m_ActiveCols - (bWrapCols ? 0 : (pShape->cols - 1));

			int elementCount = pShape->elementCount;

			bool bDontAcceptMatchedElements = (Shape::ONLY_NEW_MATCHES & pShape->dwFlags) ? true : false;

			bool bShapeMakesGroups = (Shape::MAKES_GROUPS & pShape->dwFlags) ? true : false;
	
			for ( int r = 0; r < searchRows; r++ ) {
	
				for ( int c = 0; c < searchCols; c++ ) {

					const ShapeElement * pElement = pShape->pElements;
	
					int matchCount = 0;
	
					for ( int e = 0; e < elementCount; e++ ) {
	
						int shapeMatchID = pElement->matchID;
	
						BOARDPOS boardPos = WrapAroundAwareMakeBoardPos(
							r, c, pElement
						);

						// ----------------------------------------------------

						if ( !IsBoardPieceActive( boardPos.row, boardPos.col ) ) {

							break;

						}

						if ( bDontAcceptMatchedElements ) {

							if ( DoesElementHaveTimer( boardPos.row, boardPos.col ) ) {

								break;

							}

						}

						if ( !CanPieceBeMatched( boardPos.row, boardPos.col ) ) {

							break;

						}

						// ----------------------------------------------------

		// need to check the piece is a member of a group
		// and if so it needs to check the shape to see if
		// it is compatible with the operation.  For instance
		// a bigger group shouldn't break into the smaller
		// elements.  It's also important for the shape
		// processing to be done in a prioritized manor
		// so that larger shapes are processed first.

						if ( bShapeMakesGroups ) {

							if ( !CanBoardElementBeGrouped( boardPos.row, boardPos.col ) ) {

								break;

							}

						}

						// ----------------------------------------------------

						if ( 0 > shapeMatchID ) {

							if ( ShapeElement::MATCH_SET_COUNT > (-shapeMatchID) ) {

								int pieceID = GetPieceMatchID( boardPos.row, boardPos.col );

								if ( pieceID ) {

									matchIDs[ -shapeMatchID ] = pieceID;

								} else {

									matchIDs[ -shapeMatchID ] = -1;

								}

								++matchCount;

							} else {

								int matchAgainst = -(shapeMatchID + ShapeElement::MATCH_SET_COUNT);

								if ( GetPieceMatchID( boardPos.row, boardPos.col ) == matchAgainst ) {

									++matchCount;

								}

							}
	
						} else if ( 0 < shapeMatchID ) {
	
							_ASSERT( ShapeElement::MATCH_SET_COUNT > shapeMatchID );
	
							if ( GetPieceMatchID( boardPos.row, boardPos.col ) == matchIDs[ shapeMatchID ] ) {
	
								++matchCount;
	
							} else {
	
								break;
	
							}
	
						} else {
	
							if ( GetPieceMatchID( boardPos.row, boardPos.col ) ) {
	
								++matchCount;
	
							} else {
	
								break;
	
							}
	
						}
	
						++pElement;
	
					}
	
					if ( matchCount == elementCount ) {
	
						newMatchCount += FoundShapeAt( pShape, r, c );
	
					}
	
				}
	
			}

			return newMatchCount;
	
		}

		// Get position based on 'fractional' postion
		// --------------------------------------------------------------------

		//
		//	FPCalcPosition()
		//

		void FPCalcPosition( const int FP_row, const int col, Location & pos ) {

			// Find the positions to lerp
			// ----------------------------------------------------------------

			int t = FP_row & FRACTION_MASK;

			int a = FP_row >> FRACTION_SHIFT;

			int b = a + 1;

			a = max( 0, min( a, m_LastRow ) );
			b = max( 0, min( b, m_LastRow ) );

			// Lerp all the coordinate
			// ----------------------------------------------------------------

			Location locationA, locationB;

			GetLocation( a, col, locationA );
			GetLocation( b, col, locationB );

			pos.x = 
				(((locationB.x - locationA.x) * t) >> FRACTION_SHIFT) + locationA.x;

			pos.y = 
				(((locationB.y - locationA.y) * t) >> FRACTION_SHIFT) + locationA.y;

			pos.z = 
				(((locationB.z - locationA.z) * t) >> FRACTION_SHIFT) + locationA.z;

		}

		// Mover reserve methods
		// --------------------------------------------------------------------

		//
		//	ReserveMoverElement()
		//

		void ReserveMoverElement( Mover * pMover, const int col ) {

			_BoardElement( (pMover->FP_boardRow >> FRACTION_SHIFT), col ).Reserve();

		}

		//
		//	UnreserveMoverElement()
		//

		void UnreserveMoverElement( Mover * pMover, const int col ) {

			_BoardElement( (pMover->FP_boardRow >> FRACTION_SHIFT), col ).UnReserve();

		}

		// Handle movers
		// --------------------------------------------------------------------

		//
		//	HandleMovers()
		//

		void HandleMovers() {

			int FP_delta = m_FP_PerframeDelta + m_FP_UserPieceDelta;

			for ( int col = 0; col < m_ActiveCols; col++ ) {

				const Mover * pLastActiveProcessedMover = 0;

				Mover ** ppPrev = &m_Movers[ col ];

				Mover * pNext = 0;

				for ( Mover * pMover = m_Movers[ col ]; 0 != pMover; pMover = pNext ) {

					UnreserveMoverElement( pMover, col );

					pNext = pMover->pNext;

					pMover->FP_delta += FP_delta;

					pMover->FP_boardRow += pMover->FP_delta;

					// handle overtake condition
					// -----------------------------------------------------------------------

					if ( pLastActiveProcessedMover ) { // there was a mover below us...

						int elementBottom = pMover->FP_boardRow + (1 << FRACTION_SHIFT) - 1;

						if ( pLastActiveProcessedMover->FP_boardRow < elementBottom ) {

							int overtakeAmount = (elementBottom - pLastActiveProcessedMover->FP_boardRow);

							pMover->FP_boardRow -= overtakeAmount;

						}

					}

					// Now figure out which row we are really in and validate
					// --------------------------------------------------------

					int row = pMover->FP_boardRow >> FRACTION_SHIFT;

					if ( 0 > row ) {

						// ATLTRACE( "Off-board mover %p\n", pMover );

						continue;

					}

					// Make sure we haven't moved too far
					// --------------------------------------------------------

					if ( m_ActiveRows <= row ) {

						row = m_LastRow;

						pMover->FP_boardRow = row << FRACTION_SHIFT;

					}

					// if occupied move up until free position is found.
					// --------------------------------------------------------

					if ( !CanMoverPenetrate( row, col ) ) {

						for ( int r = (row + 1); 0 <= --r; ) {

							if ( CanMoverPenetrate( r, col ) ) {

								pMover->FP_boardRow = r << FRACTION_SHIFT;

								row = r;

								break;

							}

						}

						if ( !CanMoverPenetrate( row, col ) ) {

							// ATLTRACE( "Board is FULL? skipping mover %p landing.\n", pMover );

							continue;

						}

					}

					// Check for landing
					// --------------------------------------------------------

					bool bLand = (m_LastRow == row);

					if ( !bLand ) {

						bLand = (!CanMoverPenetrate( row + 1, col ));

					}

					if ( bLand ) {

						// request match check

						m_bNeedToCheckForMatches = true;

	// ================================================================
	// Trigger related events
	// ================================================================

						// Setup board information for this piece
						// ----------------------------------------------------

#if 1
						{
							int jiggle = (rand() % 8) - 2;

							pMover->pieceType.SetStillCounter( jiggle );

							// transfer the jiggle amount to the neighbors
							// stopping if we encounter an empty slot

							if ( jiggle < 1 ) {

								jiggle = 1;

							}

							for ( int r = row + 1; r <= m_LastRow; r++ ) {

								if ( !_BoardElement( r, col ).ID() ) {

									break;

								}

								int currentJiggle = _BoardElement( r, col ).StillCounter();

								int newJiggle = (jiggle + (rand() % 8) - 2);

								if ( currentJiggle > newJiggle ) {

									_BoardElement( r, col ).SetStillCounter( max( 0, newJiggle ) );

								}

								jiggle *= 2;

							}

						}
#endif

						SetBoardPiece( row, col, pMover->pieceType );

						// Remove and release the mover
						// ----------------------------------------------------

						pLastActiveProcessedMover = 0;

						*ppPrev = pNext;

						ReleaseMover( pMover );

					} else {

						Location pos;

						FPCalcPosition( pMover->FP_boardRow, col, pos );

						SetMoverLocation( pMover, pos );

						ppPrev = &pMover->pNext; // setup our new prev

						pLastActiveProcessedMover = pMover;

						ReserveMoverElement( pMover, col );

					}

				}

			}

		}

		// Find new movers
		// --------------------------------------------------------------------

		//
		//	CanElementMove()
		//

		bool CanElementMove( const int row, const int col ) {

			if ( !IsBoardPieceActive( row, col ) ) {

				return false;

			}

			return !DoesElementHaveTimer( row, col );

		}

		//
		//	CreateNewMoverAt()
		//

		void
		CreateNewMoverAt(
			const int row
			,const int col
			,const PieceType & piece
			,const DWORD dwFlags
		) {

			Mover * pMover = MakeMover( row, col, piece, dwFlags );

			_ASSERT( 0 != pMover );

			// need to insert the mover in sorted order

			if ( m_Movers[ col ] ) {

				if ( m_Movers[ col ]->FP_boardRow < pMover->FP_boardRow ) {

					pMover->pNext = m_Movers[ col ];

					m_Movers[ col ] = pMover;

				} else {

					Mover * pPrev = m_Movers[ col ];

					for ( ; pPrev->pNext ; pPrev = pPrev->pNext ) {

						if ( pPrev->pNext->FP_boardRow < pMover->FP_boardRow ) {

							break;

						}

					}

					pMover->pNext = pPrev->pNext;

					if ( pMover->pNext ) {

						pMover->FP_delta = pMover->pNext->FP_delta;

					}

					pPrev->pNext = pMover;

				}

			} else {

				m_Movers[ col ] = pMover;

			}

			ReserveMoverElement( pMover, col );

	// ================================================================
	// Trigger related events
	// ================================================================

		}

		//
		//	ProcessMatchTable()
		//

		void ProcessMatchTable() {

			// drop simple pieces
			// ----------------------------------------------------------------

			for ( int col = 0; col < m_ActiveCols; col++ ) {

				if ( !m_MatchCount[ col ] ) {

					continue;

				}

				m_MatchCount[ col ] = 0;

				bool bFoundMatch = false;

				for ( int row = m_ActiveRows; 0 <= --row; ) {

					// If we find a inactive piece then skip it and
					// start our mover search again.
					// --------------------------------------------------------

					if ( !CanElementMove( row, col ) ) {

						bFoundMatch = false;

						continue;

					}

					// --------------------------------------------------------

					int elementMatchCount = GetElementMatchCount( row, col );

					if ( bFoundMatch && (!elementMatchCount) ) {

// is solid, better name?

						if ( !CanMoverPenetrate( row, col ) ) { 

							CreateNewMoverAt( row, col, _BoardElement( row, col ), 0 );

							ClearBoardPiece( row, col );

							RemoveFromGroup( row, col );

						}

					}

					if ( elementMatchCount ) {

						SetElementMatchCount( row, col, 0 );

						RemoveFromGroup( row, col );

						ClearBoardPiece( row, col );

						bFoundMatch = true;

					}

				}

			}

			// Drop non-trivial elements (these movers need to move as a group?)
			// ----------------------------------------------------------------

			// <<< FUTURE >>>

			// For debug builds it's probably not a bad idea to 
			// validate the movers list to make sure it's sorted
			// if it's not then there is a bug!!!!

		}

		// ====================================================================

		//
		//	CountColElements()
		//

		int CountColElements( const int col ) const {

			int count = 0;

			for ( int row = 0; row < m_ActiveRows; row++ ) {

				if ( _BoardElement( row, col ) ) {

					++count;

				}

			}

			return count;

		}

		//
		//	CountColMovers()
		//

		int CountColMovers( const int col ) const {

			validate_row_col_ASSERT( 0, col );

			Mover * pMover = m_Movers[ col ];

			int count = 0;

			for ( ; pMover ; pMover = pMover->pNext ) {

				++count;

			}

			return count;

		}

		//
		//	OkayToDropNewPieceIntoCol()
		//

		bool OkayToDropNewPieceIntoCol( const int col ) const {

			int total = (CountColElements(col) + CountColMovers(col) + m_HiddenRows);

			return (total < m_ActiveRows);

		}

		//
		//	SearchForShapes()
		//

		int SearchForShapes() {

			if ( !m_bNeedToCheckForMatches ) {

				return 0;

			}

			m_bNeedToCheckForMatches = false;

			const Shape * pShape = m_pCurrentShapes;

			if ( !pShape ) return 0;

			int newMatchCount = 0;

			while ( pShape->pElements ) {

				newMatchCount += MatchShape( pShape, false, false );

				++pShape;

			}

			return newMatchCount;

		}

		// --------------------------------------------------------------------

		//
		//	CountActiveMatchTimers()
		//

		int CountActiveMatchTimers() {

			int total = 0;

			for ( int row = 0; row < m_ActiveRows; row++ ) {

				if ( m_RowHasNMatchTimers[ row ] ) {

					for ( int col = 0; col < m_ActiveCols; col++ ) {

						if ( m_MatchTimer[ row ][ col ].Active() ) {

							++total;

						}

					}

				}

			}

			return total;

		}

		//
		//	HandleDelayedMatchTimers()
		//

		void HandleDelayedMatchTimers() {

			for ( int row = 0; row < m_ActiveRows; row++ ) {

				if ( m_RowHasNMatchTimers[ row ] ) {

					for ( int col = 0; col < m_ActiveCols; col++ ) {

						if ( m_MatchTimer[ row ][ col ].Tick() ) {

							--m_RowHasNMatchTimers[ row ];

							IncrementElementMatchCount( row, col );

	// ================================================================
	// Trigger related events 
	// ================================================================

						}

					}

				}

			}

		}

		//
		//	ProcessGroups()
		//

		int ProcessGroups() {

			int newMatchCount = 0;

			SGroup * pGroup = m_pActiveGroupsListHead;

			for ( ; 0 != pGroup; pGroup = pGroup->pNext ) {

				if ( !pGroup->bActivated ) {

					if ( m_nGroupActivationCount ) {
						
						if ( m_nGroupActivationCount > pGroup->memberCount ) {

							continue;

						} else {

							pGroup->bActivated = true;

						}

					} else {

						// check to see if there is an activator in the group.

						SGroup::Member * pMember = pGroup->pMembersHead;

						for ( ; 0 != pMember; pMember = pMember->pNext ) {

							if ( _BoardElement( pMember->row, pMember->col ).IsGroupActivator() ) {

								pGroup->bActivated = true;

								break;

							}

						}

					}

				}

				// Make sure all group members are activated it the group
				// is activated

				if ( pGroup->bActivated ) {

					SGroup::Member * pMember = pGroup->pMembersHead;

					for ( ; 0 != pMember; pMember = pMember->pNext ) {

						if ( !DoesElementHaveTimer( pMember->row, pMember->col ) ) {

							++newMatchCount;

						}

						StartElementTimer( pMember->row, pMember->col, m_GroupSetTimerValue );

					}

				}

			}

			return newMatchCount;

		}

		// ====================================================================

		//
		//	ProcessEachElement()
		//

		void ProcessEachElement() {

			for ( int row = 0; row < m_ActiveRows; row++ ) {

				for ( int col = 0; col < m_ActiveCols; col++ ) {

					PieceType & piece = _BoardElement( row, col );

					piece.IncreaseStillCounter();

					piece.SetFromInput( false );

				}

			}

		}

		// ====================================================================

		//
		//	ResetScoreMultiplier()
		//

		void ResetScoreMultiplier() {

			m_ScoreMultiplier = 1;

			// something

		}

		//
		//	IncreaseScoreMultiplier()
		//

		void IncreaseScoreMultiplier() {

			++m_ScoreMultiplier;

		}

		//
		//	CollectPointsFromPiece()
		//

		bool CollectPointsFromPiece( PieceType & piece ) {

			// only score once

			if ( piece.WasCollected() ) {
				
				return false;

			}

			piece.SetCollectedStatus( true );

			// collect points...

			++m_nTotalMatchesThisFrame;

			m_nPointsCollectedThisFrame += m_ScoreMultiplier;

			// transfer's multiplier here

			piece.SetMultiplier( m_ScoreMultiplier );

			return true;

		}

		//
		//	CollectPointsForElement()
		//

		bool CollectPointsForElement( const int row, const int col ) {

			return CollectPointsFromPiece( _BoardElement( row, col ) );

		}

		// ====================================================================

		//
		//	AdvanceGameState()
		//

		bool
		AdvanceGameState( input_type * pInput ) {

			// ----------------------------------------------------------------

			m_nTotalMatchesThisFrame = 0;
			m_nPointsCollectedThisFrame = 0;

			// ----------------------------------------------------------------

			if ( pInput ) {

				if ( pInput->THandleInput( this ) ) {

					ResetScoreMultiplier();

					// input dropped a piece should clear multiplier...

				}

			}

			// ----------------------------------------------------------------

			// HandleFrozenPieceTimers();

			HandleMovers();

			// How many new matches, still need to decide what owns the 
			// multiplier
			// ----------------------------------------------------------------

			int newMatchCount = 0;
			
			newMatchCount += SearchForShapes();

			newMatchCount += ProcessGroups();

			if ( newMatchCount ) {

				IncreaseScoreMultiplier();

			}

			// collect score?

			// Collect points for this piece

			// ----------------------------------------------------------------

			HandleDelayedMatchTimers();

			ProcessMatchTable();

			// Do any per element processing
			// ----------------------------------------------------------------

			ProcessEachElement();

			return true; // need to render!

		}

		// --------------------------------------------------------------------

		//
		//	AnimatedClearBoard()
		//

		void AnimatedClearBoard( const int timerStart, const int timerIncrement ) {

			int timerValue = timerStart;

			for ( int row = 0; row < m_ActiveRows; row++ ) {

				for ( int col = 0; col < m_ActiveCols; col++ ) {

					if ( IsBoardElementOccupied( row, col ) ) {

						++m_RowHasNMatchTimers[ row ];
						
						m_MatchTimer[ row ][ col ].StartTimer( timerValue );

					}

				}

				timerValue += timerIncrement;

			}

		}


	}; // class TPuzzleGameCore<>

	// ------------------------------------------------------------------------

}; // namespace DOWNFALL

#endif // !defined(AFX_GAMECORE_H__4A70CE15_944D_4d8b_9C18_AD7B2E4360A4__INCLUDED_)
