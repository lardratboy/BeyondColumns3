// DownfallGameData.cpp -- 
//
//	Copyright (c) 2002, Brad P. Taylor, LLC
//
//	All rights reserved, unauthorized reproduction prohibited
//
//	-- FILE NOTES --
//
//////////////////////////////////////////////////////////////////////

// ----------------------------------------------------------------------------

#include "StdAfx.h"
#include "downfallgamedata.h"

// ----------------------------------------------------------------------------

namespace GAMEDATA {

	// ------------------------------------------------------------------------

	//
	//	g_GenericPieceOddsTable
	//

	const DOWNFALL::PieceType g_GenericPieceOddsTable[] = {
			DOWNFALL::PieceType( 2, 0 )
		,	DOWNFALL::PieceType( 3, 0 )
		,	DOWNFALL::PieceType( 4, 0 )
		,	DOWNFALL::PieceType( 5, 0 )
		,	DOWNFALL::PieceType( 6, 0 )
	};

	//
	//	g_MagicPieceOddsTable
	//

	const DOWNFALL::PieceType g_MagicPieceOddsTable[] = {
			DOWNFALL::PieceType( 2, 0 ) // non magic
		,	DOWNFALL::PieceType( 3, 0 )
		,	DOWNFALL::PieceType( 4, 0 )
		,	DOWNFALL::PieceType( 5, 0 )
		,	DOWNFALL::PieceType( 2, 0 )
		,	DOWNFALL::PieceType( 3, 0 )
		,	DOWNFALL::PieceType( 4, 0 )
		,	DOWNFALL::PieceType( 5, 0 )
		,	DOWNFALL::PieceType( 2, 0 )
		,	DOWNFALL::PieceType( 3, 0 )
		,	DOWNFALL::PieceType( 4, 0 )
		,	DOWNFALL::PieceType( 5, 0 )
		,	DOWNFALL::PieceType( 2, 0 )
		,	DOWNFALL::PieceType( 3, 0 )
		,	DOWNFALL::PieceType( 4, 0 )
		,	DOWNFALL::PieceType( 5, 0 )
		,	DOWNFALL::PieceType( 2, DOWNFALL::PieceType::eGROUP_ACTIVATOR ) // magic
		,	DOWNFALL::PieceType( 3, DOWNFALL::PieceType::eGROUP_ACTIVATOR )
		,	DOWNFALL::PieceType( 4, DOWNFALL::PieceType::eGROUP_ACTIVATOR )
		,	DOWNFALL::PieceType( 5, DOWNFALL::PieceType::eGROUP_ACTIVATOR )
	};

	// ========================================================================

	const DOWNFALL::InputShapeNode g_Column_ShapeNodes[] = {

			DOWNFALL::InputShapeNode( -1, 0, 0 )
		,	DOWNFALL::InputShapeNode(  0, 0, 1 )
		,	DOWNFALL::InputShapeNode( +1, 0, 2 )

	};

	const DOWNFALL::InputShapeLayout g_Column_Layouts[] = {

			DOWNFALL::InputShapeLayout( 3, -1, 0, +1, 0, &g_Column_ShapeNodes[0] )

	};

	const DOWNFALL::InputShapeSet g_Column_ShapeSet(
		3
		,sizeof(g_Column_Layouts)/sizeof(g_Column_Layouts[0])
		,DOWNFALL::InputShapeSet::LAYOUT_CAN_CHANGE_PIECE_ORDER
		,g_Column_Layouts
		,g_GenericPieceOddsTable
		,sizeof(g_GenericPieceOddsTable)/sizeof(g_GenericPieceOddsTable[0])
	);

	// ========================================================================

	const DOWNFALL::InputShapeNode g_TwoUp_ShapeNodes[] = {

			DOWNFALL::InputShapeNode( -1, 0, 0 )
		,	DOWNFALL::InputShapeNode(  0, 0, 1 )

		,	DOWNFALL::InputShapeNode( 0, -1, 0 )
		,	DOWNFALL::InputShapeNode( 0,  0, 1 )

		,	DOWNFALL::InputShapeNode( +1, 0, 0 )
		,	DOWNFALL::InputShapeNode(  0, 0, 1 )

		,	DOWNFALL::InputShapeNode( 0, +1, 0 )
		,	DOWNFALL::InputShapeNode( 0,  0, 1 )

	};

	const DOWNFALL::InputShapeLayout g_TwoUp_Layouts[] = {

			DOWNFALL::InputShapeLayout( 2, -1, 0, 0, 0, &g_TwoUp_ShapeNodes[0] )
		,	DOWNFALL::InputShapeLayout( 2, 0, -1, 0, 0, &g_TwoUp_ShapeNodes[2] )
		,	DOWNFALL::InputShapeLayout( 2, 0, 0, +1, 0, &g_TwoUp_ShapeNodes[4] )
		,	DOWNFALL::InputShapeLayout( 2, 0, 0, 0, +1, &g_TwoUp_ShapeNodes[6] )

	};

	const DOWNFALL::InputShapeSet g_TwoUp_ShapeSet(
		2
		,sizeof(g_TwoUp_Layouts)/sizeof(g_TwoUp_Layouts[0])
		,DOWNFALL::InputShapeSet::LAYOUT_CAN_CHANGE_PIECE_ORDER
		,g_TwoUp_Layouts
#if 1 // magic pieces
		,g_MagicPieceOddsTable
		,sizeof(g_MagicPieceOddsTable)/sizeof(g_MagicPieceOddsTable[0])
#else
		,g_GenericPieceOddsTable
		,sizeof(g_GenericPieceOddsTable)/sizeof(g_GenericPieceOddsTable[0])
#endif
	);

	const DOWNFALL::InputShapeSet * g_pTwoUpShapeOddsTable[] = {
			&g_TwoUp_ShapeSet
	};

	// ========================================================================

	const DOWNFALL::InputShapeNode g_Fallout_ShapeNodes[] = {

			DOWNFALL::InputShapeNode( -1, 0, 0 )
		,	DOWNFALL::InputShapeNode(  0, 0, 1 )
		,	DOWNFALL::InputShapeNode( +1, 0, 2 )

		,	DOWNFALL::InputShapeNode( 0, -1, 0 )
		,	DOWNFALL::InputShapeNode( 0,  0, 1 )
		,	DOWNFALL::InputShapeNode( 0, +1, 2 )

		,	DOWNFALL::InputShapeNode( -1, 0, 2 )
		,	DOWNFALL::InputShapeNode(  0, 0, 1 )
		,	DOWNFALL::InputShapeNode( +1, 0, 0 )

		,	DOWNFALL::InputShapeNode( 0, -1, 2 )
		,	DOWNFALL::InputShapeNode( 0,  0, 1 )
		,	DOWNFALL::InputShapeNode( 0, +1, 0 )

	};

	const DOWNFALL::InputShapeLayout g_Fallout_Layouts[] = {

			DOWNFALL::InputShapeLayout( 3, -1, 0, +1, 0, &g_Fallout_ShapeNodes[0] )
		,	DOWNFALL::InputShapeLayout( 3, 0, -1, 0, +1, &g_Fallout_ShapeNodes[3] )
		,	DOWNFALL::InputShapeLayout( 3, -1, 0, +1, 0, &g_Fallout_ShapeNodes[6] )
		,	DOWNFALL::InputShapeLayout( 3, 0, -1, 0, +1, &g_Fallout_ShapeNodes[9] )

	};

	// ------------------------------------------------------------------------

	const DOWNFALL::InputShapeSet g_Fallout_ShapeSet(
		3
		,sizeof(g_Fallout_Layouts)/sizeof(g_Fallout_Layouts[0])
		,DOWNFALL::InputShapeSet::LAYOUT_CAN_CHANGE_PIECE_ORDER
		,g_Fallout_Layouts
		,g_GenericPieceOddsTable
		,sizeof(g_GenericPieceOddsTable)/sizeof(g_GenericPieceOddsTable[0])
	);

	const DOWNFALL::InputShapeSet * g_pFalloutShapeOddsTable[] = {
			&g_Fallout_ShapeSet
	};

	// ========================================================================

	const DOWNFALL::InputShapeNode g_ExtendedFallout_ShapeNodes[] = {

		// 0

			DOWNFALL::InputShapeNode( -1, +0, +0 ) // 0
		,	DOWNFALL::InputShapeNode( +0, +0, +1 ) // 1
		,	DOWNFALL::InputShapeNode( +1, +0, +2 ) // 2

		// 3

		,	DOWNFALL::InputShapeNode( +0, -1, +0 ) // 01
		,	DOWNFALL::InputShapeNode( +0, +0, +1 ) //  2
		,	DOWNFALL::InputShapeNode( +1, +0, +2 ) // 

		// 6

		,	DOWNFALL::InputShapeNode( +0, -1, +0 ) // 012
		,	DOWNFALL::InputShapeNode( +0, +0, +1 ) //
		,	DOWNFALL::InputShapeNode( +0, +1, +2 ) //

		// 9

		,	DOWNFALL::InputShapeNode( +0, +1, +2 ) // 12
		,	DOWNFALL::InputShapeNode( +0, +0, +1 ) // 0
		,	DOWNFALL::InputShapeNode( +1, +0, +0 ) //

		// 12

		,	DOWNFALL::InputShapeNode( -1, +0, +2 ) // 2
		,	DOWNFALL::InputShapeNode( +0, +0, +1 ) // 1
		,	DOWNFALL::InputShapeNode( +1, +0, +0 ) // 0

		// 15

		,	DOWNFALL::InputShapeNode( -1, +0, +2 ) // 2
		,	DOWNFALL::InputShapeNode( +0, +0, +1 ) // 10
		,	DOWNFALL::InputShapeNode( +0, +1, +0 ) //

		// 18

		,	DOWNFALL::InputShapeNode( +0, -1, +2 ) // 210
		,	DOWNFALL::InputShapeNode( +0, +0, +1 ) //
		,	DOWNFALL::InputShapeNode( +0, +1, +0 ) //

		// 21

		,	DOWNFALL::InputShapeNode( +0, +1, +0 ) // 10
		,	DOWNFALL::InputShapeNode( +0, +0, +1 ) // 2
		,	DOWNFALL::InputShapeNode( +1, +0, +2 ) //

	};

	const DOWNFALL::InputShapeLayout g_ExtendedFallout_Layouts[] = {

			DOWNFALL::InputShapeLayout( 3, -1, +0, +1, +0, &g_ExtendedFallout_ShapeNodes[ 0] ) // .
		,	DOWNFALL::InputShapeLayout( 3, +0, -1, +1, +1, &g_ExtendedFallout_ShapeNodes[ 3] ) // .

		,	DOWNFALL::InputShapeLayout( 3, +0, -1, +0, +1, &g_ExtendedFallout_ShapeNodes[ 6] ) // .
		,	DOWNFALL::InputShapeLayout( 3, +0, +0, +1, +1, &g_ExtendedFallout_ShapeNodes[ 9] ) // 

		,	DOWNFALL::InputShapeLayout( 3, -1, +0, +1, +0, &g_ExtendedFallout_ShapeNodes[12] ) // .
		,	DOWNFALL::InputShapeLayout( 3, -1, +0, +0, +1, &g_ExtendedFallout_ShapeNodes[15] ) // .

		,	DOWNFALL::InputShapeLayout( 3, +0, -1, +0, +1, &g_ExtendedFallout_ShapeNodes[18] ) // .
		,	DOWNFALL::InputShapeLayout( 3, +0, +0, +1, +1, &g_ExtendedFallout_ShapeNodes[21] ) // .

	};

	// ------------------------------------------------------------------------

	const DOWNFALL::InputShapeSet g_ExtendedFallout_ShapeSet(
		3
		,sizeof(g_ExtendedFallout_Layouts)/sizeof(g_ExtendedFallout_Layouts[0])
		,DOWNFALL::InputShapeSet::LAYOUT_CAN_CHANGE_PIECE_ORDER
		,g_ExtendedFallout_Layouts
		,g_GenericPieceOddsTable
		,sizeof(g_GenericPieceOddsTable)/sizeof(g_GenericPieceOddsTable[0])
	);

	const DOWNFALL::InputShapeSet * g_pExtendedFalloutShapeOddsTable[] = {
			&g_ExtendedFallout_ShapeSet
	};

	// ========================================================================

	//
	//	g_FalloutShapeElements
	//
 
	const DOWNFALL::ShapeElement g_FalloutShapeElements[] = {

		// piece 1
		// --------------------------------------------------------------------

			{ -1, 0, 0, DOWNFALL::ShapeElement::DEFAULT_FLAGS }
		,	{ 1, 0, 1, DOWNFALL::ShapeElement::DEFAULT_FLAGS }
		,	{ 1, 0, 2, DOWNFALL::ShapeElement::DEFAULT_FLAGS }

		// piece 2
		// --------------------------------------------------------------------

		,	{ -1, 0, 0, DOWNFALL::ShapeElement::DEFAULT_FLAGS }
		,	{ 1, 1, 0, DOWNFALL::ShapeElement::DEFAULT_FLAGS }
		,	{ 1, 2, 0, DOWNFALL::ShapeElement::DEFAULT_FLAGS }

		// piece 3
		// --------------------------------------------------------------------

		,	{ -1, 0, 0, DOWNFALL::ShapeElement::DEFAULT_FLAGS }
		,	{ 1, 1, 1, DOWNFALL::ShapeElement::DEFAULT_FLAGS }
		,	{ 1, 2, 2, DOWNFALL::ShapeElement::DEFAULT_FLAGS }

		// piece 4
		// --------------------------------------------------------------------

		,	{ -1, 0, 2, DOWNFALL::ShapeElement::DEFAULT_FLAGS }
		,	{ 1, 1, 1, DOWNFALL::ShapeElement::DEFAULT_FLAGS }
		,	{ 1, 2, 0, DOWNFALL::ShapeElement::DEFAULT_FLAGS }

	};

	// -------------------------------------------------------------------------

#define E_TIMER_FRAMES	(20)

	//
	//	g_FalloutShapes
	//

	struct FALLOUT {

		enum {

			eFLAGS		= DOWNFALL::Shape::SETS_TIMER | DOWNFALL::Shape::MAKES_GROUPS
			,eTIMER		= MACRO_SCALE_TO_FRAMERATE(E_TIMER_FRAMES)

		};

	};

	const DOWNFALL::Shape g_FalloutShapes[] = {

			{ 1, 3, 3, 0, FALLOUT::eTIMER, FALLOUT::eFLAGS, &g_FalloutShapeElements[ 0 ] }
		,	{ 3, 1, 3, 0, FALLOUT::eTIMER, FALLOUT::eFLAGS, &g_FalloutShapeElements[ 3 ] }
		,	{ 3, 3, 3, 0, FALLOUT::eTIMER, FALLOUT::eFLAGS, &g_FalloutShapeElements[ 6 ] }
		,	{ 3, 3, 3, 0, FALLOUT::eTIMER, FALLOUT::eFLAGS, &g_FalloutShapeElements[ 9 ] }

		,	{ 0, 0, 0, 0, 0, 0 } // terminator

	};

	// ===========================================================================

	struct GROUP_TEST {

		enum {

			eFLAGS					= DOWNFALL::Shape::MAKES_GROUPS
			,eMAGICFLAG				= DOWNFALL::Shape::ACTIVATE_GROUP
			,eTIMER					= (MACRO_SCALE_TO_FRAMERATE(E_TIMER_FRAMES))

#if 0 // magic pieces stay longer
			,eELEMENTMAGICFLAG		= DOWNFALL::ShapeElement::ELEMENT_SETS_TIMER
			,eMAGICTIMER			= ((eTIMER) * 4)
#else
			,eELEMENTMAGICFLAG		= DOWNFALL::ShapeElement::DEFAULT_FLAGS
			,eMAGICTIMER			= eTIMER
#endif

		};

	};

	//
	//	g_GroupSearchElements
	//

	const DOWNFALL::ShapeElement g_GroupSearchElements[] = {

		// piece 1
		// --------------------------------------------------------------------

			{ -1, 0, 0, DOWNFALL::ShapeElement::DEFAULT_FLAGS }
		,	{ 1, 0, 1, DOWNFALL::ShapeElement::DEFAULT_FLAGS }

		// piece 2
		// --------------------------------------------------------------------

		,	{ -1, 0, 0, DOWNFALL::ShapeElement::DEFAULT_FLAGS }
		,	{ 1, 1, 0, DOWNFALL::ShapeElement::DEFAULT_FLAGS }

		// piece 3
		// --------------------------------------------------------------------

		,	{ -1, 0, 0, DOWNFALL::ShapeElement::DEFAULT_FLAGS }
		,	{ 1, 1, 1, DOWNFALL::ShapeElement::DEFAULT_FLAGS }

		// piece 4
		// --------------------------------------------------------------------

		,	{ -1, 0, 1, DOWNFALL::ShapeElement::DEFAULT_FLAGS }
		,	{ 1, 1, 0, DOWNFALL::ShapeElement::DEFAULT_FLAGS }

		// piece 5
		// --------------------------------------------------------------------

		,	{ DOWNFALL::ShapeElement::MAKEMATCHEXACT(1), 0, 0, GROUP_TEST::eELEMENTMAGICFLAG }
		,	{ 0, 0, 1, DOWNFALL::ShapeElement::DEFAULT_FLAGS }

		// piece 6
		// --------------------------------------------------------------------

		,	{ DOWNFALL::ShapeElement::MAKEMATCHEXACT(1), 0, 0, GROUP_TEST::eELEMENTMAGICFLAG }
		,	{ 0, 1, 0, DOWNFALL::ShapeElement::DEFAULT_FLAGS }

		// piece 7
		// --------------------------------------------------------------------

		,	{ 0, 0, 0, DOWNFALL::ShapeElement::DEFAULT_FLAGS }
		,	{ DOWNFALL::ShapeElement::MAKEMATCHEXACT(1), 0, 1, GROUP_TEST::eELEMENTMAGICFLAG }

		// piece 8
		// --------------------------------------------------------------------

		,	{ 0, 0, 0, DOWNFALL::ShapeElement::DEFAULT_FLAGS }
		,	{ DOWNFALL::ShapeElement::MAKEMATCHEXACT(1), 1, 0, GROUP_TEST::eELEMENTMAGICFLAG }

	};

	//
	//	g_GroupShapes
	//

	const DOWNFALL::Shape g_GroupShapes[] = {

			{ 1, 2, 2, 0, GROUP_TEST::eTIMER, GROUP_TEST::eFLAGS, &g_GroupSearchElements[ 0 ] }
		,	{ 2, 1, 2, 0, GROUP_TEST::eTIMER, GROUP_TEST::eFLAGS, &g_GroupSearchElements[ 2 ] }

#if 0 // diagnals
		,	{ 2, 2, 2, 0, GROUP_TEST::eTIMER, GROUP_TEST::eFLAGS, &g_GroupSearchElements[ 4 ] }
		,	{ 2, 2, 2, 0, GROUP_TEST::eTIMER, GROUP_TEST::eFLAGS, &g_GroupSearchElements[ 6 ] }
#endif

#if 0 // magic pieces
		,	{ 1, 2, 2, 0, GROUP_TEST::eMAGICTIMER, GROUP_TEST::eMAGICFLAG, &g_GroupSearchElements[ 8  ] }
		,	{ 2, 1, 2, 0, GROUP_TEST::eMAGICTIMER, GROUP_TEST::eMAGICFLAG, &g_GroupSearchElements[ 10 ] }
		,	{ 1, 2, 2, 0, GROUP_TEST::eMAGICTIMER, GROUP_TEST::eMAGICFLAG, &g_GroupSearchElements[ 12 ] }
		,	{ 2, 1, 2, 0, GROUP_TEST::eMAGICTIMER, GROUP_TEST::eMAGICFLAG, &g_GroupSearchElements[ 14 ] }
#endif
		,	{ 0, 0, 0, 0, 0, 0 } // terminator

	};

	// need to have other shapes here

}; // namespace GAMEDATA

