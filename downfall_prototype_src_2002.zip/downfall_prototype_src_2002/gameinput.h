// gameinput.h: -- implements a movable shape that talks to the gamecore object
//
//	Copyright (c) 2002, Brad P. Taylor, LLC
//
//	All rights reserved, unauthorized reproduction prohibited
//
//	-- FILE NOTES --
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMEINPUT_H__3DE3CE78_BC64_46d0_99B6_431237860374__INCLUDED_)
#define AFX_GAMEINPUT_H__3DE3CE78_BC64_46d0_99B6_431237860374__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// ----------------------------------------------------------------------------

#include "gametypes.h"
#include "gamecore.h"

// ----------------------------------------------------------------------------

namespace DOWNFALL {

	// ------------------------------------------------------------------------

	//
	//	InputShapeNode
	//

	struct InputShapeNode {

		int rowOffset;
		int colOffset;
		int index;

		InputShapeNode(
			const int row, const int col, const int ind
		) : rowOffset(row), colOffset(col), index(ind) {}

	};

	//
	//	InputShapeLayout
	//

	struct InputShapeLayout {

		int nodeCount; // number of nodes in the layout

		int t_offset;
		int l_offset; // offsets from control position to determine rectangle
		int b_offset;
		int r_offset;

		const InputShapeNode * pFirstNode; // pointer to the shape nodes

		InputShapeLayout(
			const int nNodes
			,const int top
			,const int left
			,const int bottom
			,const int right
			,const InputShapeNode * pFirst
		) : nodeCount( nNodes ), t_offset( top ), l_offset( left )
			,b_offset( bottom ), r_offset( right ), pFirstNode( pFirst )
		{
		}

	};

	//
	//	InputShapeSet
	//

	struct InputShapeSet {

		enum {

			LAYOUT_CAN_CHANGE_PIECE_ORDER	= 0x00000001

		};

		int needPieceCount; // controls the number of pieces generated

		int layoutCount; // how many alternative layouts exist for this shape

		DWORD dwFlags; // action flags

		const InputShapeLayout * pLayoutTable; // pointer to layouts

		const PieceType * pPieceOddsTable; // what pieces are usable for this shape set

		int nPieceOddsTableLength; // how long is sequence

		InputShapeSet(
			const int pieceCount, const int layouts, 
			const DWORD flags, const InputShapeLayout * pLayout,
			const PieceType * pPieceOdds, const int nPieceOdds
		) : needPieceCount( pieceCount ), layoutCount( layouts )
			, dwFlags( flags ), pLayoutTable( pLayout )
			, pPieceOddsTable( pPieceOdds ), nPieceOddsTableLength( nPieceOdds )
		{
		}

	};

	// ------------------------------------------------------------------------

	//
	//	TInputMovableShape<>
	//

	template<
		class RENDERER
		,const int MAX_ELEMENTS
		,const bool b_USE_DOWN_TO_IMPLEMENT_DROP = true
	>
	class TInputMovableShape {

	public:

		friend RENDERER;

		enum {

			ELEMENTS = MAX_ELEMENTS

		};

	private:

		//
		//	Piece
		//

		class Piece {

		private:

			// ----------------------------------------------------------------

			const PieceType * m_pOrder[ ELEMENTS ];

			const InputShapeSet * m_pCurrentShapeSet;

			const InputShapeLayout * m_pCurrentLayout;

			int m_nCurrentLayout;

			// ----------------------------------------------------------------

			void ASSERT_ELEMENT( const int n ) const {

				_ASSERT( m_pCurrentLayout );

				_ASSERT( (0 <= n) && (m_pCurrentLayout->nodeCount > n) );

			}

			// ----------------------------------------------------------------

			const PieceType * RawGetNthPiece( const int n ) const {

				ASSERT_ELEMENT( n );

				return m_pOrder[ n ];

			}

			// ----------------------------------------------------------------

			Piece & operator=( const Piece & rhs );

		public:

			Piece() : m_pCurrentShapeSet(0), m_nCurrentLayout(0), m_pCurrentLayout(0) {

				for ( int i = 0; i < ELEMENTS; i++ ) {

					m_pOrder[ i ] = 0;

				}

			}

			// ----------------------------------------------------------------

#if defined(_DEBUG)

			void ValidateInternals() const {

				if ( m_pCurrentShapeSet ) {

					_ASSERT( (0 <= m_nCurrentLayout) && (m_pCurrentShapeSet->layoutCount > m_nCurrentLayout) );

				}

			}

#endif // defined(_DEBUG)

			// ----------------------------------------------------------------

			void Copy( const Piece * pRHS ) {

				for ( int i = 0; i < ELEMENTS; i++ ) {

					m_pOrder[ i ] = pRHS->m_pOrder[ i ];

				}

				m_pCurrentShapeSet = pRHS->m_pCurrentShapeSet;

				m_pCurrentLayout = pRHS->m_pCurrentLayout;

				m_nCurrentLayout = pRHS->m_nCurrentLayout;

#if defined(_DEBUG)
				ValidateInternals();
#endif // defined(_DEBUG)

			}

			// ----------------------------------------------------------------

			void ROL() {

				_ASSERT( m_pCurrentShapeSet );

				// ------------------------------------------------------------
				// NOTE (A)
				// ------------------------------------------------------------
				// should this use the layout's notion instead?
				// this allows invisible pieces to be rotated in if the 
				// layouts have a different number of elements than the shape
				// allows for.  This might be a cool option or just confusing.
				// ------------------------------------------------------------

				if ( 1 < m_pCurrentShapeSet->needPieceCount ) {

					const PieceType * pT = m_pOrder[ 0 ];

					for ( int i = 1; i < m_pCurrentShapeSet->needPieceCount; i++ ) {

						m_pOrder[ i - 1 ] = m_pOrder[ i ];

					}

					m_pOrder[ m_pCurrentShapeSet->needPieceCount - 1 ] = pT;

				}

#if defined(_DEBUG)
				ValidateInternals();
#endif // defined(_DEBUG)


			}
	
			void ROR() {

				_ASSERT( m_pCurrentShapeSet );

				// see NOTE (A)

				if ( 1 < m_pCurrentShapeSet->needPieceCount ) {

					const PieceType * pT = m_pOrder[ m_pCurrentShapeSet->needPieceCount - 1 ];

					for ( int i = m_pCurrentShapeSet->needPieceCount; --i >= 1; ) {

						m_pOrder[ i ] = m_pOrder[ i - 1 ];

					}

					m_pOrder[ 0 ] = pT;

				}

#if defined(_DEBUG)
				ValidateInternals();
#endif // defined(_DEBUG)

			}

			// ----------------------------------------------------------------

			void PrevLayout() {

				_ASSERT( m_pCurrentShapeSet );

				_ASSERT( (0 <= m_nCurrentLayout) && (m_pCurrentShapeSet->layoutCount > m_nCurrentLayout) );

				if ( 0 > --m_nCurrentLayout ) {

					m_nCurrentLayout = m_pCurrentShapeSet->layoutCount - 1;

				}

				_ASSERT( (0 <= m_nCurrentLayout) && (m_pCurrentShapeSet->layoutCount > m_nCurrentLayout) );

				m_pCurrentLayout = &m_pCurrentShapeSet->pLayoutTable[ m_nCurrentLayout ];

#if defined(_DEBUG)
				ValidateInternals();
#endif // defined(_DEBUG)

			};

			void NextLayout() {

				_ASSERT( m_pCurrentShapeSet );

				_ASSERT( (0 <= m_nCurrentLayout) && (m_pCurrentShapeSet->layoutCount > m_nCurrentLayout) );

				if ( m_pCurrentShapeSet->layoutCount <= ++m_nCurrentLayout ) {

					m_nCurrentLayout = 0;

				}

				_ASSERT( (0 <= m_nCurrentLayout) && (m_pCurrentShapeSet->layoutCount > m_nCurrentLayout) );

				m_pCurrentLayout = &m_pCurrentShapeSet->pLayoutTable[ m_nCurrentLayout ];

#if defined(_DEBUG)
				ValidateInternals();
#endif // defined(_DEBUG)

			}

			// Handle generation (how to handle random numbers?)
			// ----------------------------------------------------------------

			bool Generate(
				const InputShapeSet * pShapeSet
				// eventually a random generator object will be passed here!
			) {

				_ASSERT( pShapeSet );

				_ASSERT( pShapeSet->nPieceOddsTableLength );

				_ASSERT( ELEMENTS >= pShapeSet->needPieceCount );

				// init the simple stuff

				m_pCurrentShapeSet = pShapeSet;

				m_nCurrentLayout = 0;

				m_pCurrentLayout = &m_pCurrentShapeSet->pLayoutTable[ 0 ];

				// now pick the pieces from the shape's piece odds table

				for ( int i = 0; i < pShapeSet->needPieceCount; i++ ) {

					int r = rand() % pShapeSet->nPieceOddsTableLength; 

					m_pOrder[ i ] = &pShapeSet->pPieceOddsTable[ r ];

				}

				_ASSERT( (0 <= m_nCurrentLayout) && (m_pCurrentShapeSet->layoutCount > m_nCurrentLayout) );

#if defined(_DEBUG)
				ValidateInternals();
#endif // defined(_DEBUG)

				return true;

			}

			// helper methods
			// ----------------------------------------------------------------

			int GetPieceCount() const {

				_ASSERT( m_pCurrentLayout );

				return m_pCurrentLayout->nodeCount;

			}

			const PieceType * GetPieceTypeForNThElement( const int n ) const {

				ASSERT_ELEMENT( n );

				return RawGetNthPiece( m_pCurrentLayout->pFirstNode[ n ].index );

			}

			int GetRowForNThElement( const int n, const int baseRow ) const {

				ASSERT_ELEMENT( n );

				return m_pCurrentLayout->pFirstNode[ n ].rowOffset + baseRow;

			}

			int GetColForNThElement( const int n, const int baseCol ) const {

				ASSERT_ELEMENT( n );

				return m_pCurrentLayout->pFirstNode[ n ].colOffset + baseCol;

			}

		};

		// --------------------------------------------------------------------

		//
		//	TPeriodicBooleanInput<>
		//

		template< const int RESET >
		class TPeriodicBooleanInput {

		private: 

			bool m_bCurrentStatus;

			int m_nResetCountDown;

		public:

			TPeriodicBooleanInput() : m_nResetCountDown(0), m_bCurrentStatus(false) {}

			//
			//	RawStatus()
			//

			bool RawStatus() const {

				return m_bCurrentStatus;

			}

			//
			//	IsActive()
			//

			bool IsActive( const bool bPeek = false ) {

				if ( m_nResetCountDown && (!bPeek) ) --m_nResetCountDown;

				if ( m_bCurrentStatus ) {

					if ( 0 == m_nResetCountDown ) {

						m_nResetCountDown = RESET;

						return true;

					}

				} else {

					m_nResetCountDown = 0;

				}

				return false;

			}

			//
			//	SetStatus()
			//

			void SetStatus( const bool bStatus ) {

				m_bCurrentStatus = bStatus;

			}

		}; // class TPeriodicBooleanInput<>

		typedef TPeriodicBooleanInput<5> periodic_input_type;
		typedef TPeriodicBooleanInput<0> continuous_input_type;

		// --------------------------------------------------------------------

		periodic_input_type m_Input_ButtonA;
		periodic_input_type m_Input_ButtonB;
		periodic_input_type m_Input_ButtonC;
		periodic_input_type m_Input_ButtonD;
		continuous_input_type m_Input_U;
		continuous_input_type m_Input_D;

		periodic_input_type m_Input_L; // periodic until fractional column movement...
		periodic_input_type m_Input_R; // periodic until fractional column movement...

		// --------------------------------------------------------------------

		Piece m_PieceA;
		Piece m_PieceB;
		Piece m_PieceC;

		Piece * m_pFront;
		Piece * m_pBack;
		Piece * m_pNext;

		bool m_bDefaultOrientation;

		// --------------------------------------------------------------------

		int m_FP_row;
		int m_FP_col;

		int m_FP_DefaultRow;
		int m_FP_DefaultCol;

		const InputShapeSet ** m_ppShapeOddsTable;
		int m_nShapeOddsTableLength;

		bool m_bNeedNewPiece;

		int m_FP_DownDelta;
		int m_FP_LastValidRow;

		int m_FinalMomentsCountdown;

		bool m_bAutoDownInput;

		int m_DifficultySpeedSetting;

		// --------------------------------------------------------------------

	private: // methods

		// --------------------------------------------------------------------

		//
		//	SwapFrontAndBack()
		//

		void SwapFrontAndBack( const bool bChangeOrientation = true ) {

			if ( bChangeOrientation ) {

				m_bDefaultOrientation = !m_bDefaultOrientation;

			}

			Piece * t = m_pFront;
			m_pFront = m_pBack;
			m_pBack = t;

		}

		// --------------------------------------------------------------------

		//
		//	ReorderPiece()
		//

		void ReorderPiece() {

			m_pBack->Copy( m_pFront );

			if ( m_bDefaultOrientation ) {

				m_pBack->ROL();

			} else {

				m_pBack->ROL();
//				m_pBack->ROR();

			}

			// swap the buffers so the transformed piece is used
			// ----------------------------------------------------------------

			SwapFrontAndBack( false );

		}

		// --------------------------------------------------------------------

		//
		//	RotateLeft()
		//

		void RotateLeft() {

			m_pBack->Copy( m_pFront );

			m_pBack->NextLayout();

			// swap the buffers so the transformed piece is used
			// ----------------------------------------------------------------

			SwapFrontAndBack();

		}

		//
		//	RotateRight()
		//

		void RotateRight() {

			m_pBack->Copy( m_pFront );

			m_pBack->PrevLayout();

			// swap the buffers so the transformed piece is used
			// ----------------------------------------------------------------

			SwapFrontAndBack();

		}

		// --------------------------------------------------------------------

		int WrapFriendlyGetNthElementRow( const int n, const int baseRow ) {

			return m_pFront->GetRowForNThElement( n, baseRow );

		}

		int WrapFriendlyGetNthElementCol( const int n, const int baseCol ) {

			return m_pFront->GetColForNThElement( n, baseCol );

		}

		// --------------------------------------------------------------------

		//
		//	IsLocationClear()
		//

		template< class T > 
		bool IsLocationClear( T * pGame, const int row, const int col ) {

			int elements = m_pFront->GetPieceCount();

			for ( int i = 0; i < elements; i++ ) {

				int readRow = WrapFriendlyGetNthElementRow( i, row );
				int readCol = WrapFriendlyGetNthElementCol( i, col );

				// Check the element's potential board row and col.
				// ------------------------------------------------------------

				if ( (0 > readRow) || (0 > readCol) ) return false;

				if ( pGame->m_ActiveRows <= readRow ) return false;

				if ( pGame->m_ActiveCols <= readCol ) return false;

				// If the board element has something then bail
				// ------------------------------------------------------------

				if ( !pGame->CanInputPenetrate( readRow, readCol ) ) {
					
					return false;

				}

			}
			
			return true;

		}

		//
		//	AttemptLocation()
		//

		template< class T > 
		bool AttemptLocation(
			T * pGame
			,const int row
			,const int col
			,const bool bChangeRow = true
			,const bool bChangeCol = true
		) {

			if ( !IsLocationClear( pGame, row, col ) ) {

				return false;

			}

			if ( bChangeRow ) m_FP_row = row << T::FRACTION_SHIFT;
			if ( bChangeCol ) m_FP_col = col << T::FRACTION_SHIFT;

			return true;

		}

		//
		//	ValidateNewOrientationOrPosition()
		//

		template< class T > 
		bool ValidateNewOrientationOrPosition(
			T * pGame
			,const bool bSwapBuffersOnFailure
			,const bool bReverseOrientationOnFailure
			,const bool bTryMovingPieceUpFirst
			,bool * pMoved = 0
		) {

			// check to see if the piece is just fine where it is located
			// ----------------------------------------------------------------

			int row = (m_FP_row + (1 << T::FRACTION_SHIFT) - 1) >> T::FRACTION_SHIFT;

			int col = m_FP_col >> T::FRACTION_SHIFT;

			if ( IsLocationClear( pGame, row, col ) ) {

				if ( pMoved ) { *pMoved = false; }

				return true;

			}

			// make sure that the piece isn't inside another if it is
			// try moving [U] LRD to correct this.
			// ----------------------------------------------------------------

			if ( bTryMovingPieceUpFirst ) {

				if ( AttemptLocation( pGame, row - 1, col, true, false ) ) {
					
					if ( pMoved ) { *pMoved = true; }

					return true;

				}

			}

			if ( AttemptLocation( pGame, row, col - 1, false, true ) ) {

				if ( pMoved ) { *pMoved = true; }

				return true;

			}

			if ( AttemptLocation( pGame, row, col + 1, false, true ) ) {

				if ( pMoved ) { *pMoved = true; }

				return true;

			}

			if ( AttemptLocation( pGame, row + 1, col, true, false ) ) {
				
				if ( pMoved ) { *pMoved = true; }

				return true;

			}

			// Deal with the UNDO
			// ----------------------------------------------------------------

			if ( bSwapBuffersOnFailure ) {

				SwapFrontAndBack( bReverseOrientationOnFailure );

			}

			if ( pMoved ) { *pMoved = false; }

			return false;

		}

		//
		//	RandNumber()
		//

		int RandNumber() {

			return rand();

		}

		//
		//	Generate()
		//

		void Generate( Piece * pPiece ) {

			// choose a shape set then generate :)
			// --------------------------------

			_ASSERT( (0 != m_nShapeOddsTableLength) && (0 != m_ppShapeOddsTable) );

			int choice = rand() % m_nShapeOddsTableLength;

			const InputShapeSet * pShapeSet = m_ppShapeOddsTable[ choice ];

			pPiece->Generate( pShapeSet );

		}

		// --------------------------------------------------------------------

		//
		//	CantPlacePieceInDefaultLocation()
		//

		template< class T > 
		void CantPlacePieceInDefaultLocation( T * pGame ) {

			pGame->AnimatedClearBoard( 20, 0 );

//			pGame->ResetGameInternals();

			m_bNeedNewPiece = true;

		}

		// --------------------------------------------------------------------

		//
		//	NextShape()
		//

		template< class T > 
		void NextShape( T * pGame ) {

			m_bDefaultOrientation = true;

			Piece * p = m_pFront;
			m_pFront = m_pNext;
			m_pNext = p;

			Generate( m_pNext );

			m_FP_row = m_FP_DefaultRow;
			m_FP_col = m_FP_DefaultCol;

			if ( !AttemptLocation(
				pGame, m_FP_row >> T::FRACTION_SHIFT, m_FP_col >> T::FRACTION_SHIFT ) ) {

				// if we couldn't place in the default position try left to right
				// scaning before we end the game...

				m_FP_col = 0;

				int FP_delta = 1 << T::FRACTION_SHIFT;

				for ( int c = 0; c < pGame->m_ActiveCols; c++ ) {

					if ( AttemptLocation(
						pGame, m_FP_row >> T::FRACTION_SHIFT, m_FP_col >> T::FRACTION_SHIFT ) ) {

						return; // we sucessfully introduced a piece :)

					}

					m_FP_col += FP_delta;

				}

				CantPlacePieceInDefaultLocation( pGame );

			}

		}

		//
		//	PlaceIntoBoard()
		//

		template< class T > 
		bool PlaceIntoBoard( T * pGame, const int row, const int col ) {

			// Drop all the active pieces
			// ----------------------------------------------------------------

			int elements = m_pFront->GetPieceCount();

			for ( int i = 0; i < elements; i++ ) {

				int readRow = WrapFriendlyGetNthElementRow( i, row );

				int readCol = WrapFriendlyGetNthElementCol( i, col );

				const PieceType * pPiece = m_pFront->GetPieceTypeForNThElement( i );

				pGame->CreateNewMoverAt(
					readRow, readCol, *pPiece, Mover::MF_FROM_INPUT
				);

			}

			// ----------------------------------------------------------------

#if 0
			if ( !AttemptLocation(
				pGame, m_FP_DefaultRow >> T::FRACTION_SHIFT, m_FP_DefaultCol >> T::FRACTION_SHIFT ) ) {

				CantPlacePieceInDefaultLocation( pGame );

			}
#endif

			// make the next shape active... (should have a pause???)
			// ----------------------------------------------------------------

			m_bNeedNewPiece = true;

			m_bAutoDownInput = false;

			return true;

		}

	public:

		// --------------------------------------------------------------------

		//
		//	TInputMovableShape()
		//

		TInputMovableShape() : 
			m_FP_row(0)
			,m_FP_col( 0 )
			,m_FP_DefaultRow(0)
			,m_FP_DefaultCol(0) 
			,m_ppShapeOddsTable(0)
			,m_nShapeOddsTableLength(0)
			,m_bNeedNewPiece(false)
			,m_FP_DownDelta(1)
			,m_FinalMomentsCountdown(0)
			,m_FP_LastValidRow(0)
			,m_bAutoDownInput(false)
			,m_DifficultySpeedSetting(0)
		{

			m_pFront = &m_PieceA;
			m_pBack = &m_PieceB;
			m_pNext = &m_PieceC;

		};

		//
		//	KickStart()
		//

		template< class T > 
		void KickStart(
			 T * pGame 
			,const int defaultRow
			,const int defaultCol
			,const InputShapeSet ** ppShapeOddsTable
			,const int nShapeOddsTableLength
		) {

			m_FP_DefaultRow = defaultRow << T::FRACTION_SHIFT;
			m_FP_DefaultCol = defaultCol << T::FRACTION_SHIFT;

			m_FP_row = m_FP_DefaultRow;
			m_FP_col = m_FP_DefaultCol;

			m_ppShapeOddsTable = ppShapeOddsTable;
			m_nShapeOddsTableLength = nShapeOddsTableLength;

			m_bNeedNewPiece = true;

			m_bDefaultOrientation = true;

			m_FP_LastValidRow = 0;

			Generate( m_pNext );

			m_bAutoDownInput = false;

		}

		// --------------------------------------------------------------------

		enum INPUT_FLAGS {

				INPUT_DIR_L		= 0x00000001
			,	INPUT_DIR_R		= 0x00000002
			,	INPUT_DIR_U		= 0x00000004
			,	INPUT_DIR_D		= 0x00000008
			,	INPUT_BUTTON_A	= 0x00000010
			,	INPUT_BUTTON_B	= 0x00000020
			,	INPUT_BUTTON_C	= 0x00000040
			,	INPUT_BUTTON_D	= 0x00000080

		};

		//
		//	SetDifficultySpeedSetting()
		//

		void SetDifficultySpeedSetting( const int value ) {

			m_DifficultySpeedSetting = value;

		}

		//
		//	SetBooleanInput()
		//

		void SetBooleanInput( DWORD dwInputFlags ) {

#if 1

			// If there has been no input for a very long time then
			// start randomly entering input
			// ----------------------------------------------------------------

			static int nNoInputCount = 0;

			if ( dwInputFlags ) {

				nNoInputCount = 0;

			} else {

				if ( ++nNoInputCount >= 360 ) {

					nNoInputCount = 360;

					dwInputFlags = 
							((0 == (RandNumber() % 16)) ? INPUT_DIR_L : 0)
						|	((0 == (RandNumber() % 16)) ? INPUT_DIR_R : 0)
						|	((0 == (RandNumber() % 64)) ? INPUT_DIR_U : 0)
						|	((0 == (RandNumber() % 16)) ? INPUT_DIR_D : 0)
						|	((0 == (RandNumber() % 16)) ? INPUT_BUTTON_C : 0)
						|	((0 == (RandNumber() % (m_bDefaultOrientation ? 16 : 128)) ? INPUT_BUTTON_D : 0))
						|	((0 == (RandNumber() % (m_bDefaultOrientation ? 16 : 128)) ? INPUT_BUTTON_A : 0))
						|	((0 == (RandNumber() % (m_bDefaultOrientation ? 128 : 256)) ? INPUT_BUTTON_B : 0))
						;

				}

			}

#endif

			m_Input_L.SetStatus( (INPUT_DIR_L & dwInputFlags) ? true : false );
			m_Input_R.SetStatus( (INPUT_DIR_R & dwInputFlags) ? true : false );
			m_Input_U.SetStatus( (INPUT_DIR_U & dwInputFlags) ? true : false );
			m_Input_D.SetStatus( (INPUT_DIR_D & dwInputFlags) ? true : false );

			m_Input_ButtonA.SetStatus( (INPUT_BUTTON_A & dwInputFlags) ? true : false );
			m_Input_ButtonB.SetStatus( (INPUT_BUTTON_B & dwInputFlags) ? true : false );
			m_Input_ButtonC.SetStatus( (INPUT_BUTTON_C & dwInputFlags) ? true : false );
			m_Input_ButtonD.SetStatus( (INPUT_BUTTON_D & dwInputFlags) ? true : false );

		}

		// --------------------------------------------------------------------

		//
		//	OkayToIntroducePiece()
		//

		template< class T >
		bool OkayToIntroducePiece( T * pGame ) {

			return (!pGame->BoardHasMovers()) && (!pGame->CountActiveMatchTimers());

		}

		// --------------------------------------------------------------------

		//
		//	THandleInput()
		//

		template< class T > 
		bool THandleInput( T * pGame ) {

			// Introduce new piece if there are no movers...
			// -------------------------------------------------------------------------

			static int nStuckCounter = 0;

			if ( m_bNeedNewPiece ) {

				if ( OkayToIntroducePiece( pGame ) ) { // what about no timers as well?

					m_bNeedNewPiece = false;

					NextShape( pGame );

					nStuckCounter = 0;

				} else {

					if ( 500 <= ++nStuckCounter ) {

						pGame->ResetGameInternals(); // ???

						nStuckCounter = 0;

//						return true;

					}

					return false;

				}

			}

			// -------------------------------------------------------------------------

			// process input

			bool bRotateRight = m_Input_ButtonA.IsActive();
			bool bRotateLeft = m_Input_ButtonB.IsActive();
			bool bMoveLeft = m_Input_L.IsActive();
			bool bMoveRight = m_Input_R.IsActive();
			bool bMoveUp = m_Input_U.IsActive();
			bool bMoveDown = m_Input_D.IsActive();
			bool bDrop = m_Input_ButtonD.IsActive();
			bool bReorder = m_Input_ButtonC.IsActive();

			// see if down is implemented via faked input

			if ( m_bAutoDownInput && b_USE_DOWN_TO_IMPLEMENT_DROP ) {

				bMoveDown = true;

			}

			// handle rotation

			if ( bRotateRight ) {

				RotateRight();

				ValidateNewOrientationOrPosition( pGame, true, true, false );

			} else if ( bRotateLeft ) {

				RotateLeft();

				ValidateNewOrientationOrPosition( pGame, true, true, false );

			}

			// handle reorder

			if ( bReorder ) {

				ReorderPiece();

				ValidateNewOrientationOrPosition( pGame, true, false, false );

			}

			// handle movement

			if ( bMoveLeft ) {

				int row = (m_FP_row + ((1 << T::FRACTION_SHIFT) - 1)) >> T::FRACTION_SHIFT;
				int col = (m_FP_col >> T::FRACTION_SHIFT);

				AttemptLocation( pGame, row, col - 1, false, true );

			} else if ( bMoveRight ) {

				int row = (m_FP_row + ((1 << T::FRACTION_SHIFT) - 1)) >> T::FRACTION_SHIFT;
				int col = (m_FP_col >> T::FRACTION_SHIFT);

				AttemptLocation( pGame, row, col + 1, false, true );

			}

			// per frame decent

			int FP_delta = 0;

			if ( m_FinalMomentsCountdown ) {

				if ( bMoveDown ) {

					m_FinalMomentsCountdown = 1;

				}

			} else {

				FP_delta += (pGame->m_FP_PerframeDelta + m_DifficultySpeedSetting);

				if ( bMoveDown ) {

					FP_delta += m_FP_DownDelta;

					const int FP_speedLimit = (1 << T::FRACTION_SHIFT) + (1 << T::FRACTION_SHIFT)/2;

					if ( FP_speedLimit > m_FP_DownDelta ) {

						m_FP_DownDelta += m_FP_DownDelta;

					} else {

						m_FP_DownDelta = FP_speedLimit;

					}

				} else {

					m_FP_DownDelta = 16; // magic number :(
					
					if ( bMoveUp ) {

						FP_delta -= (1 << T::FRACTION_SHIFT) / 64;

					}

				}

			}

			// check to see if the piece is resting ontop of another.
			// ----------------------------------------------------------------

			bool bChangedBoard = false;

			do {

				// Break the delta into 'row' sized chunks for processing
				// ------------------------------------------------------------

				int useDelta = min( FP_delta, (1 << T::FRACTION_SHIFT) );

				FP_delta -= useDelta;

				m_FP_row += useDelta;

				// ------------------------------------------------------------

				int nextRow = ((m_FP_row + (1 << T::FRACTION_SHIFT)) >> T::FRACTION_SHIFT);

				int col = (m_FP_col >> T::FRACTION_SHIFT);

				if ( IsLocationClear( pGame, nextRow, col ) ) {

					m_FP_LastValidRow = m_FP_row;

					m_FinalMomentsCountdown = 0;

				} else {

					if ( m_FinalMomentsCountdown ) {

						m_FP_row = m_FP_LastValidRow; // hold vertically

						if ( 0 == --m_FinalMomentsCountdown ) {

							while ( 0 <= nextRow ) {

								--nextRow;

								if ( IsLocationClear( pGame, nextRow, col ) ) {

									break;

								}

							}

							bChangedBoard = PlaceIntoBoard( pGame, nextRow, col );

						}

					} else {

						m_FP_row = (nextRow - 1) << T::FRACTION_SHIFT;

						m_FP_LastValidRow = m_FP_row;

						m_FinalMomentsCountdown = 8; // magic number!

					}

				}

			} while ( 0 < FP_delta );

			// handle drop request
			// ----------------------------------------------------------------

			if ( bDrop ) {

				if ( b_USE_DOWN_TO_IMPLEMENT_DROP ) {

					m_bAutoDownInput = true; // !m_bAutoDownInput;

				} else {

					int row = m_FP_row >> T::FRACTION_SHIFT;

					int col = m_FP_col >> T::FRACTION_SHIFT;

					bChangedBoard = PlaceIntoBoard( pGame, row, col );

				}

			}

	// ================================================================
	// Trigger related events
	// ================================================================

			return bChangedBoard;

		}

	}; /* TInputMovableShape<> */

}; // namespace DOWNFALL

#endif // !defined(AFX_GAMEINPUT_H__3DE3CE78_BC64_46d0_99B6_431237860374__INCLUDED_)
