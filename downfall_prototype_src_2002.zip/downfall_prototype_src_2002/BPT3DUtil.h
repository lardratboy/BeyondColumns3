// BPT3DUtil.h: -- my testbed for various subdivision experiments
//
//	Copyright (c) 2002, Brad P. Taylor, LLC
//
//	All rights reserved, unauthorized reproduction prohibited
//
//	-- FILE NOTES --
//
//	eventually I should roll my own types for vectors and
//	matrices so that the code isn't dependent on D3D!
//
//////////////////////////////////////////////////////////////////////

#if !defined( BPT3DUTIL_71ED1FAD_3265_419f_BC85_5DE02F9A04DB_INCLUDED )
#define BPT3DUTIL_71ED1FAD_3265_419f_BC85_5DE02F9A04DB_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif

// ----------------------------------------------------------------------------

#include <D3d8types.h>
#include <D3dx8math.h>

// ----------------------------------------------------------------------------

namespace BPT {

	// ------------------------------------------------------------------------

	void OutputDebugf( const char * pszFormat, ... );

	// ------------------------------------------------------------------------

	//
	//	XYZNormals
	//

	struct XYZNormals {

		D3DXVECTOR3 x_axis_normal;
		D3DXVECTOR3 y_axis_normal;
		D3DXVECTOR3 z_axis_normal;

		XYZNormals() : 
			x_axis_normal(1.0f,0.0f,0.0f),
			y_axis_normal(0.0f,1.0f,0.0f),
			z_axis_normal(0.0f,0.0f,1.0f)
		{
		}

		XYZNormals( const D3DXVECTOR3 & normal, const bool bNormalizeIncomming = true ) {

			FromNormal( normal );

		}

		void FromNormal( const D3DXVECTOR3 & normal, const bool bNormalizeIncomming = true ) {

			// base all the other normals on the incomming normal
			// ----------------------------------------------------------------

			y_axis_normal = normal;

			if ( bNormalizeIncomming ) {

				D3DXVec3Normalize( &y_axis_normal, &y_axis_normal );

			}

			// ----------------------------------------------------------------

			if ( D3DXVECTOR3( 0.0f, 1.0f, 0.0f ) == normal ) {

				x_axis_normal = D3DXVECTOR3( 1.0f, 0.0f, 0.0f );
				z_axis_normal = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );

			} else if ( D3DXVECTOR3( 0.0f, -1.0f, 0.0f ) == normal ) {

				x_axis_normal = D3DXVECTOR3( -1, 0.0f, 0.0f );
				z_axis_normal = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );

			} else {

				x_axis_normal = D3DXVECTOR3( normal.z, 0.0f, -normal.x );

				z_axis_normal = D3DXVECTOR3(
					-(-normal.x * normal.y),
					-normal.x * normal.x - (normal.z * normal.z),
					normal.z * normal.y
				);

			}

			// ----------------------------------------------------------------

			D3DXVec3Normalize( &x_axis_normal, &x_axis_normal );
			D3DXVec3Normalize( &z_axis_normal, &z_axis_normal );

		}

	};

	// ------------------------------------------------------------------------

}; // namespace BPT

#endif // !defined( BPT3DUTIL_71ED1FAD_3265_419f_BC85_5DE02F9A04DB_INCLUDED )

