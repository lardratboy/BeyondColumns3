// subdivision.h: -- my testbed for various subdivision experiments
//
//	Copyright (c) 2002, Brad P. Taylor, LLC
//
//	All rights reserved, unauthorized reproduction prohibited
//
//	-- FILE NOTES --
//
//////////////////////////////////////////////////////////////////////

#if !defined( SUBDIVISION_17CE6AC8_BF45_431e_8346_653253603E44_INCLUDED )
#define SUBDIVISION_17CE6AC8_BF45_431e_8346_653253603E44_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif

// ----------------------------------------------------------------------------

#include <memory>
#include <limits>
#include <D3d8types.h>
#include <D3dx8math.h>

// ----------------------------------------------------------------------------

#include "BPT3DUtil.h"

// ----------------------------------------------------------------------------

namespace BPT {

	// ------------------------------------------------------------------------

#if 0 // BROKEN BROKEN DONT USE!!!

		// ------------------------------------------------------------------------

		//
		//	TOutputHelper
		//

		template< class T >
		class TOutputHelper {

			enum {

				vertex_stride = sizeof(T)

			};

		private:

			LPDIRECT3DDEVICE8 m_pd3dDevice;

			const WORD * m_pIndices;

			int m_nIndices;

			const T * m_pVertices;

			int m_nVertices;

			LPDIRECT3DVERTEXBUFFER8 m_pVertexBuffer;
			LPDIRECT3DINDEXBUFFER8 m_pIndexBuffer;

			TOutputHelper(); // Hidden

		public:

			TOutputHelper( LPDIRECT3DDEVICE8 pd3dDevice ) : 
				m_pd3dDevice( pd3dDevice )
				,m_pIndices(0)
				,m_nIndices(0)
				,m_pVertices(0)
				,m_nVertices(0)
				,m_pVertexBuffer(0)
				,m_pIndexBuffer(0)
			{
			}

			void Release() {

				SAFE_RELEASE( m_pIndexBuffer );
				SAFE_RELEASE( m_pVertexBuffer );

			}

			~TOutputHelper() {

				Release();

			}

			void Begin() {}

			void SetData(
				const T * pVertices, const int nVertices
				,const WORD * pIndices, const int nIndices
			) {

				Release();

				// ------------------------------------------------------------

				m_pVertices = pVertices;
				m_nVertices = nVertices;

				m_pIndices = pIndices;
				m_nIndices = nIndices;

				// ------------------------------------------------------------

				if ( m_pd3dDevice ) {

					DWORD usageFlags = D3DUSAGE_WRITEONLY;
					D3DPOOL d3dPool = D3DPOOL_MANAGED;

					// --------------------------------------------------------

					int nVertexBufferSizeInBytes = sizeof(nVertices) * sizeof(T);

					HRESULT hr = m_pd3dDevice->CreateVertexBuffer(
						nVertexBufferSizeInBytes
						,usageFlags
						,T::eFVFType
						,d3dPool
						,&m_pVertexBuffer
					);

					if ( FAILED( hr ) ) {

						BPT::OutputDebugf(
							"Create Vertex buffer length %d (%d entries) lock failed.\n",
							nVertexBufferSizeInBytes, nVertices
						);

						Release();
						return;

					}

					BPT::OutputDebugf( "CreateVertexBuffer size %d\n", nVertexBufferSizeInBytes );

					// --------------------------------------------------------

					int nIndexBufferSizeInBytes = nIndices * sizeof(WORD);

					hr = m_pd3dDevice->CreateIndexBuffer(
						nIndexBufferSizeInBytes
						,usageFlags
						,D3DFMT_INDEX16
						,d3dPool
						,&m_pIndexBuffer
					);

					if ( FAILED( hr ) ) {

						BPT::OutputDebugf(
							"Create Index buffer length %d (%d entries) lock failed.\n",
							nIndexBufferSizeInBytes, nIndices
						);

						Release();
						return;

					}

					BPT::OutputDebugf( "CreateIndexBuffer size %d\n", nIndexBufferSizeInBytes );

					// --------------------------------------------------------

					DWORD dwLockFlags = 0; // D3DLOCK_DISCARD;

					{
						BYTE * pLockedVertexBuffer = 0;

						hr = m_pVertexBuffer->Lock( 0, 0, &pLockedVertexBuffer, dwLockFlags );

						if ( FAILED( hr ) ) {

							BPT::OutputDebugf( "Vertex buffer lock failed.\n" );

							Release();
							return;

						}

						memcpy( pLockedVertexBuffer, pVertices, nVertexBufferSizeInBytes );

						m_pVertexBuffer->Unlock();
					}

					// --------------------------------------------------------

					{

						BYTE * pLockedIndexBuffer = 0;

						hr = m_pIndexBuffer->Lock( 0, 0, &pLockedIndexBuffer, dwLockFlags );

						if ( FAILED( hr ) ) {

							BPT::OutputDebugf( "Index buffer lock failed.\n" );

							Release();
							return;

						}

						memcpy( pLockedIndexBuffer, pIndices, nIndexBufferSizeInBytes );

						m_pIndexBuffer->Unlock();

					}

				}

			}

			//
			//	IndexedTriangleStrip()
			//

			void IndexedTriangleStrip(
				const int minIndex
				,const int firstIndex
				,const int nTriangles
				,const bool bDebug = false
			) {

				if ( m_pVertexBuffer && m_pIndexBuffer ) {

					m_pd3dDevice->SetStreamSource( 0, m_pVertexBuffer, sizeof(T) );
					m_pd3dDevice->SetVertexShader( T::eFVFType );
					m_pd3dDevice->SetIndices( m_pIndexBuffer, 0 );

					HRESULT hr = m_pd3dDevice->DrawIndexedPrimitive(
						D3DPT_TRIANGLESTRIP
						,minIndex
						,nTriangles + 2
						,firstIndex
						,nTriangles
					);

					if ( FAILED( hr ) ) {

						D3DINDEXBUFFER_DESC indexBufferInfo;

						m_pIndexBuffer->GetDesc( &indexBufferInfo );

						int nIndexEntries = indexBufferInfo.Size;

						if ( D3DFMT_INDEX16 == indexBufferInfo.Format ) {

							nIndexEntries /= 2;

						} else {

							nIndexEntries /= 4;

						}

						BPT::OutputDebugf( "DrawIndexPrimitive: Failed (0x%08x)\n", hr );
						BPT::OutputDebugf( "Params( mini:%d, indx:%d, tris:%d )\n", minIndex, firstIndex, nTriangles ); 
						BPT::OutputDebugf( "IndexBuffer has %d vs (%d) entries\n", nIndexEntries, m_nIndices );

						// dump info!

						int stop = 1;

					}

					return;

				}

//m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

				// collect stats
				// ------------------------------------------------------------

				HACKDATA::g_nTrianglesGenerated += nTriangles;

				// Convert data to a draw primitive
				// ------------------------------------------------------------

#if 1 // turn on/off the triangle renderer

#if 0 // convert strip to raw triangles

				const int MAX_TRIANGLES = 128;

				T rawTriangles[ MAX_TRIANGLES * 3 ];

				int nUseTriangles = min( nTriangles, MAX_TRIANGLES );

				T * pWork = rawTriangles;

				const WORD * pIndex = m_pIndices + firstIndex;

				for ( int i = 0; i < nUseTriangles; i++ ) {

					if ( (i & 1) ) {

						*pWork++ = m_pVertices[ *( pIndex + 2 ) ];
						*pWork++ = m_pVertices[ *( pIndex + 1 ) ];
						*pWork++ = m_pVertices[ *( pIndex + 0 ) ];

					} else {

						*pWork++ = m_pVertices[ *( pIndex + 0 ) ];
						*pWork++ = m_pVertices[ *( pIndex + 1 ) ];
						*pWork++ = m_pVertices[ *( pIndex + 2 ) ];

					}

					++pIndex;

				}

				HRESULT hr = m_pd3dDevice->DrawPrimitiveUP(
					D3DPT_TRIANGLELIST 
					,nUseTriangles
					,rawTriangles
					,vertex_stride
				);

				_ASSERT( SUCCEEDED( hr ) );

#elif 0 // convert to triangle indices 

				const int MAX_TRIANGLES = 128;

				WORD triangleIndices[ MAX_TRIANGLES * 3 ];

				int nUseTriangles = min( nTriangles, MAX_TRIANGLES );

				WORD * pWork = triangleIndices;

				const WORD * pSrcIndex = m_pIndices + firstIndex;

				for ( int i = 0; i < nUseTriangles; i++ ) {

					if ( i & 1 ) {

						*pWork++ = *( pSrcIndex + 2 );
						*pWork++ = *( pSrcIndex + 1 );
						*pWork++ = *( pSrcIndex + 0 );

					} else {

						*pWork++ = *( pSrcIndex + 0 );
						*pWork++ = *( pSrcIndex + 1 );
						*pWork++ = *( pSrcIndex + 2 );

					}

					++pSrcIndex;

				}

#if 1 // DBUG_HACK
				if ( bDebug ) {

					int index = 0;

					for ( int i = 0; i < nUseTriangles; i++ ) {

						BPT::OutputDebugf( "tri[%3d] ", i );

						//BPT::OutputDebugf( "%3d, ", triangleIndices[ index + 0 ] );
						//BPT::OutputDebugf( "%3d, ", triangleIndices[ index + 1 ] );
						//BPT::OutputDebugf( "%3d : ", triangleIndices[ index + 2] );

						for ( int k = 0; k < 3; k++ ) {

							BPT::OutputDebugf(
								"[%3d]=(%+4.2f,%+4.2f,%+4.2f): "
								,triangleIndices[ index + k ]
								,m_pVertices[ triangleIndices[ index + k ] ].x
								,m_pVertices[ triangleIndices[ index + k ] ].y
								,m_pVertices[ triangleIndices[ index + k ] ].z
							);

						}

						BPT::OutputDebugf( "\n" );

						index += 3;

					}

				}
#endif

				HRESULT hr = m_pd3dDevice->DrawIndexedPrimitiveUP(
					D3DPT_TRIANGLELIST
					,0
					,nUseTriangles * 3
					,nUseTriangles
					,&triangleIndices[0]
					,D3DFMT_INDEX16
					,m_pVertices
					,vertex_stride
				);

				_ASSERT( SUCCEEDED( hr ) );

#else // use the indexed triangle strip

				HRESULT hr = m_pd3dDevice->DrawIndexedPrimitiveUP(
					D3DPT_TRIANGLESTRIP
					,minIndex
					,nTriangles + 2
					,nTriangles
					,m_pIndices
					,D3DFMT_INDEX16
					,m_pVertices
					,vertex_stride
				);

				_ASSERT( SUCCEEDED( hr ) );

#endif

#endif // triangles on/off

//m_pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );

			}

			// ----------------------------------------------------------------


			void End() {

				Release();
			
				// Render normals (need the camera object to backface cull)
				// ------------------------------------------------------------
			
#if 0
				float fNormalLength = 0.2f;

				for ( int i = 0; i < m_nVertices; i++ ) {

					T v[ 6 ];

					// project the normal ( logical y axis )
					// --------------------------------------------------------

					v[0] = m_pVertices[ i ];
					v[1] = v[0];

					D3DXVECTOR3 yn( v[0].nx, v[0].ny, v[0].nz );

					v[1].x += yn.x * fNormalLength;
					v[1].y += yn.y * fNormalLength;
					v[1].z += yn.z * fNormalLength;

					T middle = v[1];

					v[1].x += yn.x * fNormalLength;
					v[1].y += yn.y * fNormalLength;
					v[1].z += yn.z * fNormalLength;

					// now find logical x & z axis
					// --------------------------------------------------------

					D3DXVECTOR3 yNormal( 0.0f, 1.0f, 0.0f );

					D3DXVECTOR3 xn, zn;

					if ( yNormal == yn ) {

						xn = D3DXVECTOR3( 1.0f, 0.0f, 0.0f );
						zn = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );

					} else if ( yNormal == -yn ) {

						xn = D3DXVECTOR3( -1, 0.0f, 0.0f );
						zn = D3DXVECTOR3( 0.0f, 0.0f, 1.0f );

					} else {

						xn = D3DXVECTOR3( yn.z, 0.0f, -yn.x );

						zn = D3DXVECTOR3(
							-(-yn.x * yn.y),
							-yn.x * yn.x - (yn.z * yn.z),
							yn.z * yn.y
						);

					}

					D3DXVec3Normalize( &xn, &xn );
					D3DXVec3Normalize( &zn, &zn );

					// project along the x - axis

					v[2] = middle;
					v[3] = middle;

					v[2].x += xn.x * fNormalLength;
					v[2].y += xn.y * fNormalLength;
					v[2].z += xn.z * fNormalLength;

					v[3].x -= xn.x * fNormalLength;
					v[3].y -= xn.y * fNormalLength;
					v[3].z -= xn.z * fNormalLength;

					// project along the z - axis

					v[4] = middle;
					v[5] = middle;

					v[4].x += zn.x * fNormalLength;
					v[4].y += zn.y * fNormalLength;
					v[4].z += zn.z * fNormalLength;

					v[5].x -= zn.x * fNormalLength;
					v[5].y -= zn.y * fNormalLength;
					v[5].z -= zn.z * fNormalLength;

					m_pd3dDevice->DrawPrimitiveUP(
						D3DPT_LINELIST 
						,3
						,v
						,vertex_stride
					);


				}

#endif

			}

		}; // TOutputHelper

		//
		//	TUnitSphereFilter
		//

		template< class T > struct TUnitSphereFilter {

			T & operator()( T & t ) const {

				float len = sqrtf( (t.x * t.x) + (t.y * t.y) + (t.z * t.z) );

				if ( std::numeric_limits<FLOAT>::epsilon() <= fabsf( len ) ) {

					float oo = 1.0f / len;

					t.x = t.nx = t.x * oo;
					t.y = t.ny = t.y * oo;
					t.z = t.nz = t.z * oo;

				} else {

					t.x = (0.0f >= t.x) ? -1.0f : 1.0f;
					t.y = (0.0f >= t.y) ? -1.0f : 1.0f;
					t.z = (0.0f >= t.z) ? -1.0f : 1.0f;

					float len = sqrtf( (t.x * t.x) + (t.y * t.y) + (t.z * t.z) );

					float oo = 0.0f;

					if ( std::numeric_limits<FLOAT>::epsilon() <= fabsf( len ) ) {

						oo = 1.0f / len;

					}

					t.x = t.nx = t.x * oo;
					t.y = t.ny = t.y * oo;
					t.z = t.nz = t.z * oo;

				}

				return t;

			}

		}; // TUnitSphereFilter

		//
		//	ARGH_VERTEX
		//

		struct ARGH_VERTEX {

			typedef ARGH_VERTEX this_type;

			typedef this_type * pointer;

			enum {

				eFVFType	= D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_DIFFUSE

			};

			float x, y, z;
			float nx, ny, nz;

			DWORD color;

			ARGH_VERTEX() {}

			ARGH_VERTEX(
				const D3DXVECTOR3 & pos
				,const D3DXVECTOR3 & norm
				,const DWORD colorValue
			) {

				x = pos.x;
				y = pos.y;
				z = pos.z;

				nx = norm.x;
				ny = norm.y;
				nz = norm.z;

				color = colorValue;

			}

		};

   		// --------------------------------------------------------------------

		template< class T > 
		class T_Lerp {

		public:

			T_Lerp() { /* empty */ }
			T_Lerp( const T & a, const T & b ) { /* empty */ }
			T & Position( T & out, const float t ) { return out; }

		};

		//
		//	lerp just the x,y,z!
		//

		template<> 
		class T_Lerp<ARGH_VERTEX> {

		private:

			ARGH_VERTEX m_A;

			float x;
			float y;
			float z;

			float dx;
			float dy;
			float dz;

		public:

			T_Lerp() { /* empty */ }

			T_Lerp( const ARGH_VERTEX & a, const ARGH_VERTEX & b ) :
				m_A( a )
				,x( a.x ), y( a.y ), z( a.z )
				,dx( b.x - a.x ), dy( b.y - a.y ), dz( b.z - a.z )
			{
				 /* empty */ 
			}

			T & Position( ARGH_VERTEX & out, const float t ) {

				out = m_A;

				out.x = (x + (dx * t));
				out.y = (y + (dy * t));
				out.z = (z + (dz * t));

				return out;

			}

		};

	//
	//	TNStripsTessellateTriangle
	//

	class TNStripsTessellateTriangle {

	private:

		template< class T > struct TNOPFilter {
			void operator()( T & t ) { /* empty */ }
		};

	public:

		template< class OUTPUT, class VERTEX, class FILTER, class LERP > bool
		operator()(
			OUTPUT & output,
			const VERTEX & a, const VERTEX & b, const VERTEX & c,
			const int nStrips, FILTER & filter, const LERP & dummy
		) {

			if ( 0 >= nStrips ) {

				return false;

			}

			// ----------------------------------------------------------------

			int nVertices = ((nStrips + 1) * (nStrips + 2)) / 2;

			VERTEX * pVertices = new VERTEX [ nVertices ];

			if ( !pVertices ) {

				return false;

			}

#if 1 // DBUG_HACK
			bool dbug_dump_indices = false;

			static int nLastStripDump = -1;

			if ( nLastStripDump != nStrips ) {

				nLastStripDump = nStrips;

				OutputDebugf( "nVertices = %d\n", nVertices );

				dbug_dump_indices = true;

				int stopHere = 1;

			}
#endif

			// lerp and filter the verts for the ABC Triangle

			{
				VERTEX * pOutput = pVertices;

				typedef LERP Lerp;

				Lerp ab( a, b );

				Lerp ac( a, c );

				float d = 1.0f / static_cast<float>( nStrips );

#if defined(_DEBUG)
				int dbug_vert_index = 1;
#endif

				float t = d;

				filter( *pOutput = a );

				++pOutput;

#if 1 // DBUG hack
				if ( dbug_dump_indices ) {

					OutputDebugf( "*V[%2d] : ", 0 );

					OutputDebugf(
						"%+4.2f, %+4.2f, %+4.2f\n"
						,(pOutput-1)->x
						,(pOutput-1)->y
						,(pOutput-1)->z
					);

				}
#endif

				for ( int i = 1; i <= nStrips; i++ ) {

					VERTEX tab, tac;

					Lerp tab_tac( ab.Position( tab, t ), ac.Position( tac, t ) );

					float vt = 0.0f;

					float vd = 1.0f / static_cast<float>( i );

					for ( int v = 0; v <= i; v++ ) {

						pOutput->color = a.color; // lerp the colors...

#if defined(_DEBUG)
						_ASSERT( nVertices > dbug_vert_index ); dbug_vert_index++;
#endif

						filter( tab_tac.Position( *pOutput, vt ) );

						++pOutput;

						vt += vd;

#if 1 // DBUG hack
						if ( dbug_dump_indices ) {

							OutputDebugf( "*V[%2d] : ", dbug_vert_index - 1 );

							OutputDebugf(
								"%+4.2f, %+4.2f, %+4.2f\n"
								,(pOutput-1)->x
								,(pOutput-1)->y
								,(pOutput-1)->z
							);

						}
#endif

					}

					t += d;

				}


			}

			// calculate the number of indices
			// ----------------------------------------------------------------

			int nIndices = 0;

			for ( int i = 0; i < nStrips; i++ ) {

				nIndices += (i * 2) + 3;

			}

			// ----------------------------------------------------------------

			WORD * pIndices = new WORD [ nIndices ];

			if ( !pIndices ) {

				delete [] pVertices;

				return false;

			}

#if defined(_DEBUG)
			int nUsedIndices = 0;

			if ( dbug_dump_indices ) {

				OutputDebugf( "nIndices = %d\n", nIndices );

			}
#endif

			{
				int v1 = 0;
				int v2 = 1;

				WORD * pWork = pIndices;

#if defined(_DEBUG)
				int dbug_index = 0;
#endif

				for ( int i = 1; i <= nStrips; i++ ) {

#if defined(_DEBUG)
					_ASSERT( nIndices >= (dbug_index + 3) ); dbug_index += 3;
#endif

#if 1 // DBUG HACK
					if ( dbug_dump_indices ) {
						OutputDebugf( "(%2d to %4d) strip [%2d] ", pWork - pIndices, pWork - pIndices + i * 2, i - 1 );
					}
#endif

					for ( int j = 0; j < i; j++ ) {

#if 1 // DBUG HACK
						if ( dbug_dump_indices ) {
							OutputDebugf( "%3d, %3d, ", v2, v1 );
						}
#endif

						*pWork++ = v2++;
						*pWork++ = v1++;

					}

#if 1 // DBUG HACK
					if ( dbug_dump_indices ) {
						OutputDebugf( "%3d\n", v2 );
					}
#endif

					*pWork++ = v2++;

				}

#if defined(_DEBUG)
				nUsedIndices = static_cast<int>( pWork - pIndices );
				_ASSERT( nUsedIndices == nIndices );
#endif

			}

			// tell the output about the vertex & index data
			// ----------------------------------------------------------------

			output.Begin();

			output.SetData(
				pVertices, nVertices
				,pIndices, nIndices
			);

			// Repeatedly call the output for each triangle strip
			// ----------------------------------------------------------------

			int firstIndex = 0;

			for ( int i = 0; i < nStrips; i++ ) {

				int nStripLen = (i * 2) + 3;

//if ( (8 == i) ) { //(nStrips - 1) == i ) { // DBUG

				output.IndexedTriangleStrip(
					*(pIndices + firstIndex + 1) // should represent the lowest index number used.
					,firstIndex
					,nStripLen - 2
					,dbug_dump_indices
				);

//} // DBUG

				firstIndex += nStripLen;

			}

			output.End();

			delete [] pIndices;
			delete [] pVertices;

			return true;

		}

		// --------------------------------------------------------------------

		template< class OUTPUT, class VERTEX, class LERP > bool
		operator()(
			OUTPUT & output
			,const VERTEX & a, const VERTEX & b, const VERTEX & c
			,const int nStrips
			,const LERP & dummy
		) {

			TNOPFilter<VERTEX> nop;

			return (*this)( output, a, b, c, nStrips, nop, dummy );

		}

	}; // TNStripsTessellateTriangle

		//
		//	X_RenderSpheroidInSideCube()
		//

		void
		X_RenderSpheroidInSideCube(
			const FLOAT x, const FLOAT y, const FLOAT z
			,const FLOAT w, const FLOAT h, const FLOAT depth
			,const int nStrips
			,const DWORD colorA
			,const DWORD colorB
			,const DWORD colorC
			,const DWORD colorD
			,const DWORD colorE
			,const DWORD colorF
			,const D3DXMATRIX * pWorldMat
		)
		{
			if ( 0 >= nStrips ) {

				return;

			}

			// create translate and scale matrix
			// --------------------------------------------------------------------

			D3DXMATRIX translateMatrix;

			D3DXMatrixTranslation( &translateMatrix, x, y, z );

			D3DXMATRIX scaleMatrix;

			D3DXMatrixScaling( &scaleMatrix, w * 0.5f, h * 0.5f, depth * 0.5f );

			D3DXMATRIX transformMatrix;

			D3DXMatrixMultiply( &transformMatrix, &scaleMatrix, &translateMatrix );

			// Combine with the incomming world matrix
			// --------------------------------------------------------------------

			if ( pWorldMat ) {

				D3DXMATRIX worldMatrix;

				D3DXMatrixMultiply( &worldMatrix, &transformMatrix, pWorldMat );

				m_X.pd3dDevice->SetTransform( D3DTS_WORLD, &worldMatrix );

			} else {

				m_X.pd3dDevice->SetTransform( D3DTS_WORLD, &transformMatrix );

			}

			// --------------------------------------------------------------------

			// Build the triangles
			// --------------------------------------------------------------------

			D3DXVECTOR3 va( +0.0f, +1.0f, +0.0f );
			D3DXVECTOR3 vb( -1.0f, +0.0f, +0.0f );
			D3DXVECTOR3 vc( +0.0f, +0.0f, +1.0f );
			D3DXVECTOR3 vd( +1.0f, +0.0f, +0.0f );
			D3DXVECTOR3 ve( +0.0f, +0.0f, -1.0f );
			D3DXVECTOR3 vf( +0.0f, -1.0f, +0.0f );

			ARGH_VERTEX a( va, va, colorA );
			ARGH_VERTEX b( vb, vb, colorB );
			ARGH_VERTEX c( vc, vc, colorC );
			ARGH_VERTEX d( vd, vd, colorD );
			ARGH_VERTEX e( ve, ve, colorE );
			ARGH_VERTEX f( vf, vf, colorF );

			ARGH_VERTEX dbug_1( va, va, D3DCOLOR_XRGB(255,0,0) );
			ARGH_VERTEX dbug_2( vb, vb, D3DCOLOR_XRGB(0,255,0) );
			ARGH_VERTEX dbug_3( ve, ve, D3DCOLOR_XRGB(0,0,255) );

			ARGH_VERTEX triangles[] = {

#if 1

				dbug_1, dbug_2, dbug_3 // test a single triangle

#else

					a, c, b
				,	a, d, c
				,	a, e, d
				,	a, b, e

				,	f, b, c 
				,	f, c, d
				,	f, d, e
				,	f, e, b

#endif

			};

			// setup the render 'context'
			// --------------------------------------------------------------------

			m_X.pd3dDevice->SetIndices( NULL, 0 );
			m_X.pd3dDevice->SetStreamSource( 0, NULL, sizeof(ARGH_VERTEX) );
			m_X.pd3dDevice->SetVertexShader( ARGH_VERTEX::eFVFType );

			_ASSERT( sizeof(ARGH_VERTEX) == D3DXGetFVFVertexSize(ARGH_VERTEX::eFVFType) );

			// Render each triangle strip
			// --------------------------------------------------------------------

			TOutputHelper<ARGH_VERTEX> output( m_X.pd3dDevice );

			int nTriangles = (sizeof(triangles)/sizeof(triangles[0]))/3;

			for ( int t = 0; t < nTriangles; t++ ) {

				int i = t * 3;

				BPT::TNStripsTessellateTriangle tessellator;

				tessellator(
					output
					,triangles[ i + 0 ]
					,triangles[ i + 1 ]
					,triangles[ i + 2 ]
					,nStrips
//					,TUnitSphereFilter<ARGH_VERTEX>()
					,T_Lerp<ARGH_VERTEX>()
				);

			}

		}

#endif // BROKEN BROKEN DONT USE!!!

}; // namespace BPT

// ----------------------------------------------------------------------------

#endif // SUBDIVISION_17CE6AC8_BF45_431e_8346_653253603E44_INCLUDED

