// BPTCamera.h

#pragma once

#if !defined( BPTCAMERA_D3866EC2_1B98_48eb_A852_FF3142773939_INCLUDED )
#define BPTCAMERA_D3866EC2_1B98_48eb_A852_FF3142773939_INCLUDED

// ----------------------------------------------------------------------------

#include <limits>
#include <D3d8types.h>
#include <D3dx8math.h>

// ----------------------------------------------------------------------------

namespace BPT {

	//
	//	CD3DCamera
	//

	class CD3DCamera {

	private:

		// Attributes for view matrix

		D3DXVECTOR3		m_vEyePt;
		D3DXVECTOR3		m_vLookatPt;
		D3DXVECTOR3		m_vUpVec;
		D3DXVECTOR3		m_vView;
		D3DXVECTOR3		m_vCross;
		D3DXMATRIX		m_matView;

		// Special matrix for billboarding effects

		D3DXMATRIX		m_matBillboard; 

		// tangent variable for screen coord to view coord projection

		FLOAT			m_tan_of_half_fov;
		D3DXMATRIX		m_InverseMatView;

		// Attributes for projection matrix

		FLOAT			m_fFOV;         
		FLOAT			m_fAspect;
		FLOAT			m_fNearPlane;
		FLOAT			m_fFarPlane;
		D3DXMATRIX		m_matProj;
		D3DVIEWPORT8	m_Viewport;

	public:

		const FLOAT GetNearPlane() const { return m_fNearPlane; }
		const FLOAT GetFarPlane() const { return m_fFarPlane; }

		// --------------------------------------------------------------------

		const D3DXVECTOR3& GetEyePt() const { return m_vEyePt; }
		const D3DXVECTOR3& GetLookatPt() const { return m_vLookatPt; }
		const D3DXVECTOR3& GetUpVec() const { return m_vUpVec; }
		const D3DXVECTOR3& GetViewDir() const { return m_vView; }
		const D3DXVECTOR3& GetCross() const { return m_vCross; }

		// --------------------------------------------------------------------

		const D3DXMATRIX& GetViewMatrix() const { return m_matView; }
		const D3DXMATRIX& GetBillboardMatrix() const { return m_matBillboard; }
		const D3DXMATRIX& GetProjMatrix() const { return m_matProj; }
		const D3DXMATRIX& GetInverseViewMatrix() const { return m_InverseMatView; }

		// --------------------------------------------------------------------

		const D3DVIEWPORT8& GetViewport() const { return m_Viewport; }

		// --------------------------------------------------------------------

		void SetViewport( const D3DVIEWPORT8 & viewport ) {

			m_Viewport = viewport;

		}

		void SetViewport(
			const DWORD X
			,const DWORD Y
			,const DWORD Width
			,const DWORD Height
			,const float MinZ
			,const float MaxZ
		) {

			m_Viewport.X = X;
			m_Viewport.Y = Y;
			m_Viewport.Width = Width;
			m_Viewport.Height = Height;
			m_Viewport.MinZ = MinZ;
			m_Viewport.MaxZ = MaxZ;

		}

		// --------------------------------------------------------------------

		void SetViewParams(
			const D3DXVECTOR3 & vEyePt
			,const D3DXVECTOR3 & vLookatPt
			,const D3DXVECTOR3 & vUpVec
		) {

			// Set attributes for the view matrix

			m_vEyePt    = vEyePt;
			m_vLookatPt = vLookatPt;
			m_vUpVec    = vUpVec;

			D3DXVec3Normalize( &m_vView, &(m_vLookatPt - m_vEyePt) );
			D3DXVec3Cross( &m_vCross, &m_vView, &m_vUpVec );

			D3DXMatrixLookAtLH( &m_matView, &m_vEyePt, &m_vLookatPt, &m_vUpVec );
			D3DXMatrixInverse( &m_InverseMatView, NULL, &m_matView );

			// setup the billboard matrix

			m_matBillboard = m_InverseMatView;
			m_matBillboard._41 = 0.0f;
			m_matBillboard._42 = 0.0f;
			m_matBillboard._43 = 0.0f;

		}

		// --------------------------------------------------------------------

		void SetProjParams(
			const FLOAT fFOV
			,const FLOAT fAspect
			,const FLOAT fNearPlane
			,const FLOAT fFarPlane
		) {

			D3DXMatrixPerspectiveFovLH(
				&m_matProj
				,m_fFOV = fFOV
				,m_fAspect = fAspect
				,m_fNearPlane = fNearPlane
				,m_fFarPlane = fFarPlane
			);

			m_tan_of_half_fov = tanf( fFOV * 0.5f );

		}

		// --------------------------------------------------------------------

		void ConvertScreenCoordToRay(
			const int x
			,const int y
			,D3DXVECTOR3 & nearVec
			,D3DXVECTOR3 & farVec
		) {

			_ASSERT( m_Viewport.Width );
			_ASSERT( m_Viewport.Height );

			float dx = m_tan_of_half_fov * 
				(((float)x / (m_Viewport.Width * 0.5f)) - 1.0f) / m_fAspect;

			float dy = m_tan_of_half_fov * 
				(1.0f - ((float)y / (m_Viewport.Height * 0.5f)));

			nearVec = D3DXVECTOR3( dx * m_fNearPlane, dy * m_fNearPlane, m_fNearPlane );
			farVec = D3DXVECTOR3( dx * m_fFarPlane, dy * m_fFarPlane, m_fFarPlane );

			D3DXVec3TransformCoord( &nearVec, &nearVec, &m_InverseMatView );
			D3DXVec3TransformCoord( &farVec, &farVec, &m_InverseMatView );

		}

		// --------------------------------------------------------------------

		D3DXVECTOR3* 
		Project( D3DXVECTOR3* pOut, const D3DXVECTOR3* pV, const D3DXMATRIX * pWorldMat ) {

			return D3DXVec3Project(
				pOut, pV, &m_Viewport, &m_matProj, &m_matView, pWorldMat
			);

		}

		D3DXVECTOR3* 
		Unproject( D3DXVECTOR3* pOut, const D3DXVECTOR3* pV, const D3DXMATRIX * pWorldMat ) {

			return D3DXVec3Unproject(
				pOut, pV, &m_Viewport, &m_matProj, &m_matView, pWorldMat
			);

		}

		// --------------------------------------------------------------------

		D3DXMATRIX 
		MakeDecalProjectionMatrix( const float delta, const float pz ) {

			/*

				NOTE: This code is based on Eric Lengyel's article
				Article: "Tweaking a Vertex's Projected Depth Value"
				Game Gems, Page 361 : ISBN 1-58450-049-2

			*/

			D3DXMATRIX projMat = GetProjMatrix();

			const FLOAT n = GetNearPlane();

			const FLOAT f = GetFarPlane();

			FLOAT divisor = ((f + n) * pz * (pz + delta));

			if ( std::numeric_limits<FLOAT>::epsilon() <= fabsf(divisor) ) {

				FLOAT adjustment = -2.0f * f * n * delta / divisor;

				// set Matrix postion 3,3

				projMat( 2, 2 ) *= (1.0f + adjustment);

			}

			return projMat;

		}

		D3DXMATRIX 
		MakeDecalProjectionMatrix(
			const D3DXVECTOR3 * pV
			,const D3DXMATRIX * pWorldMat
			,const int zBitDepth = 16
		) {

			D3DXVECTOR3 p;

			Project( &p, pV, pWorldMat );

			// ------------------

#if 1 // use fudge factor

			float fDelta = std::numeric_limits<FLOAT>::epsilon() * 50.0f;

			return MakeDecalProjectionMatrix( fDelta, p.z );

#else

			// this was an attempt to calculate the smallest value
			// that would make a difference.  I'm not sure why exactly but 
			// this value seems to cause the depth to be pretty big.

			const FLOAT n = GetNearPlane();
			const FLOAT f = GetFarPlane();
			const FLOAT k = (f - n) / (2.0f * f * n * (float)((1 << zBitDepth)-1));

			// ------------------

			if ( 1.0f != (k * p.z) ) {

				float fDelta = ((k * (p.z * p.z)) / (1.0f - (k * p.z)));

				return MakeDecalProjectionMatrix( fDelta, p.z );

			}

			return GetProjMatrix();
#endif

		}

		// --------------------------------------------------------------------

		bool PointFacesCamera( const D3DXVECTOR3 * pV, const D3DXVECTOR3 * pNormal ) const {

			D3DXVECTOR3 d = m_vEyePt - *pV;

			return (0.0f < D3DXVec3Dot( pNormal, &d ));

		}

		// --------------------------------------------------------------------

		CD3DCamera() {

			// Set attributes for the view matrix

			SetViewParams(
				D3DXVECTOR3(0.0f,0.0f,0.0f)
				,D3DXVECTOR3(0.0f,0.0f,1.0f)
				,D3DXVECTOR3(0.0f,1.0f,0.0f)
			);

			// Set attributes for the projection matrix

			SetProjParams( D3DX_PI/4, 1.0f, 1.0f, 1000.0f );

			// setup the viewport

			SetViewport( 0, 0, 640, 480, 0.0f, 1.0f );

		}

	};

}; // namespace BPT

// ----------------------------------------------------------------------------

#endif // BPTCAMERA_D3866EC2_1B98_48eb_A852_FF3142773939_INCLUDED)

