// BoxOfBoxes.h: -- 
//
//	Copyright (c) 2002, Brad P. Taylor, LLC
//
//	All rights reserved, unauthorized reproduction prohibited
//
//	-- FILE NOTES --
//
//////////////////////////////////////////////////////////////////////

#if !defined( BOXOFBOXES_7B58565E_0448_461f_98CC_3BD765D59AA0 )
#define BOXOFBOXES_7B58565E_0448_461f_98CC_3BD765D59AA0

#if _MSC_VER > 1000
#pragma once
#endif

// ----------------------------------------------------------------------------

#include <D3dx8mesh.h>

// ----------------------------------------------------------------------------

namespace BPT {

	//
	//	TCreateBoxOfBoxes()
	//

	template< class T >
	HRESULT
	TCreateBoxOfBoxes( 
		T & fnDefinedBox
		,LPDIRECT3DDEVICE8 pd3dDevice
		,const int xCount
		,const int yCount
		,const int zCount
		,const D3DXVECTOR3 & firstBoxCenter
		,const D3DXVECTOR3 & innerBoxDimension
		,const D3DXVECTOR3 & innerBoxDelta
		,const bool bUseSameAttribute
		,const bool bCenterOnAxis
		,const DWORD dwOptions
		,const DWORD dwFVF
		,LPD3DXMESH * ppMesh
	)
	{
		// ----------------------------------------------------------------

		if ( !ppMesh ) {

			return E_FAIL;

		}

		*ppMesh = NULL;

		// Figure out the number of defined boxes
		// ----------------------------------------------------------------

		DWORD dwDefinedBoxes = 0;

		{
			for ( int z = 0; z < zCount; z++ ) {

				for ( int y = 0; y < yCount; y++ ) {

					for ( int x = 0; x < xCount; x++ ) {

						if ( fnDefinedBox( x, y, z ) ) {

							++dwDefinedBoxes;

						}

					}

				}

			}

		}

		if ( 0 == dwDefinedBoxes ) {

			return E_FAIL;

		}

		// Create the raw mesh
		// ----------------------------------------------------------------

		LPD3DXMESH pBoxMesh;

		DWORD dwQuads = 6 * dwDefinedBoxes;
		DWORD dwWantFaces = dwQuads * 2;
		DWORD dwWantVerts = dwQuads * 4;

		HRESULT hr = D3DXCreateMeshFVF(
			dwWantFaces, dwWantVerts, dwOptions, dwFVF, pd3dDevice, &pBoxMesh
		);

		if ( FAILED( hr ) ) {

			return hr;

		}

		// ----------------------------------------------------------------

		DWORD dwNumFaces = pBoxMesh->GetNumFaces();

		_ASSERT( dwWantFaces != dwNumFaces );

		DWORD dwNumVertices = pBoxMesh->GetNumVertices();

		_ASSERT( dwWantVerts != dwNumVertices );

		// Fill in the attribute table
		// ----------------------------------------------------------------

		{
			LPDWORD pAttributeData;

			if ( FAILED( hr = pBoxMesh->LockAttributeBuffer( 0, &pAttributeData ) ) ) {

				pBoxMesh->Release();

				return hr;

			}

			if ( bUseSameAttribute ) {

				ZeroMemory( pAttributeData, dwNumFaces * sizeof(DWORD) );

			} else {

				DWORD quadAttributes = dwDefinedBoxes * 2;

				for ( DWORD quadFace = 0; quadFace < 6; quadFace++ ) {

					for ( DWORD attribute = 0; attribute < quadAttributes; attribute++ ) {

						*pAttributeData++ = quadFace;

					}

				}

			}

			pBoxMesh->UnlockAttributeBuffer();
		}

		// Fill in the index table
		// ----------------------------------------------------------------

		{
			LPBYTE pIndexData;

			if ( FAILED( hr = pBoxMesh->LockIndexBuffer( 0, &pIndexData ) ) ) {

				pBoxMesh->Release();

				return hr;

			}

			WORD * pIndices = (WORD *)( pIndexData );

			int numQuads = dwQuads;

			int baseIndex = 0;

			for ( int quad = 0; quad < numQuads; quad++ ) {

				*pIndices++ = (baseIndex + 3);
				*pIndices++ = (baseIndex + 0);
				*pIndices++ = (baseIndex + 1);
				*pIndices++ = (baseIndex + 3);
				*pIndices++ = (baseIndex + 1);
				*pIndices++ = (baseIndex + 2);

				baseIndex += 4;

			}

			pBoxMesh->UnlockVertexBuffer();

		}

		// Fill in the vertex table
		// ----------------------------------------------------------------

		{
			LPBYTE pVertexData;

			if ( FAILED( hr = pBoxMesh->LockVertexBuffer( 0, &pVertexData ) ) ) {

				pBoxMesh->Release();

				return hr;

			}

			DWORD fvfSize = D3DXGetFVFVertexSize( dwFVF );

			ZeroMemory(
				pVertexData
				,fvfSize * dwWantVerts
			);

			// Find the offset for the various FVF fields
			// ----------------------------------------------------------------

			DWORD dwNormalOffset = (D3DFVF_NORMAL & dwFVF) ? CalcFVFOffset(dwFVF,D3DFVF_NORMAL) : 0;

			DWORD dwUVOffset = (D3DFVF_TEX1 & dwFVF) ? CalcFVFOffset(dwFVF,D3DFVF_TEX1) : 0;

			// Fill in the verts
			// ----------------------------------------------------------------

			// Setup the reset position for the box

			D3DXVECTOR3 reset[ 8 ];

			D3DXVECTOR3 half = innerBoxDimension * 0.5f;

			// front

			reset[ 0 ].x = firstBoxCenter.x - half.x;
			reset[ 0 ].y = firstBoxCenter.y + half.y;
			reset[ 0 ].z = firstBoxCenter.z - half.z;

			reset[ 1 ].x = firstBoxCenter.x + half.x;
			reset[ 1 ].y = firstBoxCenter.y + half.y;
			reset[ 1 ].z = firstBoxCenter.z - half.z;

			reset[ 2 ].x = firstBoxCenter.x + half.x;
			reset[ 2 ].y = firstBoxCenter.y - half.y;
			reset[ 2 ].z = firstBoxCenter.z - half.z;

			reset[ 3 ].x = firstBoxCenter.x - half.x;
			reset[ 3 ].y = firstBoxCenter.y - half.y;
			reset[ 3 ].z = firstBoxCenter.z - half.z;

			// back

			reset[ 4 ].x = firstBoxCenter.x - half.x;
			reset[ 4 ].y = firstBoxCenter.y + half.y;
			reset[ 4 ].z = firstBoxCenter.z + half.z;

			reset[ 5 ].x = firstBoxCenter.x + half.x;
			reset[ 5 ].y = firstBoxCenter.y + half.y;
			reset[ 5 ].z = firstBoxCenter.z + half.z;

			reset[ 6 ].x = firstBoxCenter.x + half.x;
			reset[ 6 ].y = firstBoxCenter.y - half.y;
			reset[ 6 ].z = firstBoxCenter.z + half.z;

			reset[ 7 ].x = firstBoxCenter.x - half.x;
			reset[ 7 ].y = firstBoxCenter.y - half.y;
			reset[ 7 ].z = firstBoxCenter.z + half.z;

			// fill in the normal table

			D3DXVECTOR3 faceNormals[ 6 ] = {
					D3DXVECTOR3( +0.0f, +0.0f, -1.0f)
				,	D3DXVECTOR3( +0.0f, +1.0f, +0.0f)
				,	D3DXVECTOR3( +0.0f, +0.0f, +1.0f)
				,	D3DXVECTOR3( +0.0f, -1.0f, +0.0f)
				,	D3DXVECTOR3( -1.0f, +0.0f, +0.0f)
				,	D3DXVECTOR3( +1.0f, +0.0f, +0.0f)
			};

			// fill in the uv table (each face could have different uv's)

			D3DXVECTOR3 faceUVs[ 6 ][ 4 ] = {

				{
						D3DXVECTOR3( 0.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 1.0f, 0.0f)
					,	D3DXVECTOR3( 0.0f, 1.0f, 0.0f)
				}
				,{
						D3DXVECTOR3( 0.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 1.0f, 0.0f)
					,	D3DXVECTOR3( 0.0f, 1.0f, 0.0f)
				}
				,{
						D3DXVECTOR3( 0.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 1.0f, 0.0f)
					,	D3DXVECTOR3( 0.0f, 1.0f, 0.0f)
				}
				,{
						D3DXVECTOR3( 0.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 1.0f, 0.0f)
					,	D3DXVECTOR3( 0.0f, 1.0f, 0.0f)
				}
				,{
						D3DXVECTOR3( 0.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 1.0f, 0.0f)
					,	D3DXVECTOR3( 0.0f, 1.0f, 0.0f)
				}
				,{
						D3DXVECTOR3( 0.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 0.0f, 0.0f)
					,	D3DXVECTOR3( 1.0f, 1.0f, 0.0f)
					,	D3DXVECTOR3( 0.0f, 1.0f, 0.0f)
				}
			};

			// fill in the vertex generation order

			int faceIndices[ 6 ][ 4 ] = {

					{ 0, 1, 2, 3 }		// front
				,	{ 4, 5, 1, 0 }		// top
				,	{ 7, 6, 5, 4 }		// back
				,	{ 3, 2, 6, 7 }		// bottom
				,	{ 4, 0, 3, 7 }		// left
				,	{ 1, 5, 6, 2 }		// right

			};

			// build each 'face' in the proper order

			for ( int f = 0; f < 6; f++ ) {

				D3DXVECTOR3 verts[ 8 ];

				D3DXVECTOR3 normal = faceNormals[ f ];

				D3DXVECTOR3 * pUVs = faceUVs[ f ];

				int * idx = faceIndices[ f ];

				// reset z's

				for ( int r = 0; r < 4; r++ ) { verts[ idx[ r ] ].z = reset[ idx[ r ] ].z; }

				for ( int z = 0; z < zCount; z++ ) {

					// reset y's

					for ( int r = 0; r < 4; r++ ) { verts[ idx[ r ] ].y = reset[ idx[ r ] ].y; }

					for ( int y = 0; y < yCount; y++ ) {

						// reset x's

						for ( int r = 0; r < 4; r++ ) { verts[ idx[ r ] ].x = reset[ idx[ r ] ].x; }

						for ( int x = 0; x < xCount; x++ ) {

							// check to see if this box is solid

							if ( !fnDefinedBox( x, y, z ) ) {

								for ( int a = 0; a < 4; a++ ) {
	
									verts[ idx[ a ] ].x += innerBoxDelta.x;

								}

								continue;

							} else {

								// should get the UV's here?

							}

							for ( int a = 0; a < 4; a++ ) {

								// fill in the vertex data

								float * pXYZ = (float *)pVertexData;

								*(pXYZ + 0) = verts[ idx[ a ] ].x;
								*(pXYZ + 1) = verts[ idx[ a ] ].y;
								*(pXYZ + 2) = verts[ idx[ a ] ].z;

								// normals

								if ( D3DFVF_NORMAL & dwFVF ) {

									float * pNormal = (float *)(pVertexData + dwNormalOffset);

									*(pNormal + 0) = normal.x;
									*(pNormal + 1) = normal.y;
									*(pNormal + 2) = normal.z;

								}

								// UV's

								if ( D3DFVF_TEX1 & dwFVF ) {

									float * pUV = (float *)(pVertexData + dwUVOffset);

									*(pUV + 0) = pUVs[ a ].x;
									*(pUV + 1) = pUVs[ a ].y;

								}

								// move to the next vertex

								pVertexData += fvfSize;
			
								// advance x's

								verts[ idx[ a ] ].x += innerBoxDelta.x;
							
							}

						}

						// advance y's

						for ( int a = 0; a < 4; a++ ) { verts[ idx[ a ] ].y += innerBoxDelta.y; }

					}

					// advance z's

					for ( int a = 0; a < 4; a++ ) { verts[ idx[ a ] ].z += innerBoxDelta.z; }

				}

			}

			pBoxMesh->UnlockVertexBuffer();

		}

		// ----------------------------------------------------------------

		if ( bCenterOnAxis ) {

			if ( FAILED( hr = CenterMeshOnCoordinate( pBoxMesh, D3DXVECTOR3(0.0f,0.0f,0.0f) ) ) ) {

				pBoxMesh->Release();

				return hr;

			}

		}

		// ----------------------------------------------------------------

		*ppMesh = pBoxMesh;

		return S_OK;

	}

}; // namespace BPT

#endif /* defined(BOXOFBOXES_7B58565E_0448_461f_98CC_3BD765D59AA0) */

