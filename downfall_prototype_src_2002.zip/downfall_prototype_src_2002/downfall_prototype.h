#pragma once

#ifndef AFX_3D_DOWNFALL_H__BBECA644_3B71_11D6_A01F_00D009C96677__INCLUDED_
#define AFX_3D_DOWNFALL_H__BBECA644_3B71_11D6_A01F_00D009C96677__INCLUDED_

#include "resource.h"

#include "BPTCamera.h"
#include "My3DXMesh.h"
#include "subdivision.h"
#include "BPTGeometry.h"

// ----------------------------------------------------------------------------

#include "gameplay.h"
#include "DownfallGameData.h"

#define BPT_TEST_MESH
#define BPT_USE_SLEEP_TO_SLOWDOWN_GAME

#if defined(BPT_TEST_MESH)
//#define USE_SQUARE_ASPECT_RATIO
#endif

namespace HACKDATA {

	extern int g_nTrianglesProcessed;

};

//-----------------------------------------------------------------------------
// Defines, and constants
//-----------------------------------------------------------------------------
// TODO: change "DirectX AppWizard Apps" to your name or the company name
#define DXAPP_KEY        TEXT("Software\\www.thinkbpt.com\\3D_Downfall_Prototype")

// DirectInput action mapper reports events only when buttons/axis change
// so we need to remember the present state of relevant axis/buttons for 
// each DirectInput device.  The CInputDeviceManager will store a 
// pointer for each device that points to this struct
struct InputDeviceState
{
    // TODO: change as needed
    FLOAT fAxisRotateLR;
    BOOL  bButtonRotateLeft;
    BOOL  bButtonRotateRight;

    FLOAT fAxisRotateUD;
    BOOL  bButtonRotateUp;
    BOOL  bButtonRotateDown;

    BOOL  bButtonPlaySoundButtonDown;
};


// Struct to store the current input state
struct UserInput
{
    // TODO: change as needed
    FLOAT fAxisRotateUD;
    FLOAT fAxisRotateLR;
    BOOL bPlaySoundButtonDown;
    BOOL bDoConfigureInput;
    BOOL bDoConfigureDisplay;
};

//-----------------------------------------------------------------------------
// Name: class CMyD3DApplication
// Desc: Application class. The base class (CD3DApplication) provides the 
//       generic functionality needed in all Direct3D samples. CMyD3DApplication 
//       adds functionality specific to this sample program.
//-----------------------------------------------------------------------------

// ----------------------------------------------------------------------------

class CMyD3DApplication : public CD3DApplication
{

	// ************************************************************************

private: // data

	//
	//	GameInternals
	//

	class GameInternals {

	public:

		typedef GameInternals this_type;

#if defined(BPT_USE_SLEEP_TO_SLOWDOWN_GAME)

		DWORD m_dwNextTime;

		enum {

				eTIMER_FPS			= (BPT_USE_FPS)
			,	eTIMER_DELAY		= (1000/eTIMER_FPS)

		};

#endif

	public: // data

		// ---------------

		typedef DOWNFALL::TInputMovableShape<this_type,3> player_input_type;

		player_input_type m_PlayerInput;

		// ---------------

		typedef DOWNFALL::TPuzzleGameCore<this_type,player_input_type,32,64> puzzle_core_type;

		puzzle_core_type m_PuzzleCore;

		// ---------------

		int m_Points;

		int m_nLevel;

		int m_LevelCountdownReset;

		int m_LevelCountDown;

		int m_DifficultySpeed;

		// ---------------

		RECT m_NextPieceRect;

		RECT m_BoardRect;

		SIZE m_PieceSize;

		// ---------------

		SIZE m_Resolution;

		POINT m_MousePos;

		POINT m_MouseButtonDown;

		bool m_bAppActive;

		HWND m_hwnd;

#if defined(BPT_TEST_MESH)

		enum {

			MAX_PIECE_MESHES	= 16

		};

		BPT::CMy3DXMesh m_PieceMesh[ MAX_PIECE_MESHES ];

		BPT::CMy3DXMesh m_BigSphereBackgroundMesh;

		LPDIRECT3DTEXTURE8 m_pBigSphereTexture;

#endif

	private: // methods

		DWORD ReadMillisecondTimer() const {

			return timeGetTime();

		}

	public: // interface

		GameInternals() {

			m_Points = 0;

			m_nLevel = 1;

			KickStartLevelCountdown();

			m_pBigSphereTexture = 0;

			SetRectEmpty( &m_NextPieceRect );
			SetRectEmpty( &m_BoardRect );

			m_PieceSize.cx = 0;
			m_PieceSize.cy = 0;

			m_Resolution.cx = 0;
			m_Resolution.cy = 0;

			m_MousePos.x = 0;
			m_MousePos.y = 0;

			m_bAppActive = false;

#if defined(BPT_USE_SLEEP_TO_SLOWDOWN_GAME)

			m_dwNextTime = ReadMillisecondTimer();

#endif // defined(BPT_USE_SLEEP_TO_SLOWDOWN_GAME)

		}

		// setup
		// --------------------------------------------------------------------

		bool 
		SetupGameInternals(
			const DOWNFALL::Shape * pShapes
			,const int rows
			,const int cols
			,const RECT * pRect
			,const int connectN
			,const DOWNFALL::InputShapeSet ** ppShapeSets
			,const int nShapeSets
			,HWND hwnd
		) {

			m_hwnd = hwnd;

			if ( !m_PuzzleCore.SetPerFrameMoverDelta( MACRO_SCALE_TO_FRAMERATE(15) ) ) {

				return false;

			}

			if ( !m_PuzzleCore.SetShapeSet( pShapes ) ) {

				// ATLTRACE( "Unable to set shape set\n" );

				return false;

			}

			int hiddenRows = 3;

			if ( !m_PuzzleCore.SetDimensions( rows + hiddenRows, cols, hiddenRows ) ) {

				// ATLTRACE( "Unable to set dimensions %d, %d\n", rows, cols );

				return false;

			}

			if ( !m_PuzzleCore.SetupGroupActivationPolicy( connectN, 20 ) ) {

				return false;

			}

			m_BoardRect = *pRect;

			m_PieceSize.cx = (pRect->right - pRect->left) / cols;
			m_PieceSize.cy = (pRect->bottom - pRect->top) / rows;

			SIZE centerAdjustment = { m_PieceSize.cx/2, m_PieceSize.cy/2 };

			m_PuzzleCore.SetupLocations(
				pRect->left + centerAdjustment.cx
				,pRect->top - (hiddenRows * m_PieceSize.cy) + centerAdjustment.cy
				,0
				,m_PieceSize.cy
				,m_PieceSize.cx
				,0
			);

			// --------------------------------------------------------------------

			m_NextPieceRect.left = m_Resolution.cx - ((player_input_type::ELEMENTS + 1) * m_PieceSize.cx);
			m_NextPieceRect.top = m_BoardRect.top;
			m_NextPieceRect.right = m_NextPieceRect.left + ((player_input_type::ELEMENTS + 1) * m_PieceSize.cx);
			m_NextPieceRect.bottom = m_NextPieceRect.top + ((player_input_type::ELEMENTS + 1) * m_PieceSize.cy);

			// setup input
			// --------------------------------------------------------------------

			m_PlayerInput.KickStart(
				&m_PuzzleCore
				,hiddenRows ? hiddenRows - 1 : 1
				,cols / 2
				,ppShapeSets
				,nShapeSets
			);

			return true;

		}

		bool GameBootstrap( const int width, const int height, HWND hwnd ) {

			m_Resolution.cx = width;
			m_Resolution.cy = height;

//			SIZE playField = { 9, 18 };
//			SIZE playField = { 8, 16 };
			SIZE playField = { 7, 14 }; // nice

			SIZE pieceSize;

#if defined(USE_SQUARE_ASPECT_RATIO)
			
			pieceSize.cx = 24; //(30 * m_Resolution.cx) / 640;
			pieceSize.cy = 24; //(30 * m_Resolution.cy) / 480;

#else

			pieceSize.cx = (30 * m_Resolution.cx) / 640;
			pieceSize.cy = (24 * m_Resolution.cy) / 480;

#endif

#if 1 // scale to board ratio

			pieceSize.cx = (pieceSize.cx * 9  ) / playField.cx;
			pieceSize.cy = (pieceSize.cy * 18 ) / playField.cy;

#endif

			SIZE boardSize = { playField.cx * pieceSize.cx, playField.cy * pieceSize.cy };

			RECT boardRect;
			
			boardRect.left = (m_Resolution.cx - boardSize.cx) / 2;
			boardRect.top = (m_Resolution.cy - boardSize.cy) / 2;
			boardRect.right = boardRect.left + boardSize.cx;
			boardRect.bottom = boardRect.top + boardSize.cy;

#if 1 // fallout

			const DOWNFALL::Shape * pUseShapes = GAMEDATA::g_FalloutShapes;
//			const DOWNFALL::InputShapeSet ** pUseShapeSet = GAMEDATA::g_pExtendedFalloutShapeOddsTable;
			const DOWNFALL::InputShapeSet ** pUseShapeSet = GAMEDATA::g_pFalloutShapeOddsTable;

#else

			const DOWNFALL::InputShapeSet ** pUseShapeSet = GAMEDATA::g_pTwoUpShapeOddsTable;
			const DOWNFALL::Shape * pUseShapes = GAMEDATA::g_GroupShapes;
#endif

			int nConnectedMatches = 0; // probably should be hooked up to piece type rules...

//			int nPieces = 4;

			return SetupGameInternals(
				pUseShapes, playField.cy, playField.cx, 
				&boardRect, nConnectedMatches,
				pUseShapeSet, 1, hwnd
			);

		}

		// data
		// ------------------------------------------------------------------------

		//
		//	SDXInfo
		//

		struct SDXInfo {

			// ----------------------------------------------------------------

			LPDIRECT3D8             pD3D;
			LPDIRECT3DDEVICE8       pd3dDevice;
			D3DCAPS8				d3dCaps;

			bool					bShowWireframe;
			bool					b2dDisplay;
			bool					bGoFast;
			bool					bWiggle;
			bool					bPieceBorders;
			bool					bAntialiaseEdges;
			bool					bGradientBackground;
			bool					bUseCubes;

			D3DXMATRIX				boardWorldMat;

			DWORD					dwZbufferOn;

			BPT::CD3DCamera			camera;

			// ----------------------------------------------------------------

			SDXInfo() : pD3D(0)
				, pd3dDevice(0)
				, bShowWireframe(false)
				, b2dDisplay(false)
				, bGoFast(false)
				, bWiggle(false)
				, bPieceBorders(false)
				, bAntialiaseEdges(false)
				, dwZbufferOn( D3DZB_TRUE )
				, bGradientBackground( true )
				, bUseCubes( false )
			{

				D3DXMatrixIdentity( &boardWorldMat );

				ZeroMemory( &d3dCaps, sizeof(d3dCaps) );

			}

		};	// struct SDXInfo

		SDXInfo m_X;

		// ------------------------------------------------------------------------

		//
		//	SetupMatrices()
		//

		void SetupMatrices() {

			// For our world matrix, we will just leave it as the identity
			// --------------------------------------------------------------------

			// Default :)
			// --------------------------------------------------------------------

			D3DXMATRIX matWorld;

			D3DXMatrixIdentity( &matWorld );

			m_X.pd3dDevice->SetTransform( D3DTS_WORLD, &matWorld );

		}

		// ------------------------------------------------------------------------

		//
		//	X_FourColorRectangle()
		//

		void X_FourColorRectangle(
			const int x, const int y, const int w, const int h
			,const DWORD colorTL
			,const DWORD colorTR
			,const DWORD colorBL
			,const DWORD colorBR
		) {

			struct CUSTOMVERTEX {

				enum {

					eFVFType	= D3DFVF_XYZRHW | D3DFVF_DIFFUSE

				};

				float x, y, z, rhw;
				DWORD color;

			};

			FLOAT z = 0.0f;
			FLOAT rhw = 1.0f / (z * 990.0f + 10.0f);
			FLOAT x1 = (FLOAT)x - 0.5f;
			FLOAT x2 = (FLOAT)(x + w) - 0.5f;
			FLOAT y1 = (FLOAT)y - 0.5f;
			FLOAT y2 = (FLOAT)(y + h) - 0.5f;

			CUSTOMVERTEX verts[ 4 ] = {

					{ x1, y2, z, rhw, colorBL }
				,	{ x1, y1, z, rhw, colorTL }
				,	{ x2, y2, z, rhw, colorBR }
				,	{ x2, y1, z, rhw, colorTL }

			};

			m_X.pd3dDevice->SetVertexShader( CUSTOMVERTEX::eFVFType );

			m_X.pd3dDevice->DrawPrimitiveUP( D3DPT_TRIANGLESTRIP, 2, verts, sizeof(CUSTOMVERTEX) );
		}

		//
		//	X_SolidRectangle()
		//

		void X_SolidRectangle( const int x, const int y, const int w, const int h, const DWORD color ) {

			X_FourColorRectangle( x, y, w, h, color, color, color, color );

		}

		// ------------------------------------------------------------------------

		//
		//	X_Render3dCube()
		//

		void 
		X_Render3dCube(
			const FLOAT x, const FLOAT y, const FLOAT z,
			const FLOAT w, const FLOAT h, const FLOAT d,
			const DWORD color1, const DWORD color2,
			const DWORD color3, const DWORD color4,
			const bool bOnlyEdges,
			const bool bRenderEdges,
			const bool bAntialiasEdge,
			const D3DXMATRIX * pWorldMat,
			const int pieceType

		) {

#if defined(BPT_TEST_MESH)

			bool bPieceTypeHasMesh = false;

			if ( (!m_X.bUseCubes) && ((0 < pieceType) && (MAX_PIECE_MESHES > pieceType)) ) {

				bPieceTypeHasMesh = m_PieceMesh[ pieceType - 1 ].HasData();

			}

			if ( pWorldMat && bPieceTypeHasMesh ) {

				int pieceMeshIndex = pieceType - 1;

				// setup the material
				// ------------------------------------------------------------

				D3DMATERIAL8 material;

			    ZeroMemory( &material, sizeof(D3DMATERIAL8) );

				material.Diffuse = D3DXCOLOR( color1 );
				material.Ambient = D3DXCOLOR( color2 );
				material.Specular = D3DXCOLOR( 1.0f, 1.0f, 1.0f, 1.0f );
				material.Power = 5.0f;

				m_X.pd3dDevice->SetMaterial( &material );

				// ------------------------------------------------------------

				D3DXMATRIX translationMat;

				D3DXMatrixTranslation( &translationMat, x, y, z );

				D3DXMatrixMultiply( &translationMat, &translationMat, pWorldMat );

				// ------------------------------------------------------------

				FLOAT hw = w * 0.5f;
				FLOAT hh = h * 0.5f;
				FLOAT hd = d * 0.5f;

				if ( SUCCEEDED( m_PieceMesh[ pieceMeshIndex ].ConformToCubeThenDraw(
					translationMat
					,D3DXVECTOR3( -hw, -hh, -hd )
					,D3DXVECTOR3( +hw, +hh, +hd )
					,0
					,false
					,false
					) ) ) {

					HACKDATA::g_nTrianglesProcessed += m_PieceMesh[ pieceMeshIndex ].FaceCount();

					return ;

				}

			}

#endif

			// ----------------------------------------------------------------

		}

		// ------------------------------------------------------------------------

		//
		//	X_RenderPiece()
		//

		void X_RenderPiece(
			const DOWNFALL::Location & pos
			,const DOWNFALL::PieceType & piece
			,const bool bMover
			,puzzle_core_type::CElementTimer * pTimer
			,const FLOAT fXScale
			,const FLOAT fYScale
			,const FLOAT fZScale
			,const bool bOnlyEdges
			,const bool bRenderEdges
			,const bool bAntialiasEdge
			,const int alpha
			,const D3DXMATRIX & matrix
		) {

			int useAlpha = alpha;

			int pieceType = piece.ID();

#if 0 // show reserved
			if ( piece.IsReserved() ) {

				pieceType = 1;

			}
#endif

			if ( pieceType ) {

				SIZE offset = { 0, 0 };

				if ( bMover ) {

					offset.cx = 4;
					offset.cy = -4;

				} else {

					offset.cx = 1;
					offset.cy = 1;

				}

#if 0 // make magic pieces throb
				if ( piece.IsGroupActivator() ) {

					float t = (float)timeGetTime() * 0.01f;

					int iScale = ((int)( 4.0f * (0.0f + sinf( t )) ) + 1);

					offset.cx *= iScale; 
					offset.cy *= iScale; 

//					useAlpha = (int)((float)alpha * fabsf( sinf( t ) )); // cheesy alpha effect

				}
#endif

#if 1 // scale so that the distortion matches the porportions of the 640x480...
				offset.cx = (offset.cx * m_PieceSize.cx * 100) / 3000;
				offset.cy = (offset.cy * m_PieceSize.cy * 100) / 2400;
#endif

				// if there is a timer scale the element
				// ------------------------------------------------------------

				FLOAT fPieceScale = 1.0f;

				bool bActiveTimer = false;

#if 1 // if disapearing
				if ( pTimer ) {

					int limit = pTimer->Limit();

					if ( limit ) {

						bActiveTimer = true;

						int current = pTimer->Current();

						offset.cx += ((m_PieceSize.cx/2) * current) / limit;
						offset.cy += ((m_PieceSize.cy/2) * current) / limit;

						useAlpha = alpha - ((alpha * current) / limit);

						const FLOAT HALF_PI = D3DX_PI * 0.5f;
						const FLOAT THREE_FOURTHS_PI = D3DX_PI * 0.75f;

						fPieceScale -= 0.75f * cosf( THREE_FOURTHS_PI + ((D3DX_PI * (FLOAT)current) / (FLOAT)limit) );

#if 1
						fPieceScale *= ((float)piece.GetMultiplier() + 0.125f); // this should be attached to chained explosions!
#else
						fPieceScale *= 1.5125f; // this should be attached to chained explosions!
#endif

					}

				}
#endif

				// select the color

				int r, g, b;

				switch ( pieceType ) {

				default: r = 255; g = 255; b = 255; break;
			
				case 0: r = 0; g = 0; b = 0; break;
				case 2: r = 255; g = 0; b = 0; break;
				case 3: r = 0; g = 255; b = 0; break;
				case 4: r = 0; g = 0; b = 255; break;
				case 5: r = 255; g = 0; b = 255; break;
				case 6: r = 255; g = 255; b = 0; break;
				case 7: r = 0; g = 255; b = 255; break;

#if COLOR_CYCLE_PIECE_1
				case 1: {
					int r = rand() & 255;
					int g = rand() & 255;
					int b = rand() & 255;
					}
					break;
#endif

				}

				DWORD color1  = D3DCOLOR_RGBA(r,g,b,useAlpha);
				DWORD color2 = D3DCOLOR_RGBA(r/2,g/2,b/2,useAlpha);
				DWORD color3  = D3DCOLOR_RGBA(r/4,g/4,b/4,useAlpha);
				DWORD color4 = D3DCOLOR_RGBA(r/8,g/8,b/8,useAlpha);

				if ( bAntialiasEdge ) {

					color3 = color1;
					color4 = color2;

				}

				// finally do the render
				// ------------------------------------------------------------

				if ( m_X.b2dDisplay ) {

					X_SolidRectangle(
						pos.x + offset.cx - (m_PieceSize.cx/2)
						,pos.y + offset.cy - (m_PieceSize.cy/2)
						,m_PieceSize.cx - (offset.cx * 2)
						,m_PieceSize.cy - (offset.cy * 2)
						,color1
					);

				} else {

					FLOAT oow = 1.0f / (FLOAT)m_Resolution.cx;
					FLOAT ooh = 1.0f / (FLOAT)m_Resolution.cy;

					FLOAT x = (FLOAT)pos.x * oow;
					FLOAT y = (FLOAT)pos.y * ooh;
					FLOAT z = 0.1f;

					// ========================================================

					FLOAT w = (FLOAT)(m_PieceSize.cx - (offset.cx * 2)) * oow * fPieceScale;
					FLOAT h = (FLOAT)(m_PieceSize.cy - (offset.cy * 2)) * ooh * fPieceScale;
					FLOAT d = (w + h) * 0.5f;

					x = x * fXScale;
					y = y * fYScale;
					z = z * fZScale;

					w *= fXScale;
					h *= fYScale;
					d *= fZScale;

#if 1 // check to see if the piece is wiggling
					{

						// Need an animation table...

						float tJiggle = (float)piece.StillCounter() / 25.0f;

						if ( (!bMover) && (1.0f > tJiggle) ) {

							float fJiggleAmplitude = 0.25f * (1.0f - tJiggle);

							float fJiggleScale = sinf( tJiggle * D3DX_PI * 4.5f ) * fJiggleAmplitude;

							h *= (1.0f - fJiggleScale);
							w *= (1.0f + fJiggleScale);

						}

					}
#endif

					FLOAT xOffset = fXScale * 0.5f;
					FLOAT yOffset = fYScale * 0.5f;

					// ========================================================

					if ( m_X.bWiggle || piece.IsGroupActivator() || bActiveTimer ) {

#if 1 // WACKO PLAY THING

						/// --------------

						D3DXMATRIX pieceTranslationMat;

						D3DXMatrixTranslation(
							&pieceTranslationMat, x - xOffset, -(y - yOffset), z
						);

						/// --------------

						D3DXMATRIX pieceWiggleMat;

						if ( piece.IsGroupActivator() || bActiveTimer ) {

							FLOAT wiggleT = (FLOAT)timeGetTime() * 0.005f;

							if ( bActiveTimer ) {

								wiggleT = (2.0f * D3DX_PI * (float)pTimer->Current()) / pTimer->Limit();

							}

							D3DXMatrixRotationYawPitchRoll(
								&pieceWiggleMat
								,wiggleT // sinf( wiggleT ) * D3DX_PI * 2.0f
								,0.0f
								,0.0f
							);

						} else {

							FLOAT wiggleT = (FLOAT)timeGetTime() / 1000.0f;

							D3DXMatrixRotationYawPitchRoll(
								&pieceWiggleMat
								,sinf( wiggleT + 2.0f * (x - xOffset))
								,sinf( wiggleT + 3.0f * (x + y  + wiggleT) )
								,cosf( wiggleT + (-(y - yOffset)) * x)
							);

						}

						/// --------------

						D3DXMATRIX pieceWorldMat;

						D3DXMatrixMultiply( &pieceWorldMat, &pieceWiggleMat, &pieceTranslationMat );

						/// --------------

						D3DXMatrixMultiply( &pieceWorldMat, &pieceWorldMat, &matrix );

						m_X.pd3dDevice->SetTransform( D3DTS_WORLD, &pieceWorldMat );

						/// --------------
		
						X_Render3dCube(
							0.0f, 0.0f, 0.0f, w, h, d, color1, color2, color3, color4,
							bOnlyEdges, bRenderEdges, bAntialiasEdge, &pieceWorldMat,
							pieceType
						);

#else

						X_Render3dCube(
							x - xOffset, -(y - yOffset), z, w, h, d, color1, color2, color3, color4,
							bOnlyEdges, bRenderEdges, bAntialiasEdge, &matrix, pieceType
						);

#endif  // WACKO PLAY THING

					} else {

						X_Render3dCube(
							x - xOffset, -(y - yOffset), z, w, h, d, color1, color2, color3, color4,
							bOnlyEdges, bRenderEdges, bAntialiasEdge, &matrix, pieceType
						);

					}

					// ========================================================

				}

			}

		}

		// ------------------------------------------------------------------------

		//
		//	RenderBackdropRect()
		//

		void RenderBackdropRect(
			const RECT & rect
			,const FLOAT fXScale
			,const FLOAT fYScale
			,const FLOAT fZScale
			,const D3DXMATRIX * pWorldMat
		) {

			if ( m_X.b2dDisplay ) {

				X_SolidRectangle(
					rect.left, rect.top,
					rect.right - rect.left,
					rect.bottom - rect.top,
					D3DCOLOR_RGBA(0,0,0,255)
				);

			} else {

				FLOAT oow = 1.0f / (FLOAT)m_Resolution.cx;
				FLOAT ooh = 1.0f / (FLOAT)m_Resolution.cy;

				FLOAT x = (FLOAT)((rect.right + rect.left)/2) * oow;
				FLOAT y = (FLOAT)((rect.bottom + rect.top)/2) * ooh;
				FLOAT z = 0.21f; // + (FLOAT)((m_PieceSize.cx + m_PieceSize.cx)/2) * oow;

				FLOAT w = (FLOAT)(rect.right - rect.left + (m_PieceSize.cx * 2)) * oow;
				FLOAT h = (FLOAT)(rect.bottom - rect.top + (m_PieceSize.cy * 4)) * ooh;
				FLOAT d = (FLOAT)((m_PieceSize.cx + m_PieceSize.cx)/2) * oow;

#if 1
				d *= 15.0f;
				float z2 = z + d * 0.31525f;
				w *= 1.75f * z2 / z;
				h *= 0.75f * z2 / z;
				y -= 64.0f * ooh;
				z = z2;
#endif

				x = x * fXScale;
				y = y * fYScale;
				z = z * fZScale;

				w *= fXScale;
				h *= fYScale;
				d *= fZScale;

				FLOAT xOffset = fXScale * 0.5f;
				FLOAT yOffset = fYScale * 0.5f;

//				DWORD colorA = D3DCOLOR_RGBA( 128, 64, 32, 32 );
				DWORD colorA = D3DCOLOR_RGBA( 176, 64, 255, 255 ); // nice purple
//				DWORD colorA = D3DCOLOR_RGBA( 192, 128, 16, 255 ); // bronze

				DWORD colorB = colorA; 

#if 0
				m_X.pd3dDevice->SetRenderState( D3DRS_COLORVERTEX, TRUE );
#endif

				X_Render3dCube(
					x - xOffset, -(y - yOffset), z, w, h, d,
					colorA, colorB, colorA, colorB, false, false, false, pWorldMat, 1
				);

#if 0
				if ( m_X.bUseCubes ) {

					m_X.pd3dDevice->SetRenderState( D3DRS_COLORVERTEX, TRUE );

				} else {

					m_X.pd3dDevice->SetRenderState( D3DRS_COLORVERTEX, FALSE );

				}
#endif

			}

		}

		// ------------------------------------------------------------------------

		//
		//	X_RenderPieceRelatedElements
		//

		void 
		X_RenderPieceRelatedElements(
			const FLOAT fXScale
			,const FLOAT fYScale
			,const FLOAT fZScale
			,const bool bOnlyEdges
			,const bool bRenderEdges
			,const bool bAntialiasEdge
			,const D3DXMATRIX & matrix
		) {

			// Render the board pieces
			// --------------------------------------------------------------------

			{
				for ( int row = m_PuzzleCore.m_HiddenRows; row < m_PuzzleCore.m_ActiveRows; row++ ) {

					for ( int col = 0; col < m_PuzzleCore.m_ActiveCols; col++ ) {

						// Get board information

						const DOWNFALL::PieceType & piece = m_PuzzleCore._BoardElement( row, col ); // _BoardElement( row, col );

						if ( !piece.IsEmpty() ) {

							DOWNFALL::Location pos;

							m_PuzzleCore.GetLocation( row, col, pos );

							X_RenderPiece(
								pos, piece, false, &m_PuzzleCore.m_MatchTimer[ row ][ col ],
								fXScale, fYScale, fZScale, bOnlyEdges, bRenderEdges, bAntialiasEdge,
								255, matrix
							);

						}

					}

				}

			}

			// Render the movers
			// --------------------------------------------------------------------

			{
				for ( int col = 0; col < m_PuzzleCore.m_ActiveCols; col++ ) {

					const DOWNFALL::Mover * pMover = m_PuzzleCore.m_Movers[ col ];

					while ( pMover ) {

						X_RenderPiece(
							pMover->location, pMover->pieceType, true, 0, 
							fXScale, fYScale, fZScale, bOnlyEdges, bRenderEdges, bAntialiasEdge,
							255, matrix
						);

						pMover = pMover->pNext;

					}

				}

			}

			// Render the input
			// --------------------------------------------------------------------

			if ( !m_PlayerInput.m_bNeedNewPiece ) { // don't render if waiting...

				int row = m_PlayerInput.m_FP_row >> puzzle_core_type::FRACTION_SHIFT;

				int col = m_PlayerInput.m_FP_col >> puzzle_core_type::FRACTION_SHIFT;

				int elements = m_PlayerInput.m_pFront->GetPieceCount();

				bool bIsFalling = m_PlayerInput.m_bAutoDownInput;

				for ( int i = 0; i < elements; i++ ) {

					int readRow = m_PlayerInput.WrapFriendlyGetNthElementRow( i, row );

					int readCol = m_PlayerInput.WrapFriendlyGetNthElementCol( i, col );

					int FP_readRow = (readRow << puzzle_core_type::FRACTION_SHIFT) + 
						(m_PlayerInput.m_FP_row & puzzle_core_type::FRACTION_MASK);

					DOWNFALL::Location pos;

					m_PuzzleCore.FPCalcPosition( FP_readRow, readCol, pos );

					X_RenderPiece(
						pos
						,*m_PlayerInput.m_pFront->GetPieceTypeForNThElement( i )
						,bIsFalling
						,0
						,fXScale
						,fYScale
						,fZScale
						,bOnlyEdges
						,bRenderEdges
						,bAntialiasEdge
						,255
						,matrix
					);

				}

			}

		}

		//
		//	X_RenderPreviewPiece()
		//

		void 
		X_RenderPreviewPiece(
			const FLOAT fXScale
			,const FLOAT fYScale
			,const FLOAT fZScale
			,const bool bOnlyEdges
			,const bool bRenderEdges
			,const bool bAntialiasEdge
			,const D3DXMATRIX & matrix
		) {

			// render the preview piece
			// ----------------------------------------------------------------

			{

				// rotate the whole preview piece around the y axis?
				// ------------------------------------------------------------

				// fun
				// ------------------------------------------------------------

				int elements = m_PlayerInput.m_pNext->GetPieceCount();

				// find the size of the piece
				// ------------------------------------------------------------

				int width = 0, height = 0;

				{
					for ( int j = 0; j < elements; j++ ) {

						int r = m_PlayerInput.m_pNext->GetRowForNThElement( j, 0 );
						int c = m_PlayerInput.m_pNext->GetColForNThElement( j, 0 );

						width = max( width, (c + 1) );
						height = max( height, (r + 1) );

					}
				}

				// ------------------------------------------------------------

				int xOffset = m_NextPieceRect.left +
					(m_PieceSize.cx/2) + ((m_NextPieceRect.right - m_NextPieceRect.left) - 
					(width * m_PieceSize.cx))/2;

				int yOffset = m_NextPieceRect.top +
					(m_PieceSize.cy) + ((m_NextPieceRect.bottom - m_NextPieceRect.top) - 
					(height * m_PieceSize.cy))/2;

				for ( int i = 0; i < elements; i++ ) {

					int readRow = m_PlayerInput.m_pNext->GetRowForNThElement( i, 0 );

					int readCol = m_PlayerInput.m_pNext->GetColForNThElement( i, 0 );

					int xPos = xOffset + (m_PieceSize.cx * readCol);

					int yPos = yOffset + (m_PieceSize.cy * readRow);

					DOWNFALL::Location pos = { xPos, yPos, 0 };

					// --------------------------------------------------------

					X_RenderPiece(
						pos
						,*m_PlayerInput.m_pNext->GetPieceTypeForNThElement( i )
						,false
						,0
						,fXScale
						,fYScale
						,fZScale
						,bOnlyEdges
						,bRenderEdges
						,bAntialiasEdge
						,255
						,matrix
					);

				}

			}

		}

		// ------------------------------------------------------------------------

		//
		//	X_Render()
		//

		void X_Render() {

			SetupMatrices();

			// This scale value really needs to be derived from the camera?
			// --------------------------------------------------------------------

//			float fThrobScale = (fabsf(sinf((float)timeGetTime() / 420.0f)) * 0.125f) + 0.90f;
			float fThrobScale = 0.87f; // 0.90f == default

			FLOAT fXScale = -m_X.camera.GetEyePt().z * fThrobScale;
			FLOAT fYScale = fXScale;
			FLOAT fZScale = fXScale;

			// setup the various render & texture state
			// --------------------------------------------------------------------

			DWORD dwOldZENABLE = m_X.dwZbufferOn;
			
			// --------------------------------------------------------------------

			if ( m_X.bShowWireframe ) {

				m_X.pd3dDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_WIREFRAME );
				m_X.pd3dDevice->SetRenderState( D3DRS_SHADEMODE, D3DSHADE_FLAT );

#if !defined(BPT_TEST_MESH)
				m_X.pd3dDevice->SetRenderState( D3DRS_LIGHTING, FALSE );
#endif

				m_X.pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE );

				if ( D3DPRASTERCAPS_ANTIALIASEDGES & m_X.d3dCaps.RasterCaps ) {

					m_X.pd3dDevice->SetRenderState( D3DRS_EDGEANTIALIAS, TRUE );

				}

			} else {

				m_X.pd3dDevice->SetRenderState( D3DRS_SHADEMODE, D3DSHADE_GOURAUD );
				m_X.pd3dDevice->SetRenderState( D3DRS_FILLMODE, D3DFILL_SOLID );
				m_X.pd3dDevice->SetRenderState( D3DRS_LIGHTING, TRUE );
				m_X.pd3dDevice->SetRenderState( D3DRS_ALPHABLENDENABLE, TRUE );
				m_X.pd3dDevice->SetRenderState( D3DRS_EDGEANTIALIAS, FALSE );

				if ( m_X.bUseCubes ) {

					m_X.pd3dDevice->SetRenderState( D3DRS_COLORVERTEX, TRUE );

				} else {

					m_X.pd3dDevice->SetRenderState( D3DRS_COLORVERTEX, FALSE );

				}

#if defined(BPT_TEST_MESH)

				m_X.pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1  );
				m_X.pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1,  D3DTA_TEXTURE );
				m_X.pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1  );
				m_X.pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1,  D3DTA_TEXTURE );

				m_X.pd3dDevice->SetTextureStageState( 0, D3DTSS_MINFILTER,  D3DTEXF_LINEAR );
				m_X.pd3dDevice->SetTextureStageState( 0, D3DTSS_MAGFILTER,  D3DTEXF_LINEAR );
				m_X.pd3dDevice->SetTextureStageState( 0, D3DTSS_MIPFILTER,  D3DTEXF_LINEAR );

#endif

			}

			// Render the background
			// --------------------------------------------------------------------

			if ( m_X.bGradientBackground ) {

				if ( m_BigSphereBackgroundMesh.HasData() ) {

					m_X.pd3dDevice->SetTexture( 0, m_pBigSphereTexture );

					// ---------------------------

					D3DMATERIAL8 material;

					ZeroMemory( &material, sizeof(D3DMATERIAL8) );

					material.Diffuse = D3DXCOLOR( 0.0f, 0.25f, 1.0f, 1.0f );
					material.Ambient = D3DXCOLOR( (DWORD)0 );
					material.Specular = D3DXCOLOR( 1.0f, 1.0f, 1.0f, 1.0f );
					material.Power = 5.0f;

					m_X.pd3dDevice->SetMaterial( &material );

					// ---------------------------

					float fScale = fabsf( m_X.camera.GetEyePt().z * 2.5f );

					D3DXMATRIX rotationMatrix;

//					float t = 0.0f; //0.625f * sinf( (float)timeGetTime() / 85000.0f );
					float t = 0.625f * sinf( (float)timeGetTime() / 85000.0f );

					D3DXMatrixRotationYawPitchRoll(
//						&rotationMatrix, sinf(t), cosf( sinf(t * D3DX_PI ) * sinf( t * 2.0f ) ),sinf( 2.0f * t )
						&rotationMatrix, sinf(t * 2.1f), cosf( sinf(t * 1.14f ) * D3DX_PI ),sinf( 2.5f * t )
					);

					D3DXMATRIX scaleMatrix;

//					fScale += (8.0f * sinf( sinf( t * 3.0f ) * cosf( t * 5.0f ) )); // hack
					fScale += (5.0f * sinf( cosf( t * 3.0f ) )); // hack

					D3DXMatrixScaling( &scaleMatrix, fScale, fScale, fScale );

					D3DXMATRIX useMatrix;

					D3DXMatrixMultiply( &useMatrix, &rotationMatrix, &scaleMatrix );

					if ( SUCCEEDED( m_BigSphereBackgroundMesh.Draw( &useMatrix, false, false ) ) ) {

						HACKDATA::g_nTrianglesProcessed += m_BigSphereBackgroundMesh.FaceCount();

					}

					m_X.pd3dDevice->SetTexture( 0, 0 );

				} else {

					m_X.pd3dDevice->SetRenderState( D3DRS_ZENABLE, D3DZB_FALSE  );

					X_FourColorRectangle(
						0, 0, m_Resolution.cx, m_Resolution.cy
						,D3DCOLOR_XRGB(64,128,255)
						,D3DCOLOR_XRGB(64,128,255)
						,D3DCOLOR_XRGB(32,64,128) // D3DCOLOR_XRGB(255,255,255)
						,D3DCOLOR_XRGB(32,64,128) // D3DCOLOR_XRGB(255,255,255)
					);

				}

			}

			// Put the Zbuffer back
			// --------------------------------------------------------------------

			if ( !m_X.b2dDisplay ) {

				m_X.pd3dDevice->SetRenderState( D3DRS_ZENABLE, dwOldZENABLE );

			}

			// setup the board matrix
			// --------------------------------------------------------------------

			static D3DXMATRIX boardWorldMatrix;

			{
				static bool bBeenHere = false;

				if ( !bBeenHere ) {

					D3DXMatrixIdentity( &boardWorldMatrix );

					bBeenHere = true;

				}

				bool bLButton = false;
				bool bRButton = false;

				if ( m_hwnd == GetCapture() ) {

					bLButton = (0x8000 & GetAsyncKeyState(VK_LBUTTON)) ? true : false;
					bRButton = (0x8000 & GetAsyncKeyState(VK_RBUTTON)) ? true : false;

				}

				if ( bLButton || bRButton ) {

					if ( bLButton ) {

						bBeenHere = false;

					}

					// ----------------

					{

						float fmx = (float)(m_MousePos.x - m_MouseButtonDown.x) / (float)m_Resolution.cx;
						float fmy = (float)(m_MousePos.y - m_MouseButtonDown.y) / (float)m_Resolution.cy;

						D3DXMatrixRotationYawPitchRoll(
							&boardWorldMatrix
							,-(fmx * D3DX_PI * 2.0f)
							,-(fmy * D3DX_PI * 2.0f)
							,0.0f
						);

					}

				}

			}

			m_X.boardWorldMat = boardWorldMatrix;

			m_X.pd3dDevice->SetTransform( D3DTS_WORLD, &boardWorldMatrix );

			// Render the board frame
			// --------------------------------------------------------------------

			if ( m_X.b2dDisplay ) {

				RenderBackdropRect( m_BoardRect, fXScale, fYScale, fZScale, &m_X.boardWorldMat );

			}

			/// oiruhogihowihrgoihewrogidheoirthgoeihrg

			X_RenderPieceRelatedElements(
				fXScale, fYScale, fZScale, false, m_X.bPieceBorders, false, m_X.boardWorldMat
			);

			// Render the next piece (should rotate/animate somehow)
			// --------------------------------------------------------------------

			{
				// Setup the next piece location
				// ----------------------------------------------------------------

				D3DXMATRIX pieceBackdropMat = m_X.boardWorldMat;

				D3DXMatrixIdentity( &pieceBackdropMat );

				// Render the next piece backdrop
				// ----------------------------------------------------------------

				m_X.pd3dDevice->SetTransform( D3DTS_WORLD, &pieceBackdropMat );

				X_RenderPreviewPiece(
					fXScale, fYScale, fZScale, false, m_X.bPieceBorders, false, pieceBackdropMat
				);

#if 0
				RenderBackdropRect( m_NextPieceRect, fXScale, fYScale, fZScale, &pieceBackdropMat );
#endif

			}

			// --------------------------------------------------------------------

			if ( !m_X.b2dDisplay ) {

				m_X.pd3dDevice->SetTransform( D3DTS_WORLD, &boardWorldMatrix );

				RenderBackdropRect( m_BoardRect, fXScale, fYScale, fZScale, &boardWorldMatrix );

			}

			// render the antialiased edges
			// there should be an option to FORCE feature use since CAPBITS
			// seem to be a unreliable way to tell if a feature is present...

#if 0

			if ( m_X.bAntialiaseEdges 
				/* && (D3DPRASTERCAPS_ANTIALIASEDGES & m_X.d3dCaps.RasterCaps) */ )  {

				X_RenderPieceRelatedElements( fXScale, fYScale, fZScale, true, true, true );

			}

#endif

			// --------------------------------------------------------------------

			m_X.pd3dDevice->SetRenderState( D3DRS_ZENABLE, dwOldZENABLE );

		}

		// Message handlers
		// --------------------------------------------------------------------

		LRESULT OnChar( HWND hWnd, const UINT, const WPARAM wParam, const LPARAM ) {

			switch ( wParam ) {

			default:
				break;

			case 27:
				SendMessage( hWnd, WM_CLOSE, 0, 0 );
				break;

			case '2':
				m_X.b2dDisplay = !m_X.b2dDisplay;
				break;

			case 'w':
			case 'W':
				m_X.bShowWireframe = !m_X.bShowWireframe;
				break;

			case 'f':
			case 'F':
				m_X.bGoFast = !m_X.bGoFast;
				break;

			case 's':
			case 'S':
				m_X.bWiggle = !m_X.bWiggle;
				break;

			case 'e':
			case 'E':
				m_X.bAntialiaseEdges = !m_X.bAntialiaseEdges;
				break;

			case 'b':
			case 'B':
				m_X.bPieceBorders = !m_X.bPieceBorders;
				break;

			case 'r':
			case 'R':
				m_X.bGradientBackground = !m_X.bGradientBackground;
				break;

			case 'c':
			case 'C':
				m_X.bUseCubes = !m_X.bUseCubes;
				break;

			case '-':
				break;

			case '+':
			case '=':
				break;

			}

			return 0;

		}

		LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam ) {

			switch( msg ) {

				case WM_LBUTTONDOWN:
				case WM_RBUTTONDOWN:
					m_MouseButtonDown.x = GET_X_LPARAM(lParam); 
					m_MouseButtonDown.y = GET_Y_LPARAM(lParam); 
					SetCapture( hWnd );
					break;

				case WM_LBUTTONUP:
				case WM_RBUTTONUP:
					if ( hWnd == GetCapture() ) {
						ReleaseCapture();
					}
					break;

				case WM_MOUSEMOVE:
					m_MousePos.x = GET_X_LPARAM(lParam); 
					m_MousePos.y = GET_Y_LPARAM(lParam); 
					break;

				case WM_ACTIVATEAPP:
					if ( 1 || (0x8000 & GetAsyncKeyState(VK_SCROLL)) ) { // for now
						m_bAppActive = TRUE; //(FALSE != wParam);
					} else {
						m_bAppActive = (FALSE != wParam);
					}
					break;

				case WM_CHAR:
					OnChar( hWnd, msg, wParam, lParam );
					break;

			}

			return 0;

		}

		// called by the framework
		// --------------------------------------------------------------------

		HRESULT DeleteDeviceObjects() {

#if defined(BPT_TEST_MESH)

			SAFE_RELEASE( m_pBigSphereTexture );

			m_BigSphereBackgroundMesh.Release();

			for ( int m = 0; m < MAX_PIECE_MESHES; m++ ) {

				m_PieceMesh[ m ].Release();

			}

#endif
			// ------------------------------------------------------------------------

			return S_OK;

		}

		HRESULT RestoreDeviceObjects(
			LPDIRECT3D8 pD3D
			,LPDIRECT3DDEVICE8 pd3dDevice
			,const D3DPRESENT_PARAMETERS & d3dpp
			,const D3DCAPS8 & d3dCaps
			,HWND hwnd
		) {

			// Setup the 'game'
			// ------------------------------------------------------------------------

			if ( !GameBootstrap( d3dpp.BackBufferWidth, d3dpp.BackBufferHeight, hwnd ) ) {

				return E_FAIL;

			}

			// hook up the m_X stuff
			// ------------------------------------------------------------------------

			m_X.pd3dDevice = pd3dDevice;

			m_X.pD3D = pD3D;

			m_X.d3dCaps = d3dCaps;

			// Figure out our capabilities
			// ------------------------------------------------------------------------

//D3DPRASTERCAPS_ANTIALIASEDGES 
//D3DPRASTERCAPS_DITHER
//D3DPRASTERCAPS_WBUFFER
//D3DPRASTERCAPS_ZBIAS 
//D3DPRASTERCAPS_ANISOTROPY
//D3DPRASTERCAPS_ZTEST 
//D3DPRASTERCAPS_ZBUFFERLESSHSR // cool no zbuffer or sort needed...

			if ( D3DPRASTERCAPS_ZBUFFERLESSHSR & m_X.d3dCaps.RasterCaps ) {

				m_X.dwZbufferOn = D3DZB_FALSE;

			} else if ( D3DPRASTERCAPS_WBUFFER & m_X.d3dCaps.RasterCaps )  {

				m_X.dwZbufferOn = D3DZB_USEW;

			} else {

				m_X.dwZbufferOn = D3DZB_TRUE;

			}

			m_X.pd3dDevice->SetRenderState( D3DRS_ZENABLE, m_X.dwZbufferOn  );

			// setup projection matrix
			// ------------------------------------------------------------------------

			D3DXMATRIX matProj;

#if defined(USE_SQUARE_ASPECT_RATIO)

			FLOAT fAspect;

			if ( d3dpp.BackBufferHeight ) {
			
				fAspect = (FLOAT)d3dpp.BackBufferWidth / (FLOAT)d3dpp.BackBufferHeight;

			} else {

				fAspect = 1.0f;

			}

#else

			FLOAT fAspect = 1.0f;

#endif

			// Setup our viewport
			// --------------------------------------------------------------------

			m_X.camera.SetViewport(
				0, 0, d3dpp.BackBufferWidth, d3dpp.BackBufferHeight, 0.0f, 1.0f
			);

			m_X.pd3dDevice->SetViewport( &m_X.camera.GetViewport() );

			// Set up our view matrix. (this should be a method!)
			// --------------------------------------------------------------------

			D3DXMATRIX matView;

			D3DXVECTOR3 vEyePt		= D3DXVECTOR3( 0.0f, 0.0f, -8.0f );
			D3DXVECTOR3 vLookatPt	= D3DXVECTOR3( 0.0f, 0.0f, 1.0f );
			D3DXVECTOR3 vUpVec		= D3DXVECTOR3( 0.0f, 1.0f, 0.0f );

			m_X.camera.SetViewParams( vEyePt, vLookatPt, vUpVec );

			m_X.pd3dDevice->SetTransform( D3DTS_VIEW, &m_X.camera.GetViewMatrix() );

			// ------------------------------------------------------------------------

			m_X.camera.SetProjParams( D3DX_PI/4.0f, fAspect, 0.1f, 100.0f );

			// should this have a decal mode?

			if ( FAILED( m_X.pd3dDevice->SetTransform( D3DTS_PROJECTION, &m_X.camera.GetProjMatrix() ) ) ) {

				return E_FAIL;

			}

			// restore the settings I want for rendering
			// ------------------------------------------------------------------------

			if ( D3DPRASTERCAPS_DITHER& m_X.d3dCaps.RasterCaps )  {

				m_X.pd3dDevice->SetRenderState( D3DRS_DITHERENABLE, TRUE );

			}

			m_X.pd3dDevice->SetRenderState( D3DRS_NORMALIZENORMALS, TRUE );
			m_X.pd3dDevice->SetRenderState( D3DRS_SRCBLEND, D3DBLEND_SRCALPHA );
			m_X.pd3dDevice->SetRenderState( D3DRS_DESTBLEND, D3DBLEND_INVSRCALPHA );

			// light related
			// ------------------------------------------------------------------------

			D3DMATERIAL8 material;

			D3DUtil_InitMaterial( material, 1.0f, 1.0f, 1.0f, 1.0f );

			m_X.pd3dDevice->SetMaterial( &material );

			// ------------------------------------------------------------------------

			D3DLIGHT8 light;

			D3DUtil_InitLight( light, D3DLIGHT_DIRECTIONAL, 0.125f, -0.35f, 1.0f );

			m_X.pd3dDevice->SetLight( 0, &light );

			m_X.pd3dDevice->LightEnable( 0, TRUE );

			// ------------------------------------------------------------------------

			m_X.pd3dDevice->SetRenderState( D3DRS_AMBIENT, D3DCOLOR_RGBA(32,32,32,255) );
			m_X.pd3dDevice->SetRenderState( D3DRS_SPECULARENABLE, TRUE );

			m_X.pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_CCW );
//			m_X.pd3dDevice->SetRenderState( D3DRS_CULLMODE, D3DCULL_NONE );

			// load our test model
			// ------------------------------------------------------------------------
	
#if defined(BPT_TEST_MESH)

			// Make the backdrop
			// ------------------------------------------------------------------------
			LPD3DXMESH pBigSphereMesh;

#if 0

			if ( FAILED( BPT::CreateBoxOfBoxes(
				m_X.pd3dDevice
				,64
				,48
				,1
				,D3DXVECTOR3( 0.0f, 0.0f, 0.0f )
				,D3DXVECTOR3( 1.0f, 1.0f, 1.0f )
				,D3DXVECTOR3( 1.5f, 1.5f, 1.5f )
				,true
				,true
				,D3DXMESH_MANAGED
				,D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1
				,&pBigSphereMesh
			) ) ) {

#else

			if ( FAILED( BPT::CreateSphere(
				m_X.pd3dDevice
				,true
				,33 //17
				,33 //17
				,D3DXMESH_MANAGED
				,D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1
				,&pBigSphereMesh
				,true
				) ) ) {

#endif

				// make something else?

			} else {

				if( FAILED( D3DXCreateTextureFromFile(
					m_X.pd3dDevice, ".\\downfall_models\\texture1.bmp",
					&m_pBigSphereTexture ) ) ) {

					BPT::OutputDebugf( "Failed to load texture!\n" );

				}
#if 0
				char meshFilename[ _MAX_PATH ];

				sprintf( meshFilename, ".\\downfall_models\\backdrop-mesh.x" );

				if ( FAILED( D3DXSaveMeshToX(
					meshFilename
					,pBigSphereMesh
					,NULL
					,NULL
					,0
					,DXFILEFORMAT_TEXT
				) ) ) {

					BPT::OutputDebugf( "Save \"%s\" model failed.\n", meshFilename );

				}
#endif

				m_BigSphereBackgroundMesh.AdoptMesh( pBigSphereMesh, 1 );

//				m_BigSphereBackgroundMesh.Release();

			}

#if 0 // test

			// Load the pieces
			// ------------------------------------------------------------------------

			for ( int m = 0; m < MAX_PIECE_MESHES; m++ ) {

				LPD3DXMESH pOctahedron;

#if 0 // test the grid

				if ( SUCCEEDED( BPT::CreateTessellatedGrid(
					m_X.pd3dDevice
					,1.0f
					,1.0f
					,0.0f
					,33
					,33
					,D3DXMESH_MANAGED
					,D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1
					,&pOctahedron
					,true
					) ) ) {

#else

				if ( SUCCEEDED( BPT::CreateTessellatedOctahedron(
					m_X.pd3dDevice
					,16.0f
					,D3DXMESH_MANAGED
					,D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1
					,&pOctahedron
					) ) ) {

#endif

					D3DXComputeNormals( pOctahedron );

#if 0
					if ( FAILED( BPT::ReverseNormals( pOctahedron ) ) ) {

						BPT::OutputDebugf( "Reverse Normals Failed.\n" );

					}
#endif

					m_PieceMesh[ m ].AdoptMesh( pOctahedron, 1 );

					m_PieceMesh[ m ].Optimize();

					if ( true ) { // SUCCEEDED(  ) ) {

#if 0
						char meshFilename[ _MAX_PATH ];

						sprintf( meshFilename, ".\\downfall_models\\generated-%02d.x", m + 1 );

						if ( FAILED( D3DXSaveMeshToX(
							meshFilename
							,pOctahedron
							,NULL
							,NULL
							,0
							,DXFILEFORMAT_TEXT
							) ) ) {

							BPT::OutputDebugf( "Failed save mesh %d \"%s\"\n", m, meshFilename );

						}
#endif

					}

				} else {

					BPT::OutputDebugf( "Failed mesh %d creation\n", m );

				}

			}

#else

			for ( int m = 0; m < MAX_PIECE_MESHES; m++ ) {

				char meshFilename[ _MAX_PATH ];

				sprintf( meshFilename, ".\\downfall_models\\piece-%02d.x", m + 1 );

            	if ( SUCCEEDED( m_PieceMesh[ m ].LoadFromFile(
					m_X.pd3dDevice
					,meshFilename
					,D3DXMESH_MANAGED 
					) ) ) {

#if 1

					m_PieceMesh[ m ].ConvertToFVF(
						m_X.pd3dDevice, D3DFVF_XYZ | D3DFVF_NORMAL | D3DFVF_TEX1, true
					);

#endif

					m_PieceMesh[ m ].Optimize();

				}

			}

#endif


#else

			m_X.pd3dDevice->SetRenderState( D3DRS_COLORVERTEX, TRUE );
			m_X.pd3dDevice->SetTextureStageState( 0, D3DTSS_COLOROP,   D3DTOP_SELECTARG1  );
			m_X.pd3dDevice->SetTextureStageState( 0, D3DTSS_COLORARG1, D3DTA_TEXTURE  );
			m_X.pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAOP,   D3DTOP_SELECTARG1  );
			m_X.pd3dDevice->SetTextureStageState( 0, D3DTSS_ALPHAARG1,  D3DTA_TEXTURE );

#endif
			// ------------------------------------------------------------------------

			return S_OK;

		}

		//
		//	FrameMove()
		//

		HRESULT FrameMove( bool * pGameSleeping ) {

#if defined(BPT_USE_SLEEP_TO_SLOWDOWN_GAME) // slow the app down...

			if ( !m_X.bGoFast ) {

				if ( !m_bAppActive ) { // if we're not active we can 'sleep'

					if ( pGameSleeping ) { *pGameSleeping = true; }

					Sleep( 100 );

					return S_OK;

				}

				DWORD dwTime = ReadMillisecondTimer();

				if ( m_dwNextTime > dwTime ) {

					DWORD dwAmountFree = m_dwNextTime - dwTime;

					if ( 8 < dwAmountFree ) {

						Sleep( dwAmountFree - 1 );

					}

					if ( pGameSleeping ) { *pGameSleeping = true; }

					return S_OK;

				}

				m_dwNextTime = dwTime + eTIMER_DELAY;

			}

#endif

			// Feed the input state (hack for now...)
			// ------------------------------------------------------------------------

			m_PlayerInput.SetBooleanInput(
					((0x8000 & GetAsyncKeyState(VK_LEFT)) ? player_input_type::INPUT_DIR_L : 0)
				|	((0x8000 & GetAsyncKeyState(VK_RIGHT)) ? player_input_type::INPUT_DIR_R : 0)
				|	((0x8000 & GetAsyncKeyState(VK_UP)) ? player_input_type::INPUT_DIR_U : 0)
				|	((0x8000 & GetAsyncKeyState(VK_DOWN)) ? player_input_type::INPUT_DIR_D : 0)
				|	((0x8000 & GetAsyncKeyState(VK_TAB)) ? player_input_type::INPUT_BUTTON_A : 0)
				|	((0x8000 & GetAsyncKeyState(VK_UP)) ? player_input_type::INPUT_BUTTON_B : 0)
				|	((0x8000 & GetAsyncKeyState(VK_CLEAR)) ? player_input_type::INPUT_BUTTON_C : 0)
				|	((0x8000 & GetAsyncKeyState(VK_SPACE)) ? player_input_type::INPUT_BUTTON_D : 0)
				
				|	((0x8000 & GetAsyncKeyState(VK_NUMPAD4)) ? player_input_type::INPUT_DIR_L : 0)
				|	((0x8000 & GetAsyncKeyState(VK_NUMPAD6)) ? player_input_type::INPUT_DIR_R : 0)
				|	((0x8000 & GetAsyncKeyState(VK_NUMPAD8)) ? player_input_type::INPUT_DIR_U : 0)
				|	((0x8000 & GetAsyncKeyState(VK_NUMPAD2)) ? player_input_type::INPUT_DIR_D : 0)
				|	((0x8000 & GetAsyncKeyState(VK_NUMPAD8)) ? player_input_type::INPUT_BUTTON_B : 0)
				|	((0x8000 & GetAsyncKeyState(VK_NUMPAD5)) ? player_input_type::INPUT_BUTTON_C : 0)
				
			);

			// run the game tick
			// ------------------------------------------------------------------------

			m_PuzzleCore.AdvanceGameState( &m_PlayerInput );

			// Handle misc match based stats
			// ------------------------------------------------------------------------

			m_Points += m_PuzzleCore.m_nPointsCollectedThisFrame; // 4/29/02

			// handle the speed increase

			m_LevelCountDown -= m_PuzzleCore.m_nTotalMatchesThisFrame;

			if ( 0 >= m_LevelCountDown ) {

				NextLevel();

			}

			return S_OK;

		}

		void KickStartLevelCountdown() {

			m_nLevel = 1;

			m_DifficultySpeed = 0;

			m_LevelCountdownReset = 150;

			m_LevelCountDown = 75;

		}

		void ResetLevelCountdown() {

			m_LevelCountDown = m_LevelCountdownReset;

			m_LevelCountdownReset += 75;

		}

		void NextLevel() {

			++m_nLevel;

			m_PlayerInput.SetDifficultySpeedSetting( m_DifficultySpeed += 3 );

			ResetLevelCountdown();

		}

	}; // class GameInternals

	GameInternals m_Game;

	// ************************************************************************

private: // mostly from framework

    BOOL                    m_bLoadingApp;          // TRUE, if the app is loading
    CD3DFont*               m_pFont;                // Font for drawing text

    CInputDeviceManager*    m_pInputDeviceManager;  // DirectInput device manager
    DIACTIONFORMAT          m_diafGame;             // Action format for game play
    LPDIRECT3DSURFACE8      m_pDIConfigSurface;     // Surface for config'ing DInput devices
    UserInput               m_UserInput;            // Struct for storing user input 

    FLOAT                   m_fSoundPlayRepeatCountdown; // Sound repeat timer
    CMusicManager*          m_pMusicManager;        // DirectMusic manager class
    CMusicSegment*          m_pBounceSound;         // Bounce sound

    FLOAT                   m_fWorldRotX;           // World rotation state X-axis
    FLOAT                   m_fWorldRotY;           // World rotation state Y-axis

protected:

    HRESULT OneTimeSceneInit();
    HRESULT InitDeviceObjects();
    HRESULT RestoreDeviceObjects();
    HRESULT InvalidateDeviceObjects();
    HRESULT DeleteDeviceObjects();
    HRESULT Render();

#if defined(BPTLLC_CHANGES)
	HRESULT FrameMove(  bool * pGameSleeping = 0 );
#else
    HRESULT FrameMove();
#endif

    HRESULT FinalCleanup();
    HRESULT ConfirmDevice( D3DCAPS8*, DWORD, D3DFORMAT );
    VOID    Pause( BOOL bPause );

    HRESULT RenderText();

    HRESULT InitInput( HWND hWnd );
    void    UpdateInput( UserInput* pUserInput );
    void    CleanupDirectInput();

    HRESULT InitAudio( HWND hWnd );

    VOID    ReadSettings();
    VOID    WriteSettings();

public:

    LRESULT MsgProc( HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam );
    CMyD3DApplication();

    HRESULT InputAddDeviceCB( CInputDeviceManager::DeviceInfo* pDeviceInfo, const DIDEVICEINSTANCE* pdidi );
    static HRESULT CALLBACK StaticInputAddDeviceCB( CInputDeviceManager::DeviceInfo* pDeviceInfo, const DIDEVICEINSTANCE* pdidi, LPVOID pParam );   
    BOOL    ConfigureInputDevicesCB( IUnknown* pUnknown );
    static BOOL CALLBACK StaticConfigureInputDevicesCB( IUnknown* pUnknown, VOID* pUserData );
};


#endif // !defined(AFX_3D_DOWNFALL_H__BBECA644_3B71_11D6_A01F_00D009C96677__INCLUDED_)
