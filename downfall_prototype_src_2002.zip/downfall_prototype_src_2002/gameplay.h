// gameplay.h: root header for the game
//
//	Copyright (c) 2002, Brad P. Taylor, LLC
//
//	All rights reserved, unauthorized reproduction prohibited
//
//	-- FILE NOTES --
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMEPLAY_H__7108CBC4_8E2C_4A1F_9A98_21AAF8898F51__INCLUDED_)
#define AFX_GAMEPLAY_H__7108CBC4_8E2C_4A1F_9A98_21AAF8898F51__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// ----------------------------------------------------------------------------

#include "gametypes.h"
#include "gamecore.h"
#include "gameinput.h"

// ----------------------------------------------------------------------------

namespace DOWNFALL {

	/* empty */

}; /* namespace BPT */

#endif // !defined(AFX_GAMEPLAY_H__7108CBC4_8E2C_4A1F_9A98_21AAF8898F51__INCLUDED_)
