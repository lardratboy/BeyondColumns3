// gametypes.h: basic types for the downfall core to use
//
//	Copyright (c) 2002, Brad P. Taylor, LLC
//
//	All rights reserved, unauthorized reproduction prohibited
//
//	-- FILE NOTES --
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_GAMETYPES_H__9F4B7BC7_196E_4440_93CD_B4FC533E71B1__INCLUDED_)
#define AFX_GAMETYPES_H__9F4B7BC7_196E_4440_93CD_B4FC533E71B1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

// ----------------------------------------------------------------------------

// ----------------------------------------------------------------------------

namespace DOWNFALL {

	// ------------------------------------------------------------------------

	//
	//	PieceType
	//

	class PieceType {

	public:

		typedef PieceType this_type;

		enum {

			eINVISIBLE				= 0x00000001
			,eINPUT_PENETRABLE		= 0x00000002
			,eGROUP_ACTIVATOR		= 0x00000004
			,eCAN_NOT_BE_GROUPED	= 0x00000008
			,eFROM_INPUT			= 0x00000010
			,eCOLLECTED				= 0x00000020
			,eCANT_BE_MATCHED		= 0x20000000
			,eDISABLED				= 0x40000000
			,eRESERVED				= 0x80000000

		};

	private:

		int m_ID;

		DWORD m_dwFlags;

		int m_StillCounter;

		int m_Multiplier;

	public:

		PieceType() : m_ID(0), m_dwFlags(0), m_StillCounter(0), m_Multiplier(1) {}

		PieceType( const int id, const DWORD dwFlags = 0 ) : m_ID(id), m_dwFlags(dwFlags), m_StillCounter(0), m_Multiplier(1) {}

		// query
		// --------------------------------------------------------------------

		bool IsVisible() const {

			return (eINVISIBLE != (eINVISIBLE & m_dwFlags));

		}

		bool IsGroupActivator() const {

			return (eGROUP_ACTIVATOR == (eGROUP_ACTIVATOR & m_dwFlags));

		}

		bool InputCanPenetrate() const {

			return (eINPUT_PENETRABLE == (eINPUT_PENETRABLE & m_dwFlags));

		}

		bool IsDisabled() const {

			return (eDISABLED == (eDISABLED & m_dwFlags));

		}

		bool IsReserved() const {

			return (eRESERVED == (eRESERVED & m_dwFlags));

		}

		bool CanMatch() const {

			return (eCANT_BE_MATCHED != (eCANT_BE_MATCHED & m_dwFlags));

		}

		bool CanBeGrouped() const {

			return (eCAN_NOT_BE_GROUPED != (eCAN_NOT_BE_GROUPED & m_dwFlags));

		}

		int ID() const {

			if ( IsReserved() ) {

				return 0;

			}

			return m_ID;

		}

		bool IsEmpty() const {

			return (0 == ID());

		}

		bool HaveSameID( const this_type & rhs ) {

			return ID() == rhs.ID();

		}

		bool IsFromInput() const {

			return (eFROM_INPUT == (eFROM_INPUT & m_dwFlags));

		}

		bool WasCollected() const {

			return (eCOLLECTED == (eCOLLECTED & m_dwFlags));

		}

		int GetMultiplier() const {

			return m_Multiplier;

		}

		// Set status
		// --------------------------------------------------------------------

		void SetMultiplier( const int multiplier ) {

			m_Multiplier = multiplier;

		}

		void SetFromInput( const bool bFromInput ) {

			if ( bFromInput ) {

				m_dwFlags |= eFROM_INPUT;

			} else {

				m_dwFlags &= ~eFROM_INPUT;

			}

		}

		void SetCollectedStatus( const bool bCollected ) {

			if ( bCollected ) {

				m_dwFlags |= eCOLLECTED;

			} else {

				m_dwFlags &= ~eCOLLECTED;

			}

		}

		void Empty() {

			m_Multiplier = 1;

			m_StillCounter = 0;

			m_dwFlags = 0;

			m_ID = 0;

		}

		void Reserve() {

			if ( IsReserved() ) {

				++m_ID;

			} else {

				m_dwFlags = eRESERVED; // should it or?

				m_ID = 1;

			}

		}

		void UnReserve() {

			if ( IsReserved() ) {

				if ( !(--m_ID) ) {

					Empty();

				}

			} else {

				// warn about this?

			}

		}

		void Disable() {

			m_dwFlags |= eDISABLED;

		}

		void MakeUnmatchable() {

			m_dwFlags |= eCANT_BE_MATCHED;

		}

		void MakeMatchable() {

			m_dwFlags &= ~eCANT_BE_MATCHED;

		}

		void MakeInputPenetrable() {

			m_dwFlags |= eINPUT_PENETRABLE;

		}

		void MakeInputImpenetrable() {

			m_dwFlags &= ~eINPUT_PENETRABLE;

		}

		void MakeGroupActivator() {

			m_dwFlags |= eGROUP_ACTIVATOR;

		}

		void RemoveGroupActivatorStatus() {

			m_dwFlags &= ~eGROUP_ACTIVATOR;

		}

		void MakeAbleToBeAddedToGroups() {

			m_dwFlags &= ~eCAN_NOT_BE_GROUPED;

		}

		void MakeUnableToBeAddedToGroups() {

			m_dwFlags |= eCAN_NOT_BE_GROUPED;

		}

		// --------------------------------------------------------------------

		int StillCounter() const {

			return m_StillCounter;

		}

		void SetStillCounter( const int nValue ) {

			m_StillCounter = nValue;

		}

		void IncreaseStillCounter( const int nAmount = 1 ) {

			if ( ID() ) {

				m_StillCounter += nAmount;

			}

		}

	}; // class PieceType

	// ------------------------------------------------------------------------

/*

	elementType explaination

	elementType < 0 == define match type
	elementType < -MATCH_SET_COUNT then it's a specific match request
	elementType > 0 == match against defined match type
	elementType = 0 == match against any non-zero type

*/

	//
	//	ShapeElement
	//

	struct ShapeElement {

		enum {

			MATCH_SET_COUNT					= 8
			,DEFAULT_FLAGS					= 0x00000000
			,ELEMENT_SETS_TIMER				= 0x00000001

	// this needs a flag to say I convert piece to...

			// element flags

		};

		int matchID;
		int rowOffset;
		int colOffset;
		DWORD dwFlags;

	// this needs to store what piece to convert to...

		static int MAKEMATCHEXACT( const int pieceType ) {

			return -(MATCH_SET_COUNT + pieceType);

		}

	}; // struct ShapeElement

	// ------------------------------------------------------------------------

	//
	//	Shape
	//

	struct Shape {

		enum FLAGS { // these should probably be done via handler method pointers/objects...

			MARKS_PIECES				= 0x00000001
			,SETS_TIMER					= 0x00000002
			,MAKES_GROUPS				= 0x00000004
			,ONLY_NEW_MATCHES			= 0x00000008
			,ACTIVATE_GROUP				= ((MAKES_GROUPS) | (0x00000010))
			,CONVERTS_PIECES			= 0x80000000 // future...

		};

		int rows;
		int cols;
		int elementCount;
		int event;
		int setTimerValue;

		DWORD dwFlags;

		const ShapeElement * pElements; // pointer into a big table :)

	}; // Shape

	// ------------------------------------------------------------------------

	//
	//	Location
	//

	struct Location {

		int x;
		int y;
		int z;

		// fixed point lerp?

	}; // struct Location

	// ------------------------------------------------------------------------

	//
	//	Mover
	//

	struct Mover {

		// ----------------------------------

		struct Mover * pNext;

		Location location;

		PieceType pieceType;

		int FP_boardRow;

		int FP_delta;

		DWORD dwFlags;

		// ----------------------------------

		enum {

			MF_FROM_INPUT	= 0x00000001

		};

		// ----------------------------------

		void Reset() {

			dwFlags = 0;

			pNext = 0;

			pieceType.Empty();

		}

	}; // struct Mover

}; // namespace DOWNFALL

#endif // !defined(AFX_GAMETYPES_H__9F4B7BC7_196E_4440_93CD_B4FC533E71B1__INCLUDED_)
