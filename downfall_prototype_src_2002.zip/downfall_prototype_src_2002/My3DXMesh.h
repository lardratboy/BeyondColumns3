// My3DXMesh.h: -- this is my wrapper around the 3DX helpers
//
//	Copyright (c) 2002, Brad P. Taylor, LLC
//
//	All rights reserved, unauthorized reproduction prohibited
//
//	-- FILE NOTES --
//
//////////////////////////////////////////////////////////////////////

#if !defined( MY3DXMESH_EFBEEF06_BAC5_4cad_8EEB_228F58A90C44_INCLUDED )
#define MY3DXMESH_EFBEEF06_BAC5_4cad_8EEB_228F58A90C44_INCLUDED

#if _MSC_VER > 1000
#pragma once
#endif

// ----------------------------------------------------------------------------

#include <limits>
#include <D3d8types.h>
#include <D3dx8math.h>
#include <D3dx8mesh.h>

// ----------------------------------------------------------------------------

#include "DXUtil.h"

// ----------------------------------------------------------------------------

namespace BPT {

	//
	//	CMy3DXMesh
	//

	class CMy3DXMesh {

	public: // traits

		typedef CMy3DXMesh this_type;

	private: // data

		LPD3DXMESH				m_pMesh;
		D3DMATERIAL8*			m_pMeshMaterials;
		LPDIRECT3DTEXTURE8*		m_pMeshTextures;
		DWORD					m_dwNumSubsets;
		DWORD					m_dwNumMaterials;
		D3DXVECTOR3				m_BoundBoxMin;
		D3DXVECTOR3				m_BoundBoxMax;
		D3DXVECTOR3				m_BoundBoxCenter;
		D3DXVECTOR3				m_BoundBoxSize;

	public: // interface

		CMy3DXMesh() : 
			m_pMesh(0)
			,m_dwNumSubsets(0)
			,m_pMeshMaterials(0)
			,m_pMeshTextures(0)
			,m_dwNumMaterials(0)
			,m_BoundBoxMin(0.0f,0.0f,0.0f)
			,m_BoundBoxMax(0.0f,0.0f,0.0f)
			,m_BoundBoxCenter(0.0f,0.0f,0.0f)
			,m_BoundBoxSize(0.0f,0.0f,0.0f)
		{

		}

		~CMy3DXMesh() {

			Release();

		}

		// --------------------------------------------------------------------

		bool HasData() const {

			return (0 != m_pMesh);

		}

		// --------------------------------------------------------------------

		void Release() {

			if ( m_pMeshTextures ) {

				for ( DWORD i = 0; i < m_dwNumMaterials; i++ ) {

					if ( m_pMeshTextures[ i ] ) {

						m_pMeshTextures[ i ]->Release();

					}

				}

				delete [] m_pMeshTextures;

				m_pMeshTextures = 0;

			}

			SAFE_DELETE_ARRAY( m_pMeshMaterials );

			SAFE_RELEASE( m_pMesh );

			m_dwNumMaterials = 0;
			m_dwNumSubsets = 0;

			m_BoundBoxCenter	= D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
			m_BoundBoxSize		= D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
			m_BoundBoxMin		= D3DXVECTOR3( 0.0f, 0.0f, 0.0f );
			m_BoundBoxMax		= D3DXVECTOR3( 0.0f, 0.0f, 0.0f );

		}

		// --------------------------------------------------------------------

		//
		//	Draw()
		//

		HRESULT Draw(
			const D3DXMATRIX * pWorldMatrix = 0
			,const bool bUseMeshMaterial = true
			,const bool bUseMeshTexture = true
		) {

			if ( !m_pMesh ) {
				
				return E_FAIL;

			}

			LPDIRECT3DDEVICE8 pd3dDevice;

			if ( FAILED( m_pMesh->GetDevice( &pd3dDevice ) ) ) {

				return E_FAIL;

			}

			if ( pWorldMatrix ) {

				pd3dDevice->SetTransform( D3DTS_WORLD, pWorldMatrix );

			}

			for ( DWORD i = 0; i < m_dwNumSubsets; i++ ) {

				if ( bUseMeshMaterial && m_pMeshMaterials ) {

					pd3dDevice->SetMaterial( &m_pMeshMaterials[ i ] );

				}

				if ( bUseMeshTexture && m_pMeshTextures ) {

					pd3dDevice->SetTexture( 0, m_pMeshTextures[ i ] );

				}

				m_pMesh->DrawSubset( i );

			}

			pd3dDevice->Release();

			return S_OK;

		}

		//
		//	DrawAt
		//

		HRESULT Draw(
			const D3DXMATRIX & worldMatrix
			,const D3DXMATRIX * pPreTransformMatrix
			,const D3DXMATRIX * pPostTransformMatrix
			,const bool bUseMeshMaterial = true
			,const bool bUseMeshTexture = true
		) {

			if ( pPreTransformMatrix ) {

				if ( pPostTransformMatrix ) {

					D3DXMATRIX useMatrix;

					D3DXMatrixMultiply( &useMatrix, pPreTransformMatrix, &worldMatrix );

					return Draw(
						D3DXMatrixMultiply( &useMatrix, &useMatrix, pPostTransformMatrix )
						,bUseMeshMaterial
						,bUseMeshTexture
					);

				}

				D3DXMATRIX useMatrix;

				D3DXMatrixMultiply( &useMatrix, pPreTransformMatrix, &worldMatrix );

				return Draw(
					&useMatrix
					,bUseMeshMaterial
					,bUseMeshTexture
				);
				
			} else if ( pPostTransformMatrix ) {

				D3DXMATRIX useMatrix;

				return Draw(
					D3DXMatrixMultiply( &useMatrix, &worldMatrix, pPostTransformMatrix )
					,bUseMeshMaterial
					,bUseMeshTexture
				);

			}
			
			return Draw(
				&worldMatrix
				,bUseMeshMaterial
				,bUseMeshTexture
			);

		}

		//
		//	ConformToCubeThenDraw()
		//

		HRESULT 
		ConformToCubeThenDraw(
			const D3DXMATRIX & worldMatrix
			,const D3DXVECTOR3 & cubeMin
			,const D3DXVECTOR3 & cubeMax
			,const D3DXMATRIX * pPostTransformMatrix
			,const bool bUseMeshMaterial = true
			,const bool bUseMeshTexture = true
		) {

			if ( !m_pMesh ) {
				
				return E_FAIL;

			}

			// determine translation

			D3DXVECTOR3 cubeCenter = (cubeMax + cubeMin) * 0.5f;

			D3DXVECTOR3 translation = cubeCenter - m_BoundBoxCenter;

			// determine scale

			D3DXVECTOR3 cubeSize = (cubeMax - cubeMin);

			D3DXVECTOR3 scale;

			if ( std::numeric_limits<FLOAT>::epsilon() < m_BoundBoxSize.x ) {

				scale.x = cubeSize.x / m_BoundBoxSize.x;

			} else {

				scale.x = 1.0f;

			}

			if ( std::numeric_limits<FLOAT>::epsilon() < m_BoundBoxSize.y ) {

				scale.y = cubeSize.y / m_BoundBoxSize.y;

			} else {

				scale.y = 1.0f;

			}

			if ( std::numeric_limits<FLOAT>::epsilon() < m_BoundBoxSize.z ) {

				scale.z = cubeSize.z / m_BoundBoxSize.z;

			} else {

				scale.z = 1.0f;

			}

			// check to see if this is a NOP

			if ( 
				(std::numeric_limits<FLOAT>::epsilon() >= scale.x) ||
				(std::numeric_limits<FLOAT>::epsilon() >= scale.y) ||
				(std::numeric_limits<FLOAT>::epsilon() >= scale.z)
			) {

				return S_OK;

			}

			// build translate and scale matrix (make one step?)

			D3DXMATRIX translateMatrix;

			D3DXMatrixTranslation( &translateMatrix, translation.x, translation.y, translation.z );

			D3DXMATRIX scaleMatrix;

			D3DXMatrixScaling( &scaleMatrix, scale.x, scale.y, scale.z );

			D3DXMATRIX transformMatrix;

			D3DXMatrixMultiply( &transformMatrix, &translateMatrix, &scaleMatrix );

			return Draw(
				worldMatrix
				,&transformMatrix
				,pPostTransformMatrix
				,bUseMeshMaterial
				,bUseMeshTexture
			);

		}

		// --------------------------------------------------------------------

		//
		//	LoadFromFile()
		//

		HRESULT LoadFromFile(
			LPDIRECT3DDEVICE8 pd3dDevice
			,const char * pzFilename
			,const DWORD dwOptions
		) {

			Release();

			// -----------------------------------------------------------------

			LPD3DXBUFFER pD3DXMtrlBuffer;

			if( FAILED( D3DXLoadMeshFromX(
				const_cast<LPSTR>( pzFilename )
				,dwOptions
				,pd3dDevice
				,NULL // &m_pAdjacency
				,&pD3DXMtrlBuffer
				,&m_dwNumMaterials
				,&m_pMesh
			) ) ) {

				return E_FAIL;

			}

			m_dwNumSubsets = m_dwNumMaterials;

			// extract the material and texture filenames
			// -----------------------------------------------------------------

			D3DXMATERIAL* d3dxMaterials = (D3DXMATERIAL*)pD3DXMtrlBuffer->GetBufferPointer();

			m_pMeshMaterials = new D3DMATERIAL8 [ m_dwNumMaterials ];

			if ( !m_pMeshMaterials ) {

				Release();

				return E_FAIL;

			}

			m_pMeshTextures  = new LPDIRECT3DTEXTURE8 [ m_dwNumMaterials ];

			if ( !m_pMeshTextures ) {

				Release();

				return E_FAIL;

			}

			for( DWORD i=0; i < m_dwNumMaterials; i++ ) {

				// Copy the material

				m_pMeshMaterials[ i ] = d3dxMaterials[ i ].MatD3D;

				// Set the ambient color for the material (D3DX does not do this)

				m_pMeshMaterials[ i ].Ambient = m_pMeshMaterials[ i ].Diffuse;

				// Create the texture

				if( FAILED( D3DXCreateTextureFromFile(
					pd3dDevice, d3dxMaterials[ i ].pTextureFilename,
					&m_pMeshTextures[ i ] ) ) ) {

					m_pMeshTextures[ i ] = NULL;

				}

			}

			// Done with the material buffer

			pD3DXMtrlBuffer->Release();

			// find the bound box
			// -----------------------------------------------------------------

			BYTE * pFVFs = 0;

			if ( FAILED( m_pMesh->LockVertexBuffer( 0, &pFVFs ) ) ) {

				Release();

				return E_FAIL;

			}

			if ( FAILED( D3DXComputeBoundingBox(
				pFVFs
				,m_pMesh->GetNumVertices()
				,m_pMesh->GetFVF()
				,&m_BoundBoxMin
				,&m_BoundBoxMax
				) ) ) {

				Release();

				return E_FAIL;

			}

			m_pMesh->UnlockVertexBuffer();

			m_BoundBoxSize = m_BoundBoxMax - m_BoundBoxMin;

			m_BoundBoxCenter = (m_BoundBoxMin + m_BoundBoxMax) * 0.5f;

			return S_OK;

		}

		// --------------------------------------------------------------------

		HRESULT AdoptMesh( LPD3DXMESH pMesh, const DWORD dwSubsets ) {

			if ( m_pMesh == pMesh ) {

				return S_OK;

			}

			Release();

			// -----------------------------------------------------------------

			m_pMesh = pMesh;

			m_dwNumSubsets = dwSubsets;

			// find the bound box
			// -----------------------------------------------------------------

			BYTE * pFVFs = 0;

			if ( FAILED( m_pMesh->LockVertexBuffer( 0, &pFVFs ) ) ) {

				Release();

				return E_FAIL;

			}

			if ( FAILED( D3DXComputeBoundingBox(
				pFVFs
				,m_pMesh->GetNumVertices()
				,m_pMesh->GetFVF()
				,&m_BoundBoxMin
				,&m_BoundBoxMax
				) ) ) {

				Release();

				return E_FAIL;

			}

			m_pMesh->UnlockVertexBuffer();

			m_BoundBoxSize = m_BoundBoxMax - m_BoundBoxMin;

			m_BoundBoxCenter = (m_BoundBoxMin + m_BoundBoxMax) * 0.5f;

			return S_OK;
		}

		// --------------------------------------------------------------------

		HRESULT Optimize(
			const DWORD dwFlags = D3DXMESHOPT_ATTRSORT | D3DXMESHOPT_VERTEXCACHE | D3DXMESHOPT_COMPACT
		) {

			if ( !m_pMesh ) return E_FAIL;

			LPD3DXMESH pOptimized = 0;

			HRESULT hr = m_pMesh->Optimize(
				dwFlags
				,NULL
				,NULL
				,NULL
				,NULL
				,&pOptimized
			);

			if ( FAILED(hr) ) {

				return hr;

			}

			return AdoptMesh( pOptimized, m_dwNumSubsets );

		}

		// --------------------------------------------------------------------

		HRESULT ConvertToFVF(
			LPDIRECT3DDEVICE8 pd3dDevice
			,const DWORD dwFVF
			,const bool bCalcNormals
		) {

			if ( !m_pMesh ) return E_FAIL;

			LPD3DXMESH pConverted;

			HRESULT hr = m_pMesh->CloneMeshFVF(
				m_pMesh->GetOptions()
				,dwFVF
				,pd3dDevice
				,&pConverted
			);

			if ( FAILED(hr) ) {

				return hr;

			}

			if ( bCalcNormals && (D3DFVF_NORMAL & dwFVF) ) {

//				if ( FAILED( hr = D3DXComputeNormals( pConverted ) ) ) {
				if ( FAILED( hr = D3DXComputeNormals( pConverted, 0 ) ) ) {

					pConverted->Release();

					return hr;

				}

			}
	
			return AdoptMesh( pConverted, m_dwNumSubsets );
		}

		// --------------------------------------------------------------------

		HRESULT ComputeNormals() {

			if ( !m_pMesh ) return E_FAIL;

			if ( D3DFVF_NORMAL & m_pMesh->GetFVF() ) {

				HRESULT hr;

//				if ( FAILED( hr = D3DXComputeNormals( m_pMesh ) ) ) {
				if ( FAILED( hr = D3DXComputeNormals( m_pMesh, 0 ) ) ) {

					return hr;

				}

			}

			return S_OK;

		}

		// --------------------------------------------------------------------

		int FaceCount() {

			return m_pMesh->GetNumFaces();

		}

	}; // class CMy3DXMesh

}; // namespace BPT

#endif // !defined( MY3DXMESH_EFBEEF06_BAC5_4cad_8EEB_228F58A90C44_INCLUDED )
